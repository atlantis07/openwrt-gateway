This directory contains certificates and keys required for SSL testing.
The CA key has password "password".
