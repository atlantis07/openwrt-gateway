#ifndef __TASK_H
#define __TASK_H

#define TASK_DATA_LEN 512

#define DEVICE_SWITCH			(1)
#define DEVICE_AIRCONDITION		(2)

typedef struct switch_report_data{
	unsigned char macaddr[8];
	unsigned char num;
	unsigned char status;
}SWITCH_REPORT_DATA;

#define ACTION_REPORT	(1)
#define ACTION_SCENE	(2)

#define TASK_OK	0
#define TASK_INIT (-1)
#define TASK_MALLOC (-2)
#define TASK_EMPTY (-3)

pthread_mutex_t task_mutex_lock;

typedef struct taskinfo{
	int action;
	int type;
	char data[TASK_DATA_LEN];
}TASKINFO;

typedef struct _task_queue
{
	struct taskinfo tinfo;
	struct _task_queue *prev;
	struct _task_queue *next;
}TASK_QUEUE;

int task_init();
void task_print();
int task_insert_tail(TASKINFO tinfo);
int task_remove_head(TASKINFO *tinfo);
void *task_run(void *arg);
#endif
