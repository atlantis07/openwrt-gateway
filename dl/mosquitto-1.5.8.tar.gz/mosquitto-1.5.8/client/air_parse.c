#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define RBUF_LEN 24 
unsigned char soaking[]						=	{0x01, 0x03, 0x0, 0x2, 0x0, 0x1, 0x25, 0xCA};
unsigned char sleet[]						=	{0x02, 0x03, 0x0, 0x0, 0x0, 0x1, 0x84, 0x39};
unsigned char pm_transmitter[]				=	{0x03, 0x03, 0x0, 0x0, 0x0, 0x2, 0xC5, 0xE9};
unsigned char wind[]						=	{0x04, 0x03, 0x0, 0x0, 0x0, 0x2, 0xC4, 0x5E};
unsigned char temperature_humidity_sensor[] =	{0x05, 0x03, 0x0, 0x0, 0x0, 0x2, 0xC5, 0x8F};
unsigned char pm_transmitter2[] =				{0x06, 0x03, 0x0, 0x0, 0x0, 0x2, 0xC5, 0xBC};

int check_data(unsigned char* rbuf, int ret){
	if(ret <= 2){
		printf("not enough data\n");
		return 1;
	}

	if(rbuf[2] == 0){
		printf("data len is null\n");
		return 1;
	}
	unsigned char buf[RBUF_LEN];
	memset(buf, 0, RBUF_LEN);
	memcpy(buf, rbuf, ret - 2);

	unsigned int crcval = crc16table(buf, ret - 2);
	if( crcval != rbuf[ret - 2] + (rbuf[ret - 1] << 8)){
		printf("crc error\n");
		return 1;
	}

	return 0;
}

int get_device(int fd, unsigned char *dev, int len){
	unsigned char rbuf[RBUF_LEN];
	memset(rbuf, 0, RBUF_LEN);
	write(fd, dev, len);
	usleep(300000);
	int ret = read(fd, rbuf, RBUF_LEN);
	if(ret < 0 ){
		printf("read error\n");
		return 1;
	}
	else if(ret > 0){
		for(int i = 0;i < ret; i++){
			printf("%2x ", rbuf[i]);
		}
		printf("\n");
		int cret = check_data(rbuf, ret);
		if(cret){
			printf("invalid value\n");
			return 1;
		}
		
		switch(dev[0])
		{
			case 0x1:
				{
					if(rbuf[2] == 0x2){
						int soak = rbuf[4];
						if (soak == 0x01)
							printf("Soak Normal\n");
						else if(soak == 0x2)
							printf("Soak Warning\n");
					}
					break;
				}
			case 0x2:
				{
					if(rbuf[2] == 0x2){
						int rain = rbuf[4];
						if(rain == 0x0){
							printf("Rain&Snow Normal\n");
						}
						else if (rain == 0x1){
							printf("Rain&Snow Warning\n");
						}
					}
					break;
				}
			case 0x3:
			{
				if(rbuf[2] == 0x4){
					unsigned int pm25 = (rbuf[3] << 8) + rbuf[4];
					unsigned int pm10 = (rbuf[5] << 8) + rbuf[6];
					printf("PM2.5 %dug/m3\n", pm25);
					printf("PM10 %dug/m3\n", pm10);
				}
				break;
			}
			case 0x4:
			{
				if(rbuf[2] == 0x2 || rbuf[2] == 0x4){
					float wind_speed = ((rbuf[3] << 8) + rbuf[4]) / 10.0;
					printf("Wind Speed %.1f\n", wind_speed);
				}
				break;
			}
			case 0x5:
			{
				if(rbuf[2] == 0x4){
					float temp;
					if(rbuf[5] == 0xFF){
						long _temp = ((rbuf[5] << 8) + rbuf[6]) - 65536;
						temp = _temp / 10.0;
					}
					else{
						temp = ((rbuf[5] << 8) + rbuf[6])/ 10.0;
					}
					printf("Temp %.1f\n", temp);

					double humd = ((rbuf[3] << 8) + rbuf[4])/10.0;
					printf("Humd %.1f\n", humd);
						
				}
				break;
			}
			case 0x6:
			{
				if(rbuf[2] == 0x4){
					unsigned int pm25 = (rbuf[3] << 8) + rbuf[4];
					unsigned int pm10 = (rbuf[5] << 8) + rbuf[6];
					printf("PM2.5 %dug/m3\n", pm25);
					printf("PM10 %dug/m3\n", pm10);
				}
				break;
			}
		}

	}
	else  {
		printf("read none\n");
	}

	return 0;
}

int get_device_info(int fd){
	get_device(fd, soaking, 8);
	usleep(300000);
	get_device(fd, pm_transmitter, 8);
	usleep(300000);
	get_device(fd, wind, 8);
	usleep(300000);
	get_device(fd, temperature_humidity_sensor, 8);
	usleep(300000);
	get_device(fd, pm_transmitter2, 8);
	usleep(300000);
	get_device(fd, sleet, 8);
	usleep(300000);
	
	return 0;
}

