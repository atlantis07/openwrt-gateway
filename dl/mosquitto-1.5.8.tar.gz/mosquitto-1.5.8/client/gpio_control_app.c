/*
 * gpio_control_app
 *
 * Copyright (C) 2017 wurobinson <wurobinson@zhuotk.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is written for JS7628 and JS9331 development board ,
 * work with gpio_control_driver
 */
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <stdlib.h>

#include "common.h"
#include "gpio_control_app.h"

static int gpio_dev_fd;

int gpio_set(const unsigned char *data, int datalen)
{
	int ret;

	gpio_dev_fd = open(GPIO_CONTROL_DEVICE_PATH, O_RDWR);//open gpio device
	if (gpio_dev_fd < 0){
		tl_printf(MSG_ERROR, "open %s failed\n", GPIO_CONTROL_DEVICE_PATH);
		return -1;
	}

	ret = write(gpio_dev_fd, data, datalen);
	if(ret == datalen){
		tl_printf(MSG_INFO, "gpio write ok\n");
	}
	else{
		tl_printf(MSG_INFO, "gpio write failed %d\n", ret);
	}
	close(gpio_dev_fd);
	return 0;
}
