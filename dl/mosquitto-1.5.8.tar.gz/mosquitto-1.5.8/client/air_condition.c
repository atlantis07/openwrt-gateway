#include "air_condition.h"
AIR_NODE *air_head;

int air_init(){
	air_head = (AIR_NODE*) malloc(sizeof(AIR_NODE));
	if(!air_head){
		printf("init air condition failed\n");
		return -1; 
	}   
	
	air_head->next = NULL;
	air_head->prev = NULL;
	return 0;
}

int air_find(unsigned char *pkt, int type){
	if(!air_head || !pkt){
		return PARAM_NOT_EXIST;
	}
	
	unsigned char addr[AIR_ADDR_LEN];
	memset(addr, 0, AIR_ADDR_LEN);

	if(type == AIRCONDITION_SENDTO || type == AIRCONDITION_RECVFROM){
		memcpy(addr, pkt, AIR_ADDR_LEN);
	}

	if(addr[0] || addr[1]){
		AIR_NODE *p = air_head->next;
		while(p){
			if(!memcmp(p->ainfo.addr, addr, AIR_ADDR_LEN)){
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}

int air_insert_tail(AIR_INFO airinfo){
	AIR_NODE* pn = (AIR_NODE*)malloc(sizeof(AIR_NODE));
	if(!pn){
		return -1;
	}
	
	memcpy(&pn->ainfo, (const void*)&airinfo, sizeof(AIR_INFO));
	pn->next = NULL;
	
	AIR_NODE* m = NULL;
	AIR_NODE* e = NULL;
	m = air_head;
	e = m->next;
	while(e){
		m = e;
		e = e->next;
	}
	
	m->next = pn;
	pn->prev = m;
	return 0;
}
