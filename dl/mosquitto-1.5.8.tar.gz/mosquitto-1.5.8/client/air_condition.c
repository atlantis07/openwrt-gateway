#include "air_condition.h"
#include "mqttc.h"
#include "common.h"
#include "serial.h"
#include "crc.h"
AIR_NODE *air_head;

int air_init(){
	air_head = (AIR_NODE*) malloc(sizeof(AIR_NODE));
	if(!air_head){
		printf("init air condition failed\n");
		return -1; 
	}   

	air_head->next = NULL;
	air_head->prev = NULL;
	return 0;
}

int air_insert_tail(AIR_INFO airinfo){
	AIR_NODE* pn = (AIR_NODE*)malloc(sizeof(AIR_NODE));
	if(!pn){
		return -1;
	}

	memcpy(&pn->ainfo, (const void*)&airinfo, sizeof(AIR_INFO));
	pn->ainfo.is_update = 1;
	pn->next = NULL;

	AIR_NODE* m = NULL;
	AIR_NODE* e = NULL;
	m = air_head;
	e = m->next;
	while(e){
		m = e;
		e = e->next;
	}

	m->next = pn;
	pn->prev = m;
	return 0;
}

void air_free(){
	AIR_NODE *h = air_head;
	while(h){
		AIR_NODE *n = h->next;
		h->prev = NULL;
		h->next = NULL;
		free(h);
		h = n;
	}
}

AIR_NODE *find_air_short_node(unsigned char *smacaddr){
	AIR_NODE *h = air_head;
	while(h){
		if(!memcmp(h->ainfo.s_macaddr, smacaddr, S_MACADDR_LEN)){
			return h;
		}
		h = h->next;
	}
	return NULL;
}

AIR_NODE *find_air_node(unsigned char *macaddr){
	AIR_NODE *h = air_head;
	while(h){
		if(!memcmp(h->ainfo.macaddr, macaddr, MACADDR_LEN)){
			return h;
		}
		h = h->next;
	}
	return NULL;
}


int ait_condition_is_exist(unsigned char *addr){
	if(!addr){
		return PARAM_ERROR;
	}

	int ret = AIR_NOT_EXIST;
	pthread_mutex_lock(&air_mutex_lock);
	AIR_NODE *air_node = find_air_node(addr);
	pthread_mutex_unlock(&air_mutex_lock);

	if(air_node){
		ret = AIR_EXIST;
	}
	air_node = NULL;
	return ret;
}

void *air_passthrough_pthread(void *arg){
	AIR_NODE *air = (AIR_NODE *)arg;
	if(!air){
		goto exit;
	}
	pthread_mutex_lock(&air_mutex_lock);
	AIR_NODE *air_node = find_air_short_node(air->ainfo.s_macaddr);
	if(!air_node){
		printf("[passthrough] air node is not exist\n");
		pthread_mutex_unlock(&air_mutex_lock);
		goto exit;
	}
	memcpy(air_node->ainfo.status, air->ainfo.status, AIR_STATUS_LEN);
	air_node->ainfo.is_update = 1;	
	air_node = NULL;
	printf("air passthrough set success\n");
	pthread_mutex_unlock(&air_mutex_lock);
exit:
	free(arg);
	arg = NULL;
	return NULL;
}

void *air_init_pthread(void *arg){
	AIR_NODE *air = (AIR_NODE *)arg;
	if(!air){
		goto exit;
	}

	AIR_NODE *air_node = find_air_node(air->ainfo.macaddr);
	if(!air_node){
		AIR_INFO _air;
		memcpy(&_air, &air->ainfo, sizeof(AIR_INFO));
	
		pthread_mutex_lock(&air_mutex_lock);
		int ret = air_insert_tail(_air);
		if(!ret){
			register_aircondition(air->ainfo.macaddr, "FANGWEI");
		}
		pthread_mutex_unlock(&air_mutex_lock);

	}
	else{
		printf("update air node\n");
		//update
	}
exit:
	free(arg);
	arg = NULL;
	return NULL;
}

void air_passpkt_init(AIR_PASS_PKT *apkt, unsigned char *data, unsigned char datalen, unsigned char *devaddr){
	apkt->h[0] = 0xfe;
	apkt->h[1] = 0xfd;

	apkt->type = AIRCONDITION_SENDTO | (TYPE_AIRCONDITION << 4);
	apkt->data_len = datalen;
	memcpy(apkt->s_macaddr, devaddr, S_MACADDR_LEN); 
	memcpy(apkt->data, data, AIR_QUERY_DATALEN);

	//	crc
	unsigned short crc = crc16tablefast((unsigned char *)apkt, sizeof(AIR_PASS_PKT) - 4);
	apkt->crc[0] = crc & 0xff;
	apkt->crc[1] = crc >> 8;

	apkt->t[0] = 0xef;
	apkt->t[1] = 0xdf;
}


int query_climate(unsigned char* res, char *series, unsigned char *addr, int addrlen){
	unsigned char query[AIR_QUERY_DATALEN] = {0xa0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	AIR_PASS_PKT apkt;
	int air_datalen = sizeof(AIR_PASS_PKT);
	unsigned char s_addr[S_MACADDR_LEN];
	memset(s_addr, 0, S_MACADDR_LEN);

	if(!strcmp(series, "FANGWEI")){
		if(!addr){
			return PARAM_ERROR; 
		}
		pthread_mutex_lock(&air_mutex_lock);
		AIR_NODE *air = find_air_node(addr);
		if(!air){
			printf("air node is not exist\n");
			pthread_mutex_unlock(&air_mutex_lock);
			return PARAM_ERROR; 
		}
		query[1] = air->ainfo.addr[0];
		query[2] = air->ainfo.addr[1];
		memcpy(s_addr, air->ainfo.s_macaddr, S_MACADDR_LEN);
		pthread_mutex_unlock(&air_mutex_lock);
		query[7] = climate_crc(query, AIR_PASS_DATA_LEN);
	}

	air_passpkt_init(&apkt, query, (AIR_QUERY_DATALEN + S_MACADDR_LEN), s_addr);

	printf("query cmd:\n");
	for(int i = 0;i < air_datalen; i++){
		printf("%02x ", ((unsigned char *)&apkt)[i]);
	}
	printf("\n");

	int ret = sendto_zigbee((unsigned char *)&apkt, air_datalen);
	if(ret != air_datalen)
		return -1;

	usleep(2500000);
	//usleep(1500000);

	pthread_mutex_lock(&air_mutex_lock);
	AIR_NODE *air_node = find_air_node(addr);
	if(!air_node){
		printf("air node not exist\n");
		pthread_mutex_unlock(&air_mutex_lock);
		return -1;
	}

	if(air_node->ainfo.is_update){
		memcpy(res, &air_node->ainfo.status, AIR_STATUS_LEN);
		air_node->ainfo.is_update = 0;
		air_node = NULL;
		pthread_mutex_unlock(&air_mutex_lock);
		return 0;
	}
	else{
		printf("air query failed\n");
	}

	pthread_mutex_unlock(&air_mutex_lock);
	return -2;
}

void update_climate(unsigned char *gwaddr, char *series, char *host, unsigned char *addr, int addrlen){
	if(!host){
		return ;
	}

	char update_mode[256] = "";
	char update_temp[256] = "";
	char update_temp_current[256] = "";
	char update_fan[256] = "";

	unsigned char res[64] = "";
	int ret;
	ret = query_climate(res, series, addr, addrlen);
	if(ret < 0)
		return;


	int mode = (res[3] & (0x1 << 5)) >> 5;
	int current = res[6];
	int fan = res[3] & 0x3;
	char fan_mode[8] = "";
	if(fan == 0){
		memcpy(fan_mode, "auto", 4);
	}
	else if (fan == 0x1){
		memcpy(fan_mode, "high", 4);
	}
	else if (fan == 0x2){
		memcpy(fan_mode, "medium", 6);
	}
	else if (fan == 0x3){
		memcpy(fan_mode, "low", 3);
	}

//	eede08a7f2d2/airconditioning/FANGWEI/3310/

	int on = (res[3] & (0x1 << 4)) >> 4;
	if(on)
		sprintf(update_mode , "mosquitto_pub -h %s -t '%s/airconditioning/%s/%02x%02x%02x%02x%02x%02x%02x%02x/mode_state' -m '%s' ", host, gwaddr, series, addr[0], addr[1], addr[2], addr[3], addr[4], addr[5], addr[6], addr[7], mode == 0?"cool":"heat");
	else
		sprintf(update_mode , "mosquitto_pub -h %s -t '%s/airconditioning/%s/%02x%02x%02x%02x%02x%02x%02x%02x/mode_state' -m 'off' ", host, gwaddr, series, addr[0], addr[1], addr[2], addr[3], addr[4], addr[5], addr[6], addr[7]);

	sprintf(update_temp , "mosquitto_pub -h %s -t '%s/airconditioning/%s/%02x%02x%02x%02x%02x%02x%02x%02x/temperature_state' -m '%d' ", host, gwaddr, series, addr[0], addr[1], addr[2], addr[3], addr[4], addr[5], addr[6], addr[7], res[5]);
	
	sprintf(update_temp_current , "mosquitto_pub -h %s -t '%s/airconditioning/%s/%02x%02x%02x%02x%02x%02x%02x%02x/temperature_current' -m '%d' ", host, gwaddr, series, addr[0], addr[1],  addr[2], addr[3], addr[4], addr[5], addr[6], addr[7], current);

	sprintf(update_fan , "mosquitto_pub -h %s -t '%s/airconditioning/%s/%02x%02x%02x%02x%02x%02x%02x%02x/fan_state' -m '%s' ", host, 
			gwaddr, series, addr[0], addr[1], addr[2], addr[3], addr[4], addr[5], addr[6], addr[7], fan_mode);

	printf("%s\n", update_mode);
	printf("%s\n", update_temp);
	printf("%s\n", update_temp_current);
	printf("%s\n", update_fan);

	system(update_mode);
	system(update_temp);
	system(update_temp_current);
	system(update_fan);
}

void airnode_action(char *type){
	if(!type)
		return;

	if(!strcmp(type, "print")){
		AIR_NODE *h = air_head->next;
		while(h){
			printf("addr: %02x %02x\n", h->ainfo.addr[0], h->ainfo.addr[1]);
			printf("smacaddr: %02x %02x\n", h->ainfo.s_macaddr[0], h->ainfo.s_macaddr[1]);
			printf("macaddr: %02x %02x %02x %02x %02x %02x %02x %02x\n", 
					h->ainfo.macaddr[0], h->ainfo.macaddr[1],
					h->ainfo.macaddr[2], h->ainfo.macaddr[3],
					h->ainfo.macaddr[4], h->ainfo.macaddr[5],
					h->ainfo.macaddr[6], h->ainfo.macaddr[7]);
			printf("status: %02x %02x %02x %02x %02x %02x %02x %02x\n", h->ainfo.status[0], h->ainfo.status[1]
					,h->ainfo.status[2], h->ainfo.status[3],h->ainfo.status[4],
					h->ainfo.status[5],	h->ainfo.status[6], h->ainfo.status[7]);
			printf("is_update: %d\n", h->ainfo.is_update);
			h = h->next;
		}

	}
}
