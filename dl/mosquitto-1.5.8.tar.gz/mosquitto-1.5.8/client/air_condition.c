#include "air_condition.h"
#include "node.h"
#include "mqttc.h"
#include "common.h"
#include "serial.h"
#include "crc.h"
#include <fcntl.h>

AIR_NODE *air_head;

int air_init(){
	air_head = (AIR_NODE*) malloc(sizeof(AIR_NODE));
	if(!air_head){
		tl_printf(MSG_INFO, "init air condition failed\n");
		return -1; 
	}   

	air_head->next = NULL;
	air_head->prev = NULL;
	return 0;
}

int air_insert_tail(AIR_INFO airinfo){
	AIR_NODE* pn = (AIR_NODE*)malloc(sizeof(AIR_NODE));
	if(!pn){
		return -1;
	}

	memcpy(&pn->ainfo, (const void*)&airinfo, sizeof(AIR_INFO));
	pn->ainfo.is_update = 1;
	pn->next = NULL;

	AIR_NODE* m = NULL;
	AIR_NODE* e = NULL;
	m = air_head;
	e = m->next;
	while(e){
		m = e;
		e = e->next;
	}

	m->next = pn;
	pn->prev = m;
	return 0;
}

void air_free(){
	AIR_NODE *h = air_head;
	while(h){
		AIR_NODE *n = h->next;
		h->prev = NULL;
		h->next = NULL;
		free(h);
		h = n;
	}
}

/*
AIR_NODE *find_air_short_node(unsigned char *smacaddr){
	AIR_NODE *h = air_head;
	while(h){
		if(!memcmp(h->ainfo.s_macaddr, smacaddr, S_MACADDR_LEN)){
			return h;
		}
		h = h->next;
	}
	return NULL;
}
*/

AIR_NODE *find_air_node(unsigned char *macaddr){
	AIR_NODE *h = air_head;
	while(h){
		if(!memcmp(h->ainfo.macaddr, macaddr, MACADDR_LEN)){
			return h;
		}
		h = h->next;
	}
	return NULL;
}


int ait_condition_is_exist(unsigned char *addr){
	if(!addr){
		return PARAM_ERROR;
	}

	int ret = AIR_NOT_EXIST;
	pthread_mutex_lock(&air_mutex_lock);
	AIR_NODE *air_node = find_air_node(addr);
	pthread_mutex_unlock(&air_mutex_lock);

	if(air_node){
		ret = AIR_EXIST;
	}
	air_node = NULL;
	return ret;
}

int air_infrared_preinit(unsigned char *smacaddr, unsigned char *addr){
	if(!smacaddr || !addr){
		return PARAM_ERROR;
	}

	int fd = open(ZIGBEE_DEV, O_RDWR);
	if(fd < 0){ 
		perror("fd");
		return OPEN_DEVICE_ERROR;
	}

	unsigned char cmd[INFRARED_CMD_LEN] = {0xfe, 0xfd, ( AIRCONDITION_SENDTO | (TYPE_ZIGBEE_AIRCONDITION << 4)),
		0x07, 0x0, 0x0,
		0x00, 0x0, 0x0, 0x0, 0x0,
		0x0, 0x0, 0xef, 0xdf};
	cmd[4] = smacaddr[0];
	cmd[5] = smacaddr[1];

	cmd[6] = 0x2;
	cmd[7] = addr[0];
	cmd[8] = addr[1];
	cmd[9] = 0x8;
	cmd[10] = climate_infrared_xor((cmd + 6), 4); 

	unsigned short modbus_crc[2];
	modbus_crc[0] = crc16table(cmd, INFRARED_CMD_LEN - 4) & 0xff;

	modbus_crc[1] = crc16table(cmd, INFRARED_CMD_LEN - 4) >> 8;

	cmd[11] = modbus_crc[0];
	cmd[12] = modbus_crc[1];

	int ret = write(fd, cmd, INFRARED_CMD_LEN);
	if(ret != INFRARED_CMD_LEN){
		close(fd);
		return WRITE_DEVICE_ERROR;
	}	
	tl_printf_array("air condition preinit", cmd, INFRARED_CMD_LEN);
	close(fd);
	return WRITE_OK;
}

void *air_init_pthread(void *arg){
	AIR_NODE *air = (AIR_NODE *)arg;
	if(!air){
		goto exit;
	}

	unsigned char s_macaddr[S_MACADDR_LEN] = "";
	pthread_mutex_lock(&node_mutex_lock);
	NODE *node = find_node(air->ainfo.macaddr);
	if(node){
		memcpy(s_macaddr, node->ninfo.s_macaddr, S_MACADDR_LEN);
	}	
	else{
		pthread_mutex_unlock(&node_mutex_lock);
		free(arg);
		arg = NULL;
		return NULL;
	}
	pthread_mutex_unlock(&node_mutex_lock);

	pthread_mutex_lock(&air_mutex_lock);
	AIR_NODE *air_node = find_air_node(air->ainfo.macaddr);
	if(!air_node){
		AIR_INFO _air;
		memcpy(&_air, &air->ainfo, sizeof(AIR_INFO));

		int ret = air_insert_tail(_air);
		if(!ret){
			tl_printf(MSG_INFO, "insert air node\n");
			if(!strcmp(air->ainfo.series, "INFRARED")){
				air_infrared_preinit(s_macaddr, air->ainfo.addr);
			}
		}
	}
	else{
		tl_printf(MSG_INFO, "update air node\n");
		//air_node->ainfo.s_macaddr[0] = air->ainfo.s_macaddr[0]; 
		//air_node->ainfo.s_macaddr[1] = air->ainfo.s_macaddr[1];
		air_node->ainfo.addr[0] = air->ainfo.addr[0];
		air_node->ainfo.addr[1] = air->ainfo.addr[1];
		memset(air_node->ainfo.series, 0, AIR_SERIES_LEN);
		memcpy(air_node->ainfo.series, air->ainfo.series, strlen(air->ainfo.series));
		//update
	}
	air = NULL;
	air_node = NULL;
	pthread_mutex_unlock(&air_mutex_lock);
exit:
	free(arg);
	arg = NULL;
	return NULL;
}

void air_passpkt_init(AIR_PASS_PKT *apkt, unsigned char *data, unsigned char datalen, unsigned char *devaddr){
	apkt->h[0] = 0xfe;
	apkt->h[1] = 0xfd;
	
	apkt->dt = DEV_ZIGBEE;

	apkt->type = AIRCONDITION_SENDTO | (TYPE_ZIGBEE_AIRCONDITION << 4);
	apkt->data_len = datalen;
	memcpy(apkt->s_macaddr, devaddr, S_MACADDR_LEN); 
	memcpy(apkt->data, data, AIR_QUERY_DATALEN);

	//	crc
	unsigned short crc = crc16tablefast((unsigned char *)apkt, sizeof(AIR_PASS_PKT) - 4);
	apkt->crc[0] = crc & 0xff;
	apkt->crc[1] = crc >> 8;

	apkt->t[0] = 0xef;
	apkt->t[1] = 0xdf;
}


void airnode_action(char *type){
	if(!type || !air_head)
		return;

	AIR_NODE *h = air_head->next;

	while(h){
		AIR_NODE *next = h->next;
		if(!strcmp(type, "print")){
			tl_printf(MSG_INFO, "air condition: ");
			tl_printf(MSG_INFO, "	[%02x %02x %02x %02x %02x %02x %02x %02x]",
					h->ainfo.macaddr[0], h->ainfo.macaddr[1],
					h->ainfo.macaddr[2], h->ainfo.macaddr[3],
					h->ainfo.macaddr[4], h->ainfo.macaddr[5],
					h->ainfo.macaddr[6], h->ainfo.macaddr[7]);
			tl_printf(MSG_INFO, "	[%02x %02x]\n", h->ainfo.addr[0], h->ainfo.addr[1]);
			tl_printf(MSG_INFO, "	series: %s\n", h->ainfo.series);
			tl_printf(MSG_INFO,"	on:   %d\n", h->ainfo.on);
			tl_printf(MSG_INFO, "	temp: %d\n", h->ainfo.temperature);
			tl_printf(MSG_INFO, "	mode: %d\n", h->ainfo.mode);
			tl_printf(MSG_INFO,"	fan:  %d\n", h->ainfo.fan);
			tl_printf(MSG_INFO,"	status: %02x %02x %02x %02x %02x %02x %02x %02x\n", h->ainfo.status[0], h->ainfo.status[1], 
					h->ainfo.status[2], h->ainfo.status[3],h->ainfo.status[4],
					h->ainfo.status[5],	h->ainfo.status[6], h->ainfo.status[7]);
			//printf("is_update: %d\n", h->ainfo.is_update);
		}
		else if(!strcmp(type, "free")){
			h->prev = NULL;
			h->next = NULL;
			free(h);
		}
		h = next;
	}
}

//int air_final_init(unsigned char *macaddr, char *series, unsigned char* climate_addr){
int air_final_init(unsigned char *macaddr, AC_REG_INFO ac_reg){
	AIR_NODE *anode = (AIR_NODE *)malloc(AIR_NODE_LEN);
	if(anode){
		//memcpy(anode->ainfo.addr, &ac_reg.addr, AIR_ADDR_LEN);
		pthread_mutex_lock(&node_mutex_lock);
		NODE* p = find_node(macaddr);		        
		if(p){
			//memcpy(anode->ainfo.s_macaddr, p->ninfo.s_macaddr, S_MACADDR_LEN);
			//ipkt->s_macaddr[0] = p->ninfo.s_macaddr[0];
			//ipkt->s_macaddr[1] = p->ninfo.s_macaddr[1];
			p = NULL;
		}   
		else{
			free(anode);
			anode = NULL;
			pthread_mutex_unlock(&node_mutex_lock);
			return -1; 
		}  
		pthread_mutex_unlock(&node_mutex_lock);

		//		memcpy(anode->ainfo.s_macaddr, reginfo.smacaddr, S_MACADDR_LEN);
		memcpy(anode->ainfo.macaddr, macaddr, MACADDR_LEN);
		memcpy(anode->ainfo.series, ac_reg.series, AIR_SERIES_LEN);
		anode->ainfo.addr[0] = ac_reg.addr >> 8;
		anode->ainfo.addr[1] = ac_reg.addr & 0xff;
		anode->ainfo.on = 0;
		anode->ainfo.temperature = 0;
		anode->ainfo.mode = 0;
		anode->ainfo.fan = 0;
		memset(anode->ainfo.status, 0, AIR_STATUS_LEN);

		pthread_t air_t;
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

		int ret;
		ret = pthread_create(&air_t, &attr, air_init_pthread, (void *)anode);
		pthread_attr_destroy(&attr);
		if(ret < 0){ 
			printf("pthread_create error,ret=%d\n",ret);
		}   
	} 
	return 0;
}

int climate_data_init(char *series, const cJSON* cdata, unsigned char *data, int *datalen, unsigned char *climate_addr, unsigned char *climate_sdevaddr){
	if(!series || !cdata || !data){
		return PARAM_ERROR;
	}
	cJSON *json = NULL, *arrayItem = NULL;
	unsigned char tk_power = 0;
	unsigned char tk_mode = 0;
	unsigned char tk_temp = 0;
	unsigned char tk_fan = 0;

	json = cJSON_Parse(cdata);
	if(!json){
		tl_printf(MSG_INFO, "!json\n");
		return PARAM_ERROR;
	} 


	arrayItem = cJSON_GetObjectItemCaseSensitive(json, "power");
	if(arrayItem && cJSON_IsString(arrayItem)){
		if(!strcmp(arrayItem->valuestring, "on") || !strcmp(arrayItem->valuestring, "ON")){
			if(!strcmp("INFRARED_FANGWEI", series)){
				tl_printf(MSG_INFO, "%s\n", arrayItem->valuestring);
				tk_power = 1;
			}
		}   
		else{
			if(!strcmp("INFRARED_FANGWEI", series)){
				tl_printf(MSG_INFO, "%s\n", arrayItem->valuestring);
				tk_power = 0;
			}
		}   
	}   
	else{
		cJSON_Delete(json);
		return PARAM_ERROR;
	}

	arrayItem = cJSON_GetObjectItemCaseSensitive(json,"temperature_set");
	if(arrayItem && cJSON_IsNumber(arrayItem)){
		if(!strcmp("INFRARED_FANGWEI", series)){
			tk_temp = arrayItem->valuedouble;
			tl_printf(MSG_INFO, "%d\n", tk_temp);
		}
	}
	else{
		cJSON_Delete(json);
		return PARAM_ERROR;
	}

	arrayItem = cJSON_GetObjectItemCaseSensitive(json,"mode_set");
	if(arrayItem && cJSON_IsString(arrayItem)){
		if(!strcmp(arrayItem->valuestring, "heat") || !strcmp(arrayItem->valuestring, "HEAT")){
			if(!strcmp("INFRARED_FANGWEI", series)){
				tl_printf(MSG_INFO, "heat\n");
				tk_mode = 1;
			}
		}
		else{
			if(!strcmp("INFRARED_FANGWEI", series)){
				tl_printf(MSG_INFO, "cool\n");
				tk_mode = 0;
			}
		}
	}	
	else{
		cJSON_Delete(json);
		return PARAM_ERROR;
	}

	arrayItem = cJSON_GetObjectItemCaseSensitive(json,"fan_set");
	if(arrayItem && cJSON_IsString(arrayItem)){
		if(!strcmp(arrayItem->valuestring, "high") || !strcmp(arrayItem->valuestring, "HIGH")){
			if(!strcmp("INFRARED_FANGWEI", series)){
			tl_printf(MSG_INFO, "fan high\n");
				tk_fan = 1;
			}
		}
		else if(!strcmp(arrayItem->valuestring, "medium") || !strcmp(arrayItem->valuestring, "MEDIUM")|| !strcmp(arrayItem->valuestring, "middle") || !strcmp(arrayItem->valuestring, "MIDDLE")){
			if(!strcmp("INFRARED_FANGWEI", series)){
				tl_printf(MSG_INFO, "fan medium\n");
				tk_fan = 2;
			}
		}
		else if(!strcmp(arrayItem->valuestring, "low") || !strcmp(arrayItem->valuestring, "LOW")){
			if(!strcmp("INFRARED_FANGWEI", series)){
				tl_printf(MSG_INFO, "fan low\n");
				tk_fan = 3;
			}
		}
		else{
			if(!strcmp("INFRARED_FANGWEI", series)){
				tl_printf(MSG_INFO, "fan auto\n");
				tk_fan = 0;
			}
		}
	}
	else{
		cJSON_Delete(json);
		return PARAM_ERROR;
	}
	cJSON_Delete(json);

	if(!strcmp("INFRARED_FANGWEI", series)){
		unsigned char status[AIR_PASS_DATA_LEN] = {0xa1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
		status[1] = climate_addr[0];
		status[2] = climate_addr[1];
		status[3] = (tk_mode << 5) + (tk_power << 4) + tk_fan;
		//status[4] = 0x0;
		status[5] = tk_temp; 
		//status[6] = 0x0;
		status[7] = climate_crc(status, AIR_PASS_DATA_LEN);

		AIR_PASS_PKT apkt;
		air_passpkt_init(&apkt, status, (AIR_PASS_DATA_LEN + S_MACADDR_LEN), climate_sdevaddr);

		*datalen = sizeof(AIR_PASS_PKT);
		memcpy(data, &apkt, *datalen);
	}

	return 0;
}
