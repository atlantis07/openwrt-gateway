#include <stdio.h>                                                                                       
#include <stdlib.h>
#include <string.h>
#include <sys/types.h> 
#include <ctype.h>                                                                                      
#include <stdbool.h>          
#include <stdarg.h> 
#include <poll.h>   
#include <sys/epoll.h>
#include <sys/wait.h> 
#include <signal.h>   
#include <sys/socket.h>
#include <netdb.h>     
#include <netinet/in.h>
#include <arpa/inet.h> 
#include <linux/in6.h> 
#include <linux/ipv6.h>
#include <sys/file.h>  
#include <fcntl.h>     
#include <unistd.h>    
#include <pthread.h>
#include <assert.h>
#include <errno.h>


#if 0
ai_family	
AF_INET		2		IPv4
AF_INET6	10		IPv6
AF_UNSPEC	0		协议无关

ai_protocol
IPPROTO_IP		0	IP协议
IPPROTO_IPV4	4	IPv4
IPPROTO_IPV6	41	IPv6
IPPROTO_UDP		17	UDP
IPPROTO_TCP		6	TCP

ai_socktype
SOCK_STREAM		1	流
SOCK_DGRAM		2	数据报

ai_flags
AI_PASSIVE		1	被动的，用于bind，通常用于server socket
AI_CANONNAME	2	用于返回主机的规范名称
AI_NUMERICHOST	4	地址为数字串
#endif

#define HOST "127.0.0.1"
#define IP6HOST "240e:fb:a000:e::1"
//#define IP6HOST "2001:470:f815::1"
#define PORT "8001"

int connect_to_server(const char *host, const char *port){
	int fd;
	//	struct sockaddr_in;
	struct addrinfo hints, *ai, *res;

	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET6; 
	hints.ai_protocol = IPPROTO_TCP;
	hints.ai_socktype = SOCK_STREAM;

	if(getaddrinfo(host, port, &hints, &res)){
		printf("name lookup %s:%s failed %s", host, port, strerror(errno));
		return -1;
	}

	for (ai = res; ai != NULL; ai = ai->ai_next) {
		fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
		if(fd < 0){
			printf("fd < 0\n");
			continue;
		}

		if (connect(fd, ai->ai_addr, ai->ai_addrlen)) {
			close(fd);
			fd = -1;
			continue;
		}
		//printf("ai family:%d,", ai->ai_family);
		//printf("ai protocol:%d,", ai->ai_protocol);
		//printf("ai socket type:%d\n", ai->ai_socktype);
	}
	return fd;
}

#define BUF_LEN 1024
struct tcp_param {
	int uartfd;
	int sockfd;
};

static void *tcp_rpthread(void *arg) {
	struct tcp_param *p = (struct param *)arg;
	while(true){
		char buf[BUF_LEN];
		memset(buf, 0, BUF_LEN);
		//blocked
		int ret = read(p->sockfd, buf, BUF_LEN);
		if(ret < 0){
			printf("socket read error\n");
			exit(0);
		}
		else if (ret > 0){
			ret = write(p->uartfd, buf, ret);
			if(ret < 0){
				printf("uart write error\n");
				exit(0);
			}
		}
	}
}

static void *tcp_spthread(void *arg) {
	struct tcp_param *p = (struct param *)arg;
	while(true){
		char buf[BUF_LEN];
		memset(buf, 0, BUF_LEN);

		int ret = read(p->uartfd, buf, BUF_LEN);
		if(ret < 0){
			printf("uart read error\n");
			exit(0);
		}
		else if(ret > 0){
			ret = write(p->sockfd, buf, ret);
			if(ret < 0){
				printf("socket write error\n");
				exit(0);
			}
		}
	}
}

///usr/bin/passthrough -tcp -h 39.98.165.253 -p 8001

int tcp_start(int argc, char *argv[], int uartfd){
	int sockfd;
	struct sockaddr_in    servaddr;
	char *ipaddr = NULL;
	int port = 0;

	for(int i = 0; i< argc; i++){
		if(!strcmp("-h", argv[i])){
			if(i==argc-1){                                                                            
				fprintf(stderr, "Error: -h argument given but no host specified.\n\n");                     
				return 1;
			}
			ipaddr = argv[i+1];
		}else if(!strcmp("-p", argv[i])){
			if(i==argc-1){                                                                            
				fprintf(stderr, "Error: -h argument given but no host specified.\n\n");                     
				return 1;
			}
			int ret = sscanf(argv[i+1], "%d", &port);
			if(ret <= 0){
				printf("Invalid Port\n");
				return 1;
			}
		}
	}

//	printf("%s %d\n", ipaddr, port);

	if( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0){
		printf("create socket error: %s(errno: %d)\n", strerror(errno),errno);
		return 1;
	}


	memset(&servaddr, 0, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(port);
	if( inet_pton(AF_INET, ipaddr, &servaddr.sin_addr) <= 0){
		printf("inet_pton error for %s\n",argv[1]);
		return 1;
	}

	if( connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0){
		printf("connect error: %s(errno: %d)\n",strerror(errno),errno);
		return 1;
	}

	struct tcp_param p;
	p.uartfd = uartfd;
	p.sockfd = sockfd;

	pthread_t rpid, spid;
	int rret, sret;
	
	pthread_attr_t rattr, sattr;
	pthread_attr_init(&rattr);
	pthread_attr_init(&sattr);
	
	pthread_attr_setdetachstate(&rattr, PTHREAD_CREATE_JOINABLE);
	pthread_attr_setdetachstate(&sattr, PTHREAD_CREATE_JOINABLE);


	rret = pthread_create(&rpid, &rattr, tcp_rpthread, (void *)&p);
	if(rret<0)
	{
		printf("pthread_create error,ret=%d\n",rret);
		return -1;
	}
	
	sret = pthread_create(&spid, &sattr, tcp_spthread, (void *)&p);
	if(sret<0)
	{
		printf("pthread_create error,ret=%d\n",sret);
		return -1;
	}

	pthread_join(rpid, NULL);
	pthread_join(spid, NULL);
	printf("Passthrough threads exit\n");

	return 0;
}
