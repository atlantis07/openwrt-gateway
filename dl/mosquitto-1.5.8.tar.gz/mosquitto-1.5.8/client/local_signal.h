#ifndef __SIGNAL_H
#define __SIGNAL_H
void sigint_action(void);
#endif
