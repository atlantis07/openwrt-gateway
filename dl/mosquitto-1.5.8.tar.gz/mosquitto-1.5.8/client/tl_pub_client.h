#ifndef _TL_PUB_H
#define _TL_PUB_H
pthread_mutex_t tl_pub_mutex_lock;

#define HEADER_LEN 16
typedef struct pubinfo{
	char header[HEADER_LEN];

}PUBINFO;

typedef struct _pub_queue
{
	struct pubinfo pinfo;
	struct _pub_queue *prev;
	struct _pub_queue *next;
}PUB_QUEUE;

int tl_pub_init();
void tl_pub_print();
#endif
