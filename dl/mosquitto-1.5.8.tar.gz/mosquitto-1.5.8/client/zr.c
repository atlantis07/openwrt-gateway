#include "zr.h"
#include "serial.h"
#include "common.h"
#include "crc.h"
#include "timer.h"
#include <time.h>

int zr_reboot(){
	DEVZR_T pkt;
	memset(&pkt, 0, DEVZR_T_LEN);
	pkt.h[0] = 0xfe;
	pkt.h[1] = 0xfd;
	pkt.t[0] = 0xef;
	pkt.t[1] = 0xdf;
	
	pkt.dt = DEV_ZR;
	
	pkt.type = TYPE_ZR_REBOOT;
	pkt.datalen = 1;
	pkt.status = 1;
	unsigned short crc = crc16tablefast((unsigned char *)&pkt, DEVZR_T_LEN - 4);
	pkt.crc[0] = crc & 0xff;
	pkt.crc[1] = crc >> 8;
	int ret = sendto_zigbee((unsigned char *)&pkt, DEVZR_T_LEN);
	if(ret < 0){
		return -1;
	}
	return 0;
}
	
int zr_config_network(char *data){
	DEVZR_T pkt;
	memset(&pkt, 0, DEVZR_T_LEN);
	pkt.h[0] = 0xfe;
	pkt.h[1] = 0xfd;
	pkt.t[0] = 0xef;
	pkt.t[1] = 0xdf;
	
	pkt.dt = DEV_ZR;
		
	if(!strcmp(data, "ON") || !strcmp(data, "OFF")){
		pkt.type = TYPE_ZR_NETWORK;
		pkt.datalen = 1;
		pkt.status = (!strcmp("ON", data))?1:0;
		unsigned short crc = crc16tablefast((unsigned char *)&pkt, DEVZR_T_LEN - 4);
		pkt.crc[0] = crc & 0xff;
		pkt.crc[1] = crc >> 8;
		int ret = sendto_zigbee((unsigned char *)&pkt, DEVZR_T_LEN);
		if(ret < 0){
			return -1;
		}
	}
	else{
		int timeval = 0;
		int ret = sscanf(data, "%d", &timeval);
		if(ret == 1){
			if((timeval > ZR_MIN_NETWORK_DISABLE) && (timeval <= ZR_MAX_NETWORK_DISABLE)){
				time_t now;
				time(&now);
				zr_timer_netoff = timeval + now;
			}			
		}
	}
	return 0;
}

int zr_delay_off_work(){
	DEVZR_T pkt;
	memset(&pkt, 0, DEVZR_T_LEN);
	pkt.h[0] = 0xfe;
	pkt.h[1] = 0xfd;
	pkt.t[0] = 0xef;
	pkt.t[1] = 0xdf;
	
	pkt.dt = DEV_ZR;
	pkt.type = TYPE_ZR_NETWORK;
	pkt.datalen = 1;
	pkt.status = 0;
	unsigned short crc = crc16tablefast((unsigned char *)&pkt, DEVZR_T_LEN - 4);
	pkt.crc[0] = crc & 0xff;
	pkt.crc[1] = crc >> 8;
	int ret = sendto_zigbee((unsigned char *)&pkt, DEVZR_T_LEN);
	if(ret < 0){
		return -1;
	}
}

int write_to_zr(unsigned char id, char *cmd, char *data){
	if(!cmd || !data){
		return -1;
	}


	if(!strcmp(cmd, "reboot")){
		//pkt.type = TYPE_ZR_REBOOT;
		zr_reboot();
	}
	else if(!strcmp(cmd, "network")){
		tl_printf(MSG_INFO, "zr network");
		zr_config_network(data);
	}
	else{
		return -1;
	}
	return 0;
}

