#include "cJSON.h"
#include "cJSON_Utils.h"
#include "mqttc.h"
#include "serial.h"
#include "node.h"
#include "switch.h"
#include "air_condition.h"
#include "scene.h"

int tanklight_getreginfo(char *tkreginfo, TANKLIGHT_REGINFO *reginfo, unsigned char *switch_num, 
		unsigned char *switch_status, unsigned char *cli, char *cli_series){
	cJSON *json = NULL, *arrayItem = NULL;
	json = cJSON_Parse(tkreginfo);
	if(!json){
		tl_printf(MSG_INFO,"tk reginfo is not json format\n");
		return -1;
	}

	cJSON *switch_way = cJSON_GetObjectItemCaseSensitive(json, "switch");
	cJSON *switchstatus = cJSON_GetObjectItemCaseSensitive(json, "status");
	cJSON *climate_series = cJSON_GetObjectItemCaseSensitive(json, "climate");
	cJSON *climate_addr = cJSON_GetObjectItemCaseSensitive(json, "climate_addr");

	if(cJSON_IsNumber(switch_way)){
		unsigned char sw = switch_way->valuedouble;
		*switch_num = sw;
		tl_printf(MSG_INFO,"switch number:%d \n", *switch_num);
	}

	if(cJSON_IsString(switchstatus)){
		int ret = sscanf(switchstatus->valuestring, "%02x", switch_status);
		if(ret != 1){
			tl_printf(MSG_ERROR, "switch status failed\n");
		}
		tl_printf(MSG_INFO,"switch status:%02x \n", *switch_status);
	}

	if(cJSON_IsString(climate_series) && (climate_series->valuestring != NULL)){
		memcpy(reginfo->climate_series, climate_series->valuestring, strlen(climate_series->valuestring));
		tl_printf(MSG_INFO,"climate series:%s\n", reginfo->climate_series);
		memcpy(cli_series, climate_series->valuestring, strlen(climate_series->valuestring));
		*cli += 1;
	}

	if(cJSON_IsNumber(climate_addr)){
		unsigned short _climate_addr = climate_addr->valuedouble;
		unsigned char __climate_addr[2];
		__climate_addr[0] = _climate_addr >> 8;
		__climate_addr[1] = _climate_addr & 0xff;

		tl_printf(MSG_INFO,"climate addr:%02x %02x\n", __climate_addr[0], __climate_addr[1]);
		memcpy(reginfo->climate_addr, &__climate_addr, sizeof(__climate_addr));
		*cli += 1;
	}

	cJSON_Delete(json);
	return 0;
json_end:
	cJSON_Delete(json);
	return -1;
}

int tanklight_control(char* topic, char* message){
	if(!topic || !message){
		return -1;
	}
	
	int status = 0;
	cJSON *json = NULL, *arrayItem = NULL;
	json = cJSON_Parse(message);
	if(!json){
		tl_printf(MSG_INFO,"[error] %s\n", message);
		status = PARAM_ERROR;
		goto end;
	}

	cJSON *header = cJSON_GetObjectItemCaseSensitive(json, "header");
	cJSON *payload = cJSON_GetObjectItemCaseSensitive(json, "payload");
	if(!header || !payload){
		tl_printf(MSG_INFO,"Header or Payload is null\n");
		status = PARAM_ERROR;
		goto end;
	}

	cJSON *name = cJSON_GetObjectItemCaseSensitive(header, "name");
	if(!cJSON_IsString(name) || (!name->valuestring)){
		tl_printf(MSG_INFO,"Name is not string or null\n");
		status = PARAM_ERROR;
		goto end;
	}

	if(strstr(name->valuestring, SCENEHEAD)){
		scene_exec(name->valuestring, payload);
	}

end:
	cJSON_Delete(json);
	return status;
}
