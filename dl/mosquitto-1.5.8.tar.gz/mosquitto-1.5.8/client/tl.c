#include "cJSON.h"
#include "cJSON_Utils.h"
#include "mqttc.h"
#include "serial.h"
#include "node.h"
#include "switch.h"
#include "air_condition.h"
#include "scene.h"
#include "frequency.h"
#include "tl.h"

int tanklight_getreginfo(char *tkreginfo, SWITCH_REG_INFO* switch_reg, AC_REG_INFO *ac_reg){
	cJSON *json = NULL, *arrayItem = NULL;
	json = cJSON_Parse(tkreginfo);
	if(!json){
		tl_printf(MSG_INFO,"tk reginfo is not json format\n");
		return -1;
	}

	cJSON *switchway = cJSON_GetObjectItemCaseSensitive(json, "switch");
	cJSON *switchstatus = cJSON_GetObjectItemCaseSensitive(json, "status");
	cJSON *switchmode = cJSON_GetObjectItemCaseSensitive(json, "mode");
	cJSON *switchscene1 = cJSON_GetObjectItemCaseSensitive(json, "switch1");
	cJSON *switchscene2 = cJSON_GetObjectItemCaseSensitive(json, "switch2");
	cJSON *switchscene3 = cJSON_GetObjectItemCaseSensitive(json, "switch3");
	cJSON *switchscene4 = cJSON_GetObjectItemCaseSensitive(json, "switch4");
	
	cJSON *acseries = cJSON_GetObjectItemCaseSensitive(json, "climate");
	cJSON *acaddr = cJSON_GetObjectItemCaseSensitive(json, "climate_addr");

	/*****************************switch*************************/
	if(cJSON_IsNumber(switchway)){
		switch_reg->switch_num = switchway->valuedouble;
		tl_printf(MSG_INFO,"switch number:%d \n", switch_reg->switch_num);
	}

	if(cJSON_IsString(switchstatus)){
		int ret = sscanf(switchstatus->valuestring, "%02x", &switch_reg->switch_status);
		if(ret != 1){
			tl_printf(MSG_ERROR, "switch status failed\n");
		}
		else{
			tl_printf(MSG_INFO,"switch status:%02x \n", switch_reg->switch_status);
		}
	}

	if(cJSON_IsString(switchmode) && (switchmode->valuestring != NULL)){
		int ret = sscanf(switchmode->valuestring, "%s", switch_reg->switch_scene.switch_mode);
		if(ret != 1){
			tl_printf(MSG_ERROR, "switch mode failed\n");
		}
		else{
			tl_printf(MSG_INFO,"switch mode:%s \n", switch_reg->switch_scene.switch_mode);
		}
	}

	if(cJSON_IsString(switchscene1) && (switchscene1->valuestring != NULL)){
		int ret = sscanf(switchscene1->valuestring, "%s", switch_reg->switch_scene.switch_scene1);
		if(ret != 1){
			tl_printf(MSG_ERROR, "switch scene1 failed\n");
		}
		else{
			tl_printf(MSG_INFO,"switch scene1:%s \n", switch_reg->switch_scene.switch_scene1);
		}
	}

	if(cJSON_IsString(switchscene2) && (switchscene2->valuestring != NULL)){
		int ret = sscanf(switchscene2->valuestring, "%s", switch_reg->switch_scene.switch_scene2);
		if(ret != 1){
			tl_printf(MSG_ERROR, "switch scene2 failed\n");
		}
		else{
			tl_printf(MSG_INFO,"switch scene2:%s \n", switch_reg->switch_scene.switch_scene2);
		}
	}

	if(cJSON_IsString(switchscene3) && (switchscene3->valuestring != NULL)){
		int ret = sscanf(switchscene3->valuestring, "%s", switch_reg->switch_scene.switch_scene3);
		if(ret != 1){
			tl_printf(MSG_ERROR, "switch scene3 failed\n");
		}
		else{
			tl_printf(MSG_INFO,"switch scene3:%s \n", switch_reg->switch_scene.switch_scene3);
		}
	}

	if(cJSON_IsString(switchscene4) && (switchscene4->valuestring != NULL)){
		int ret = sscanf(switchscene4->valuestring, "%s", switch_reg->switch_scene.switch_scene4);
		if(ret != 1){
			tl_printf(MSG_ERROR, "switch scene4 failed\n");
		}
		else{
			tl_printf(MSG_INFO,"switch scene4:%s \n", switch_reg->switch_scene.switch_scene4);
		}
	}

	/*****************************AC*************************/
	if(cJSON_IsString(acseries) && (acseries->valuestring != NULL)){
		int ret = sscanf(acseries->valuestring, "%s", ac_reg->series);
		if(ret != 1){
			tl_printf(MSG_ERROR, "ac series failed\n");
		}
		else{
			tl_printf(MSG_INFO,"ac series: %s ", ac_reg->series);
		}
	}

	if(cJSON_IsNumber(acaddr)){
		ac_reg->addr = acaddr->valuedouble;
		tl_printf(MSG_INFO,"ac addr:%hx", ac_reg->addr);
	}

	cJSON_Delete(json);
	return 0;
json_end:
	cJSON_Delete(json);
	return -1;
}

int tanklight_control(char* topic, char* message){
	if(!topic || !message){
		return -1;
	}
	
	int status = 0;
	cJSON *json = NULL, *arrayItem = NULL;
	json = cJSON_Parse(message);
	if(!json){
		tl_printf(MSG_INFO,"[error] %s\n", message);
		status = PARAM_ERROR;
		goto end;
	}

	cJSON *header = cJSON_GetObjectItemCaseSensitive(json, "Header");
	cJSON *payload = cJSON_GetObjectItemCaseSensitive(json, "Payload");
	if(!header || !payload){
		tl_printf(MSG_INFO,"Header or Payload is null\n");
		status = PARAM_ERROR;
		goto end;
	}

	cJSON *name = cJSON_GetObjectItemCaseSensitive(header, "Name");
	if(!cJSON_IsString(name) || (!name->valuestring)){
		tl_printf(MSG_INFO,"Name is not string or null\n");
		status = PARAM_ERROR;
		goto end;
	}

	if(strstr(name->valuestring, SCENEHEAD)){
		scene_exec(name->valuestring, payload);
	}
	else if (strstr(name->valuestring, FREQHEAD)){
		send_freq(name->valuestring, payload);
	}

end:
	cJSON_Delete(json);
	return status;
}
