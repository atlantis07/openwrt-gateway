#ifndef _SWITCH_H
#define _SWITCH_H

#define WRITE_OK			(0)
#define OPEN_DEVICE_ERROR	(-1)
#define SET_DEVICE_ERROR	(-1)
#define WRITE_DEVICE_ERROR	(-2)
#define PARAM_ERROR			(-3)
int sendto_zigbee(unsigned char *data, int data_len);
int recvfrom_zigbee(void);

int write_to_switch(unsigned char *message, unsigned int message_len, int times, int num, unsigned char target);
int request_mac(char *type, unsigned char *mac, int len);

int write_to_climate(char *gwaddr, char *type, char* payload, char *host, char *series, unsigned char *addr, int addrlen);

#endif
