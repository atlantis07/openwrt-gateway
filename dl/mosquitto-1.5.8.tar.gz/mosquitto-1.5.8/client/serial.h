#ifndef _SERIAL_H
#define _SERIAL_H

int sendto_zigbee(unsigned char *data, int data_len);
int recvfrom_zigbee(void);

int write_to_switch(unsigned char *message, unsigned int message_len, int times, int num, unsigned char target);
int request_mac(char *type, unsigned char *mac, int len);

int write_to_climate(char *gwaddr, char *type, char* payload, int payloadlen, char *host, char *series, unsigned char *addr, int addrlen);

#define MAX_SEND_ZIEGBEE_TIME 20
#endif
