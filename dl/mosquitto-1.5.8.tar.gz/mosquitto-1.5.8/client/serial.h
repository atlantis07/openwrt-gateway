#ifndef _SWITCH_H
#define _SWITCH_H

#define WRITE_DEVICE_ERROR	(-2)
int zfd;
int recvfrom_switch(void);
int write_to_switch(unsigned char *message, unsigned int message_len, int times, int num, unsigned char target);
int request_mac(char *type, unsigned char *mac, int len);
int query_climate(int fd, unsigned char* res);
int write_for_status(int fd, unsigned char *data, int datalen);
void update_climate(int fd, char *type);
#endif
