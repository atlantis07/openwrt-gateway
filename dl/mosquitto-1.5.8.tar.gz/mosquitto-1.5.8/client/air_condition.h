#ifndef _AIR_H
#define _AIR_H

#include "air_condition.h"
#include "common.h"

#define AIR_ADDR_LEN 2
#define AIR_STATUS_LEN 8

typedef struct airinfo{
	unsigned char addr[AIR_ADDR_LEN];
	unsigned char status[AIR_STATUS_LEN];
}AIR_INFO;

typedef struct air_node{
	AIR_INFO ainfo;
	struct air_node *prev;
	struct air_node *next;
}AIR_NODE;


#endif
