#ifndef _AIR_H
#define _AIR_H

#include <pthread.h>
#include "common.h"

/******************************************FANGWEI**************************************/
#define MIN_FANGWEI_TOPIC 35
#define FANGWEI_ADDR_LEN 2
#define AIR_ADDR_POS_FANGWEI 29



/******************************************INFRARED**************************************/
#define MIN_INFRARED_TOPIC 36
#define AIR_ADDR_POS_INFRARED 30
#define INFRARED_CMD_LEN 15
#define INFRARED_POWER		0x04
#define INFRARED_MODE		0x05 //00 auto 01 cool 02 dry 03 fan_only 04 heat
#define INFRARED_TEMP_SET 	0x06
#define INFRARED_FAN_SET	0x07
#define INFRARED_SWING_SET	0x08

#define AIR_INFRARED_MAX_TEMP 31
#define AIR_INFRARED_MIN_TEMP 16

#define INFRARED_MODE_AUTO				0x00
#define INFRARED_MODE_COOL				0x01
#define INFRARED_MODE_DEHUMIDIFICATION	0x02
#define INFRARED_MODE_FAN				0x03
#define INFRARED_MODE_HEAT				0x04

#define INFRARED_FAN_AUTO				0x00
#define INFRARED_FAN_LOW				0x01
#define INFRARED_FAN_MIDDLE				0x02
#define INFRARED_FAN_HIGH				0x03
/********************************************END****************************************/

//37 + 16
//0xfe 0xfd devtype type  len nodeaddr a1 33 10 00 00 15 00 5c crc1 crc2 0xef 0xef 0xdf
//#define TYPE_POS 3
//#define LEN_POS 4
#define NODEADDR_POS 5 
#define DATA_POS 7
#define IDL_POS 8
#define HDL_POS 9

#define AIR_ADDR_LEN 2
#define AIR_STATUS_LEN 8

#define AIR_SERIES_LEN 32

#define AIR_EXIST 0
#define AIR_NOT_EXIST 1
typedef struct ac_reg_info{
    char series[AIR_SERIES_LEN];
    unsigned short addr;
}AC_REG_INFO;

typedef struct airinfo{
//	unsigned char s_macaddr[S_MACADDR_LEN];
	unsigned char macaddr[MACADDR_LEN];
	unsigned char addr[AIR_ADDR_LEN];
	char series[AIR_SERIES_LEN];
	int on;
	int mode;
	int fan;
	int temperature;
	unsigned char status[AIR_STATUS_LEN];
	int is_update;
}AIR_INFO;

#define AIR_INFO_LEN sizeof(AIR_INFO)


typedef struct air_node{
	AIR_INFO ainfo;
	struct air_node *prev;
	struct air_node *next;
}AIR_NODE;
#define AIR_NODE_LEN sizeof(AIR_NODE)

#define AIR_HEAD_LEN 2
#define AIR_PASS_DATA_LEN 8
#define AIR_PASS_DATA_MAX 200
#define AIR_PASS_CRC_LEN 2
#define AIR_TAIL_LEN AIR_HEAD_LEN



#define AIR_QUERY_DATALEN	8
typedef struct air_pass{
	unsigned char h[AIR_HEAD_LEN];
	unsigned char dt;
	unsigned char type;
	unsigned char data_len;
	unsigned char s_macaddr[S_MACADDR_LEN];
	unsigned char data[AIR_PASS_DATA_LEN];
	unsigned char crc[AIR_PASS_CRC_LEN];
	unsigned char t[AIR_TAIL_LEN];
}AIR_PASS_PKT;


pthread_mutex_t air_mutex_lock;

int air_init(void);
void air_free(void);
int air_insert_tail(AIR_INFO airinfo);
AIR_NODE *find_air_node(unsigned char *addr);
int ait_condition_is_exist(unsigned char *addr);
void *air_passthrough_pthread(void *arg);
void *air_init_pthread(void *arg);
int query_climate(unsigned char* res, char *series, unsigned char *addr, int addrlen);
void update_climate(unsigned char *gwaddr, char *series, char *host, unsigned char *addr, int addrlen);
void airnode_action(char *type);
void air_passpkt_init(AIR_PASS_PKT *apkt, unsigned char *data, unsigned char datalen, unsigned char *devaddr);
int air_final_init(unsigned char *macaddr, AC_REG_INFO ac_reg);
#endif
