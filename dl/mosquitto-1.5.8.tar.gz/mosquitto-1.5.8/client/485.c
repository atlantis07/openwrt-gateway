#include "common.h"
#include "485.h"
#include "serial.h"
#include "crc.h"
#include "mqttc.h"
int write_to_485(int id, char *cmd, char *data){
	if(!cmd || !data){
		return -1;
	}
	int ret = 0;
	if(!strcmp(cmd, "set")){
		int status = !strcmp(data, ON)?1:0;
		DEV485_T pkt;
		memset(&pkt, 0, DEV485_T_LEN);

		pkt.h[0] = 0xfe;
		pkt.h[1] = 0xfd;
		pkt.t[0] = 0xef;
		pkt.t[1] = 0xdf;

		pkt.dt = DEV_485;
		pkt.type = TYPE_485_LIGHT;
		pkt.action = DEV485_SET;
		pkt.datalen = 2;
		pkt.id = 0x15;
		pkt.status = status;
		unsigned short crc = crc16tablefast((unsigned char *)&pkt, DEV485_T_LEN - 4);
		pkt.crc[0] = crc & 0xff;
		pkt.crc[1] = crc >> 8;
		int ret = sendto_zigbee((unsigned char *)&pkt, DEV485_T_LEN);
		if(ret < 0){
			return -1;
		}
	}
	return 0;
}
