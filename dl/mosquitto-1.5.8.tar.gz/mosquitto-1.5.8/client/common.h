#ifndef _COMMON_H
#define _COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <stdbool.h>
#define _GNU_SOURCE             /* See feature_test_macros(7) */
#define __USE_GNU
//#include <sys/socket.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <netdb.h>
#include <fcntl.h>
#include <errno.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <poll.h> 
#include <sys/epoll.h>
#include <pthread.h>
#include <ctype.h>
#include <stdbool.h>
#include <assert.h>

#include "debug.h"


#define SERVER_PORT	8001

#define GWMACADDR_LEN 16
#define IP_LEN 16
#define	BUF_LEN 1024 

#define ZIGBEE_DEV "/dev/ttyS1"
#define BAUD 9600

typedef unsigned char u8_t;
typedef unsigned short u16_t;
typedef unsigned int u32_t;

#define PKT_HEAD 1  
#define PKT_TAIL 2
#define MIN_PKT_LEN 5

#define PKT_INIT_LEN 23
#define PKT_HEARTBEAT_LEN 11

#define TYPE_SWITCH             (1)
#define TYPE_AIRCONDITION       (2)
#define TYPE_MACERROR			(0xf)
#define TYPE_UNKNOWN            (-1)

//0xf.
#define NODE_INIT				(2)
#define NODE_HEARTBEAT			(8)

//0x1.
#define SWITCH_INIT             (1)
#define SWITCH_STATUS           (2)
#define SWITCH_SET_STATUS       (3)
#define SWITCH_UNKNOWN_SHORTMAC (4)
#define SWITCH_UNKNOWN_MAC      (5)

//0x2.
#define AIRCONDITION            (1)
#define AIRCONDITION_SENDTO     (2)
#define AIRCONDITION_RECVFROM   (3)

#define PARAM_NOT_EXIST     (-1)


//LEN
#define HEAD_LEN    2
#define PARENT_LEN  2
#define S_MACADDR_LEN   2
#define MACADDR_LEN 8
#define CRC_LEN     2
#define TAIL_LEN    2


//POS
//#define INIT_MACADDR_POS	10
//0xf.
#define INIT_SMACADDR_POS	4
#define INIT_MACADDR_POS	6
#define REINIT_SMACADDR_POS	8
#define REINIT_MACADDR_POS	10

#define HEARTBEAT_ADDR_POS 4
#define HEARTBEAT_SIG_POS 6

int check_type(unsigned char pkt);
int check_action(unsigned char pkt);
char gwmacaddr[GWMACADDR_LEN];
char serveripaddr[IP_LEN];

#define GW_ADDR_LEN	16

#define DEV_MAC_LEN 24

#define LEN32 32
#define LEN64 64
#define LEN128 128
#define LEN256 256
#define LEN512 512

#define WRITE_OK            (0)
#define OPEN_DEVICE_ERROR   (-1)
#define SET_DEVICE_ERROR    (-1)
#define WRITE_DEVICE_ERROR  (-2)
#define PARAM_ERROR         (-3)

int tl_pub(int argc, char *argv[]);
#endif
