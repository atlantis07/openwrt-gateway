#include "common.h"
#include "epoll.h"
#include "cJSON.h"
#include "node.h"
#include "parse.h"
#include "timer.h"
#include "serial.h"
#include "dev.h"
#include <pthread.h>
#include "air_condition.h"

#if 0
ai_family	
AF_INET		2		IPv4
AF_INET6	23		IPv6
AF_UNSPEC	0		协议无关

ai_protocol
IPPROTO_IP		0	IP协议
IPPROTO_IPV4	4	IPv4
IPPROTO_IPV6	41	IPv6
IPPROTO_UDP		17	UDP
IPPROTO_TCP		6	TCP

ai_socktype
SOCK_STREAM		1	流
SOCK_DGRAM		2	数据报

ai_flags
AI_PASSIVE		1	被动的，用于bind，通常用于server socket
AI_CANONNAME	2	用于返回主机的规范名称
AI_NUMERICHOST	4	地址为数字串
#endif

#define HOST "129.204.22.34"
#define IP6HOST "::1"
#define PORT "9090"

int connect_to_server(const char *host, const char *port){
	int fd;
	//	struct sockaddr_in;
	struct addrinfo hints, *ai, *res;

	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET; 
	hints.ai_protocol = IPPROTO_TCP;
	hints.ai_socktype = SOCK_STREAM;

	if(getaddrinfo(host, port, &hints, &res)){
		printf("name lookup %s:%s failed %s", host, port, strerror(errno));
		return -1;
	}

	for (ai = res; ai != NULL; ai = ai->ai_next) {
		fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
		if(fd < 0){
			printf("fd < 0\n");
			continue;
		}

		if (connect(fd, ai->ai_addr, ai->ai_addrlen)) {
			close(fd);
			fd = -1;
			continue;
		}
		//printf("ai family:%d,", ai->ai_family);
		//printf("ai protocol:%d,", ai->ai_protocol);
		//printf("ai socket type:%d\n", ai->ai_socktype);
	}
	return fd;
}

unsigned char testmac[] = {0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};
unsigned char dpkt1[] = {0xfe, 0xfd,							/*HEAD*/
						0x1,									/*TYPE*/
						0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0xff, 0xf1,		/*MACADDR*/
						0x35,									/*STATUS*/
						0x51, 0x52,								/*CRC MODBUS*/
						0xef, 0xdf};							/*TAIL*/

unsigned char dpkt2[] = {
						0xfe, 0xfd,							/*HEAD*/
						0x1,									/*TYPE*/
						0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0xff, 0xf1,		/*MACADDR*/
						0x1,									/*STATUS*/
						0x51, 0x52,								/*CRC MODBUS*/
						0xef, 0xdf,							/*TAIL*/
						0xfe, 0xfd,							/*HEAD*/
						0x1,									/*TYPE*/
						0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0xff, 0xf2,		/*MACADDR*/
						0x1,									/*STATUS*/
						0x51, 0x52,								/*CRC MODBUS*/
						0xef, 0xdf
					};							/*TAIL*/

int main(int argc, char** argv){

#if 0
	int fd;

	fd = connect_to_server(HOST, PORT);
	if(fd < 0){
		printf("connect server err:%s\n", strerror(fd));
		return -1;
	}
	printf("connect OK\n");
#endif

//switch table
	int head_init = node_init();
	if(head_init){
		return 0;
	}
	pthread_mutex_init(&mutex_lock,NULL);
//ait condition table;
	int airinit = air_init();
	if(airinit){
		return 0;
	}


//timer
	t_flag = 1;
	pthread_t t_pid;
	pthread_attr_t t_attr;
	pthread_attr_init(&t_attr);
	pthread_attr_setdetachstate(&t_attr, PTHREAD_CREATE_JOINABLE);
	int t_ret = pthread_create(&t_pid, &t_attr, setTimer, NULL);
	if(t_ret){
		perror("create timer");
		return 0;
	}

	printf("init timer success\n");
#if 1
	pthread_t cmd_pid;
	pthread_attr_t cmd_attr;
	pthread_attr_init(&cmd_attr);
	pthread_attr_setdetachstate(&cmd_attr, PTHREAD_CREATE_DETACHED);
	
	RECV_PARAM param;
	param.argc = argc;
	param.argv = argv;

	int cmd_ret = pthread_create(&cmd_pid, &cmd_attr, pthread_recv, (void *)&param);
	if(cmd_ret){
		perror("recv");
		return 0;
	}
#else
	printf("init recv success\n");
	recvfrom_switch();
#endif
	while(1)
		sleep(60);
exit:
	t_flag = 0;
	pthread_join(t_pid, NULL);
	node_action("free", NULL);
	return 0;
}
