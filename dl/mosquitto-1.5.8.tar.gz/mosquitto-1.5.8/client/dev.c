#include "common.h"
#include "epoll.h"
#include "cJSON.h"
#include "node.h"
#include "parse.h"
#include "timer.h"
#include "air_condition.h"
#include "ha_client.h"
#include "serial.h"
#include "dev.h"
#include "uci.h"

#include <pthread.h>
#include <stdbool.h>
#include <uci.h>
#include <uci_blob.h>


#if 0
ai_family	
AF_INET		2		IPv4
AF_INET6	23		IPv6
AF_UNSPEC	0		协议无关

ai_protocol
IPPROTO_IP		0	IP协议
IPPROTO_IPV4	4	IPv4
IPPROTO_IPV6	41	IPv6
IPPROTO_UDP		17	UDP
IPPROTO_TCP		6	TCP

ai_socktype
SOCK_STREAM		1	流
SOCK_DGRAM		2	数据报

ai_flags
AI_PASSIVE		1	被动的，用于bind，通常用于server socket
AI_CANONNAME	2	用于返回主机的规范名称
AI_NUMERICHOST	4	地址为数字串

int fd;

fd = connect_to_server(HOST, PORT);
if(fd < 0){
	printf("connect server err:%s\n", strerror(fd));
	return -1;
}
printf("connect OK\n");

#define HOST "129.204.22.34"
#define IP6HOST "::1"
#define PORT "9090"
#endif

#if 0
int connect_to_server(const char *host, const char *port){
	int fd;
	//	struct sockaddr_in;
	struct addrinfo hints, *ai, *res;

	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET; 
	hints.ai_protocol = IPPROTO_TCP;
	hints.ai_socktype = SOCK_STREAM;

	if(getaddrinfo(host, port, &hints, &res)){
		printf("name lookup %s:%s failed %s", host, port, strerror(errno));
		return -1;
	}

	for (ai = res; ai != NULL; ai = ai->ai_next) {
		fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
		if(fd < 0){
			printf("fd < 0\n");
			continue;
		}

		if (connect(fd, ai->ai_addr, ai->ai_addrlen)) {
			close(fd);
			fd = -1;
			continue;
		}
		//printf("ai family:%d,", ai->ai_family);
		//printf("ai protocol:%d,", ai->ai_protocol);
		//printf("ai socket type:%d\n", ai->ai_socktype);
	}
	return fd;
}
#endif

#if 0
unsigned char testmac[] = {0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff};
unsigned char dpkt1[] = {0xfe, 0xfd,							/*HEAD*/
						0x1,									/*TYPE*/
						0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0xff, 0xf1,		/*MACADDR*/
						0x35,									/*STATUS*/
						0x51, 0x52,								/*CRC MODBUS*/
						0xef, 0xdf};							/*TAIL*/

unsigned char dpkt2[] = {
						0xfe, 0xfd,							/*HEAD*/
						0x1,									/*TYPE*/
						0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0xff, 0xf1,		/*MACADDR*/
						0x1,									/*STATUS*/
						0x51, 0x52,								/*CRC MODBUS*/
						0xef, 0xdf,							/*TAIL*/
						0xfe, 0xfd,							/*HEAD*/
						0x1,									/*TYPE*/
						0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0xff, 0xf2,		/*MACADDR*/
						0x1,									/*STATUS*/
						0x51, 0x52,								/*CRC MODBUS*/
						0xef, 0xdf
					};							/*TAIL*/
#endif

int get_serveripaddr(int argc, char *argv[], char *ipaddr){
	for(int i = 0; i < argc; i++){
		if(!strcmp(argv[i], "-h")){
			if(i + 1 >= argc){
				return -1;
			}
			else{
				memcpy(ipaddr, argv[i+1], strlen(argv[i+1]));
				return 0;
			}
		}
	}
	return -1;
}
int main(int argc, char** argv){
	bool ret = uci_load_macaddr(gwmacaddr);
	if(ret == false){
		printf("gw macaddr is not exist\n");
		return 0;
	}
	else{
		printf("%s\n", gwmacaddr);
	}

//homeassistant server init
	memset(serveripaddr, 0, IP_LEN);
	int ha_init = get_serveripaddr(argc, argv, serveripaddr);
	if(ha_init){
		printf("ha init failed\n");
		return 0;
	}

//switch table
	int head_init = node_init();
	if(head_init){
		return 0;
	}
	pthread_mutex_init(&mutex_lock,NULL);
//ait condition table;
	int airinit = air_init();
	if(airinit){
		goto switch_exit;
	}
	pthread_mutex_init(&air_mutex_lock, NULL);
//timer
	t_flag = 1;
	pthread_t t_pid;
	pthread_attr_t t_attr;
	pthread_attr_init(&t_attr);
	pthread_attr_setdetachstate(&t_attr, PTHREAD_CREATE_JOINABLE);
	int t_ret = pthread_create(&t_pid, &t_attr, setTimer, NULL);
	pthread_attr_destroy(&t_attr);
	if(t_ret){
		perror("create timer");
		goto air_exit;
	}
	printf("init timer success\n");

//remote control thread
	pthread_t cmd_pid;
	pthread_attr_t cmd_attr;
	pthread_attr_init(&cmd_attr);
	pthread_attr_setdetachstate(&cmd_attr, PTHREAD_CREATE_DETACHED);
	
	RECV_PARAM param;
	param.argc = argc;
	param.argv = argv;

	int cmd_ret = pthread_create(&cmd_pid, &cmd_attr, pthread_recv, (void *)&param);
	pthread_attr_destroy(&cmd_attr);
	if(cmd_ret){
		perror("init recv thread");
		goto timer_exit;
	}
	
	printf("init recv thread success\n");

	recvfrom_zigbee();

timer_exit:
	t_flag = 0;
	pthread_join(t_pid, NULL);
air_exit:
switch_exit:
	node_action("free", NULL);
	return 0;
}
