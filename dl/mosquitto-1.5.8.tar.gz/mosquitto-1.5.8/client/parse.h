#ifndef _PARSE_H
#define _PARSE_H
int find_edge(unsigned char* pkt, unsigned int len, int type);
int parse_packets(unsigned char* pkt, unsigned int len);
#endif
