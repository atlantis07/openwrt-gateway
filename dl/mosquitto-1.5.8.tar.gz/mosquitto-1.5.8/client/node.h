#ifndef _NODE_H
#define _NODE_H
#include <stdbool.h>
#include "common.h"

#define NODE_EXIST 1
#define NODE_NOT_EXIST 0
typedef struct _ninfo{
	unsigned char s_macaddr[S_MACADDR_LEN];
	unsigned char macaddr[MACADDR_LEN];
	int reg;
	int signal;
}NODE_INFO;

typedef struct _node{
	NODE_INFO ninfo;
	struct node *prev;
	struct node *next;
}NODE;
pthread_mutex_t node_mutex_lock;

int node_init();
void node_action(char *type);
void *node_preinit(void *arg);
void *node_heartbeat(void *arg);
#endif
