#ifndef _NODE_H
#define _NODE_H
#include <stdbool.h>
#include "common.h"

#define NODE_EXIST 1
#define NODE_NOT_EXIST 0

#define NODE_MAX_TIMEOUT 60
typedef struct _ninfo{
	unsigned char s_macaddr[S_MACADDR_LEN];
	unsigned char macaddr[MACADDR_LEN];
	int timeout;
	int reg;
	int signal;
}NODE_INFO;

typedef struct _node{
	NODE_INFO ninfo;
	struct node *prev;
	struct node *next;
}NODE;
pthread_mutex_t node_mutex_lock;

int node_init();
void node_action(char *type);
void *node_preinit(void *arg);
int node_finalinit(unsigned char *macaddr);
void *node_heartbeat(void *arg);

#endif
