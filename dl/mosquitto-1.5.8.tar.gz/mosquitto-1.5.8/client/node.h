#ifndef _NODE_H
#define _NODE_H
#include <pthread.h>
#include "common.h"

#define TAIL_LEN	2

#define MACADDR_STRLEN 18
#define MAX_TIME 300

#define SHORTMAC_EXIST		(1)
#define SHORTMAC_NOT_EXIST	(0)
#define MAC_EXIST		SHORTMAC_EXIST
#define MAC_NOT_EXIST	SHORTMAC_NOT_EXIST
#define NODE_EXIST		SHORTMAC_EXIST
#define NODE_NOT_EXIST	SHORTMAC_NOT_EXIST
//type init
typedef struct init_dev_status_pkt {
	unsigned char h[HEAD_LEN];
//	unsigned char type;
//	unsigned char len;
//	unsigned char s[S_MACADDR_LEN];
	unsigned char parent[PARENT_LEN];
	unsigned char s_macaddr[S_MACADDR_LEN];
	unsigned char macaddr[MACADDR_LEN];
	unsigned char status;
	unsigned char crc[CRC_LEN];
	unsigned char t[TAIL_LEN];
}INIT_DPKT;
#define INIT_DEV_STATUS_PKT_LEN sizeof(INIT_DPKT)

//type 02
typedef struct dev_status_pkt {
	unsigned char h[HEAD_LEN];
	unsigned char type;
	unsigned char datalen;
	unsigned char s_macaddr[S_MACADDR_LEN];
	unsigned char status;
	unsigned char crc[CRC_LEN];
	unsigned char t[TAIL_LEN];
}DPKT;
#define DEV_STATUS_PKT_LEN sizeof(DPKT)

//type 03
typedef struct dev_single_cmd_pkt {
	unsigned char h[HEAD_LEN];
	unsigned char type;
	unsigned char datalen;
	unsigned char s_macaddr[S_MACADDR_LEN];
	unsigned char status;
	unsigned char crc[CRC_LEN];
	unsigned char t[TAIL_LEN];
}CMD_S_PKT;
#define DEV_SINGLE_CMD_PKT_LEN sizeof(CMD_S_PKT)

//type ff  for unknown macaddr or short macaddr
typedef struct req_init_pkt{
	unsigned char h[HEAD_LEN];
	unsigned char type;
	unsigned char datalen;
	unsigned char macaddr[MACADDR_LEN];
	unsigned char crc[CRC_LEN];
	unsigned char t[TAIL_LEN];
}REQ_INIT_PKT;
#define REQ_INIT_PKT_LEN sizeof(REQ_INIT_PKT)


pthread_mutex_t mutex_lock;

typedef struct nodeinfo{
	unsigned char s_macaddr[S_MACADDR_LEN];
	unsigned char macaddr[MACADDR_LEN];
	unsigned char status;
	unsigned char proc;
	unsigned char timeout;
}NODEINFO;

typedef struct node
{
	struct nodeinfo ninfo;
	struct node *prev;
	struct node *next;
}NODE;

int node_init();
int insert_tail(struct nodeinfo ninfo);

int find_node();
int find_full_mac_and_status(DPKT *dpkt, unsigned char *full_mac, unsigned char *status, unsigned char *proc);
int find_short_macaddr(INIT_DPKT *dpkt, unsigned char *short_mac);

void node_action(char *cmd, INIT_DPKT* dpkt);

void node_alarm(int num);

void *record_pthread(void *arg);
void *set_pthread(void *arg);
#endif
