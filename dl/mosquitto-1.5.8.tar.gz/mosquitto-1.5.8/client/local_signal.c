#include "common.h"
#include "local_signal.h"
void sigint_action(void){
	tl_printf(MSG_INFO, "smarthome exit\n");
	smarthome_exit = 1;
}

void signal_init(){
	signal(SIGINT, sigint_action);
	//signal(SIGKILL, sigint_action);
	signal(SIGTERM, sigint_action);
}
