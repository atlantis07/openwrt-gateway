#include "debug.h"
#include "stdio.h"

FILE *out_file = NULL; 

int tl_debug_level = MSG_INFO;
int tl_syslog = 1;
int tl_debug_timestamp = 1;

static int syslog_priority(int level)
{
	switch (level) {
		case MSG_MSGDUMP:
		case MSG_DEBUG:
			return LOG_DEBUG;
		case MSG_INFO:
			return LOG_NOTICE;
		case MSG_WARNING:
			return LOG_WARNING;
		case MSG_ERROR:
			return LOG_ERR;
	}   
	return LOG_INFO;
}

int tl_printf(int level, const char *format, ...)
{
	va_list args;

	va_start(args, format);
	//	vfprintf(fp, format, args);

	if(tl_syslog){
		vsyslog(syslog_priority(level), format, args);
	}

	va_end(args);
	return 0;
}

int tl_printf_array(char *prefix, unsigned char *pkt, int len){
	char* p = (char *)malloc(len * 3 + 1);
	memset(p, 0, len * 3 + 1);

	for(int i = 0;i < len; i++){
		char c = (pkt[i] & 0xf0) >> 4;
		char d = pkt[i] & 0xf;
		if( c >= 0xa){
			c = 'a' + (c - 0xa);
		}   
		else{
			c = '0' + (c - 0x0);
		}   

		if( d >= 0xa){
			d = 'a' + (d - 0xa);
		}   
		else{
			d = '0' + (d - 0x0);
		}   
		p[3*i] = c;
		p[3*i + 1] = d;
		p[3*i + 2] = ' ';
	}
	tl_printf(MSG_INFO, "%s %s", prefix, p); 
	free(p);
}
