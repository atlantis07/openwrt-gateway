#include "common.h"
#include "frequency.h"
#include "gpio_control_app.h"

int send_433(cJSON *payload){
	const cJSON *Appliances = cJSON_GetObjectItemCaseSensitive(payload, "Appliances");
	if(!Appliances || !cJSON_IsArray(Appliances)){
        tl_printf(MSG_ERROR,"Appliances is not Array\n");
        return PARAM_ERROR;
    }   


    const cJSON *appliance = NULL;
    cJSON_ArrayForEach(appliance, Appliances){	
		const cJSON *Series = cJSON_GetObjectItemCaseSensitive(appliance, "Series");
		if(!Series || !cJSON_IsString(Series)){
			tl_printf(MSG_ERROR, "Freq 433 Series error");
			return PARAM_ERROR;
		}

		if(!strcmp(Series->valuestring, "Curtain")){
			const cJSON *Brand = cJSON_GetObjectItemCaseSensitive(appliance, "Brand");
			const cJSON *Channel = cJSON_GetObjectItemCaseSensitive(appliance, "Channel");
			const cJSON *Action = cJSON_GetObjectItemCaseSensitive(appliance, "Action");
			if(!Brand || !cJSON_IsString(Brand)){
				tl_printf(MSG_ERROR, "Freq 433 Brand isn't defined");
				return PARAM_ERROR;
			}

			if(!Channel || !cJSON_IsNumber(Channel)){
				tl_printf(MSG_ERROR, "Freq 433 Channel isn't defined");
				return PARAM_ERROR;
			}

			if(!Action || !cJSON_IsString(Action)){
				tl_printf(MSG_ERROR, "Freq 433 Action isn't defined");
				return PARAM_ERROR;
			}
	
			unsigned char data[4] = {0};
			int datalen = 4;
	
			if (!strcmp(Brand->valuestring, DOOYA)){
				data[0] = DOOYA_433;
			}
			else{
				return PARAM_ERROR;
			}	

			data[1] = Channel->valuedouble;
	
			if(!strcmp(Action->valuestring, "UP")){
				data[2] = UP_433;
			}
			else if(!strcmp(Action->valuestring, "PAUSE")){
				data[2] = PAUSE_433;
			}
			else if(!strcmp(Action->valuestring, "DOWN")){
				data[2] = DOWN_433;
			}
			else if(!strcmp(Action->valuestring, "MATCH")){
				data[2] = MATCH_433;
			}
			else{
				return PARAM_ERROR;
			}
	
			gpio_set(data, datalen);
		}
	}
	
	return 0;
}

int send_freq(char *name, cJSON *payload){
	if(strstr(name, FREQ433)){
		send_433(payload);
	}
	return 0;
}
