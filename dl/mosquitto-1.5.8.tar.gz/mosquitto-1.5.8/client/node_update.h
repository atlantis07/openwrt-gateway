#ifndef _NODE_UPDATE_H
#define _NODE_UPDATE_H

#define ED_UPDATE_FILE "/root/client.zigbee"
#define ZR_UPDATE_FILE "/root/server.zigbee"

#define SERVER_UPDATE	0
#define CLIENT_UPDATE	1

#define SUCCESS                   0x00
#define FAILURE                   0x01
#define INVALIDPARAMETER          0x02

#define ZSuccess                    SUCCESS
#define ZFailure                    FAILURE
#define ZInvalidParameter           INVALIDPARAMETER

#define ZOtaAbort                   0x95
#define ZOtaImageInvalid            0x96
#define ZOtaWaitForData             0x97
#define ZOtaNoImageAvailable        0x98
#define ZOtaRequireMoreImage        0x99


typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;

typedef struct
{
  unsigned short manufacturer;
  unsigned short type;
  unsigned int version;
} zclOTA_FileID_t; //8



typedef struct
{
  unsigned char addrMode;
  unsigned short saddr;
  unsigned char endPoint;
  unsigned short panId;  // used for the INTER_PAN feature
}  afAddrType_t; //6

typedef struct
{
  uint8 status;
  zclOTA_FileID_t fileId;
  uint32 imageSize;
} zclOTA_QueryImageRspParams_t;

typedef struct
{
  zclOTA_FileID_t fileId;
  uint32 fileOffset;
  uint8 dataSize;
  uint8 *pData;
} imageBlockRspSuccess_t;

typedef struct
{
  uint32 currentTime;
  uint32 requestTime;
  uint16 blockReqDelay;
} imageBlockRspWait_t;

typedef union
{
  imageBlockRspSuccess_t success;
  imageBlockRspWait_t wait;
} imageBlockRsp_t;

typedef struct
{
  uint8 status;
  imageBlockRsp_t rsp;
} zclOTA_ImageBlockRspParams_t;

typedef struct 
{
	uint8 h[2];
	uint8 dt;
	uint8 type;
	uint8 len;
	uint8 proto;
	zclOTA_FileID_t f;
    afAddrType_t edev;
	uint8 opt;
	uint8 crc[2];
	uint8 t[2];
}NODE_NEXTIMG_REQ;
#define NODE_UPDATE_REQ_LEN sizeof(NODE_UPDATE_REQ)


typedef struct 
{
	uint8 h[2];
	uint8 dt;
	uint8 type;
	uint8 len;
	uint8 proto;
	zclOTA_FileID_t f;
    afAddrType_t edev;
	uint32 offset;
	uint8 reqlen;
	uint8 crc[2];
	uint8 t[2];
}NODE_BLOCK_REQ;
#define NODE_BLOCK_REQ_MAX_DATA_LEN 32

#define NODE_UPDATE_MIN 9

typedef struct{
	uint32 fileid;
	uint16 ver;
	uint16 headlen;
	uint16 filedctl;
	uint16 manufacturer;
	uint16 type;
	uint32 filever;
	uint16 stackver;
	uint8  headstring[32];
	uint32 imgsize;
}NODE_UPDATE_FILE_HEADER;
#define NODE_UPDATE_FILE_HEADER_LEN sizeof(NODE_UPDATE_FILE_HEADER)
void *node_update(void *arg);
int check_image(uint8 dt, NODE_UPDATE_FILE_HEADER *header);
int get_image(uint8 dt, uint32 offset, uint8 len, uint8 *data);
#endif
