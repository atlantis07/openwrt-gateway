#ifndef _H_FREQUENCY
#define _H_FREQUENCY

#include "cJSON.h"
#include "cJSON_Utils.h"


#define FREQHEAD "Freq"

#define FREQ433 "Freq433"

//series
#define DOOYA "DOOYA"
#define DOOYA_433 1

//action
#define UP_433      1
#define DOWN_433    2
#define PAUSE_433   3
#define MATCH_433	4

int send_freq(char *name, cJSON *payload);
#endif
