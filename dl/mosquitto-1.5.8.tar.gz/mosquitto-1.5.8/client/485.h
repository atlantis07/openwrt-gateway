#ifndef _485_H
#define _485_H
#define CMD485 "485"
#define DEV485LIGHT "light"

typedef struct
{
    unsigned char h[2];
    unsigned char dt; 
    unsigned char type;
    unsigned char action;
    unsigned char datalen;
	unsigned char id; 
    unsigned char status;
    unsigned char crc[2];
    unsigned char t[2];
}DEV485_T;

#define DEV485_T_LEN sizeof(DEV485_T)

int write_to_485(int id, char *cmd, char *data);
#endif
