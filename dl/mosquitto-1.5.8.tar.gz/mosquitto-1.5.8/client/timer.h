#ifndef _TIMER_H
#define _TIMER_H
#include <sys/time.h>
#include <sys/select.h>
#include <time.h>
#include <stdio.h>
#include <pthread.h>

//int t_flag;
#define TIMER_INTERVAL 1

#define TIMER_PRINT_ALL 30
time_t now;
time_t print_all_flag;
time_t zr_timer_netoff;

void* setTimer(void *arg);
#endif
