#ifndef _TIMER_H
#define _TIMER_H
#include <sys/time.h>
#include <sys/select.h>
#include <time.h>
#include <stdio.h>
#include <pthread.h>

//int t_flag;
#define TIMER_INTERVAL 20
void* setTimer(void *arg);
#endif
