#ifndef _SH_UCI_H
#define _SH_UCI_H
#define UCI_CONFIG_FILE "network"
#define DEV_CONFIG_FILE "smarthome"
#include <uci.h>
#define MAX_MACADDR		6	
#define MAX_SMACADDR	24
bool load_config(char *mac, int len);
bool uci_load_macaddr(char *mac);
#endif
