/*
   Copyright (c) 2009-2019 Roger Light <roger@atchoo.org>

   All rights reserved. This program and the accompanying materials
   are made available under the terms of the Eclipse Public License v1.0
   and Eclipse Distribution License v1.0 which accompany this distribution.

   The Eclipse Public License is available at
http://www.eclipse.org/legal/epl-v10.html
and the Eclipse Distribution License is available at
http://www.eclipse.org/org/documents/edl-v10.php.

Contributors:
Roger Light - initial implementation and documentation.
*/

#include "config.h"

#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifndef WIN32
#include <unistd.h>
#include <signal.h>
#else
#include <process.h>
#include <winsock2.h>
#define snprintf sprintf_s
#endif

#include <mosquitto.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "air_shared.h"

int fd485 = 0;

struct mosq_config subcfg, pubcfg;
struct mosquitto *submosq = NULL, *pubmosq = NULL;


/*pub*/
#define STATUS_CONNECTING 0
#define STATUS_CONNACK_RECVD 1
#define STATUS_WAITING 2
#define STATUS_DISCONNECTING 3
static char *pubtopic = NULL;
static char *pubmessage = NULL;
static long pubmsglen = 0;
static int pubqos = 0;
static int pubretain = 0;
static int pubmode = MSGMODE_NONE;
static int pubstatus = STATUS_CONNECTING;
static int pubmid_sent = 0;
static int publast_mid = -1;
static int publast_mid_sent = -1;
static bool pubconnected = true;
static char *pubusername = NULL;
static char *pubpassword = NULL;
static bool pubdisconnect_sent = false;
static bool pubquiet = false;

/**/
bool process_messages = true;
int msg_count = 0;

#ifndef WIN32
void my_signal_handler(int signum)
{
	if(signum == SIGALRM){
		process_messages = false;
		mosquitto_disconnect(submosq);
	}
}

void signal_int_handler(int signum)
{
	if(signum == SIGINT){
		mosquitto_destroy(submosq);
		mosquitto_lib_cleanup();
		client_config_cleanup(&subcfg);
		exit(0);
	}
}
#endif

void print_message(struct mosq_config *cfg, const struct mosquitto_message *message);


void sub_message_callback(struct mosquitto *mosq, void *obj, const struct mosquitto_message *message)
{
	struct mosq_config *cfg;
	int i;
	bool res;

	if(process_messages == false) return;

	assert(obj);
	cfg = (struct mosq_config *)obj;

	if(cfg->retained_only && !message->retain && process_messages){
		process_messages = false;
		mosquitto_disconnect(mosq);
		return;
	}

	if(message->retain && cfg->no_retain) return;
	if(cfg->filter_outs){
		for(i=0; i<cfg->filter_out_count; i++){
			mosquitto_topic_matches_sub(cfg->filter_outs[i], message->topic, &res);
			if(res) return;
		}
	}

	print_message(cfg, message);
	if(fd485){
		get_device_info(fd485);
	}

	if(cfg->msg_count>0){
		msg_count++;
		if(cfg->msg_count == msg_count){
			process_messages = false;
			mosquitto_disconnect(mosq);
		}
	}
}

void sub_connect_callback(struct mosquitto *mosq, void *obj, int result, int flags)
{
	int i;
	struct mosq_config *cfg;

	assert(obj);
	cfg = (struct mosq_config *)obj;

	if(!result){
		for(i=0; i<cfg->topic_count; i++){
			mosquitto_subscribe(mosq, NULL, cfg->topics[i], cfg->qos);
		}
		for(i=0; i<cfg->unsub_topic_count; i++){
			mosquitto_unsubscribe(mosq, NULL, cfg->unsub_topics[i]);
		}
	}else{
		if(result && !cfg->quiet){
			fprintf(stderr, "%s\n", mosquitto_connack_string(result));
		}
		mosquitto_disconnect(mosq);
	}
}

void pub_connect_callback(struct mosquitto *mosq, void *obj, int result)
{
	int rc = MOSQ_ERR_SUCCESS;

	if(!result){
		switch(pubmode){
			case MSGMODE_CMD:
			case MSGMODE_FILE:
			case MSGMODE_STDIN_FILE:
				rc = mosquitto_publish(mosq, &pubmid_sent, pubtopic, pubmsglen, pubmessage, pubqos, pubretain);
				break;
			case MSGMODE_NULL:
				rc = mosquitto_publish(mosq, &pubmid_sent, pubtopic, 0, NULL, pubqos, pubretain);
				break;
			case MSGMODE_STDIN_LINE:
				pubstatus = STATUS_CONNACK_RECVD;
				break;
		}
		if(rc){
			if(!pubquiet){
				switch(rc){
					case MOSQ_ERR_INVAL:
						fprintf(stderr, "Error: Invalid input. Does your topic contain '+' or '#'?\n");
						break;
					case MOSQ_ERR_NOMEM:
						fprintf(stderr, "Error: Out of memory when trying to publish message.\n");
						break;
					case MOSQ_ERR_NO_CONN:
						fprintf(stderr, "Error: Client not connected when trying to publish.\n");
						break;
					case MOSQ_ERR_PROTOCOL:
						fprintf(stderr, "Error: Protocol error when communicating with broker.\n");
						break;
					case MOSQ_ERR_PAYLOAD_SIZE:
						fprintf(stderr, "Error: Message payload is too large.\n");
						break;
				}
			}
			mosquitto_disconnect(mosq);
		}
	}else{
		if(result && !pubquiet){
			fprintf(stderr, "%s\n", mosquitto_connack_string(result));
		}
	}
}

void pub_disconnect_callback(struct mosquitto *mosq, void *obj, int rc)
{
	pubconnected = false;
}

void subscribe_callback(struct mosquitto *mosq, void *obj, int mid, int qos_count, const int *granted_qos)
{
	int i;
	struct mosq_config *cfg;

	assert(obj);
	cfg = (struct mosq_config *)obj;

	if(!cfg->quiet) printf("Subscribed (mid: %d): %d", mid, granted_qos[0]);
	for(i=1; i<qos_count; i++){
		if(!cfg->quiet) printf(", %d", granted_qos[i]);
	}
	if(!cfg->quiet) printf("\n");
}

void publish_callback(struct mosquitto *mosq, void *obj, int mid)
{
	publast_mid_sent = mid;
	if(pubmode == MSGMODE_STDIN_LINE){
		if(mid == publast_mid){
			mosquitto_disconnect(mosq);
			pubdisconnect_sent = true;
		}
	}else if(pubdisconnect_sent == false){
		mosquitto_disconnect(mosq);
		pubdisconnect_sent = true;
	}
}



void my_log_callback(struct mosquitto *mosq, void *obj, int level, const char *str)
{
	printf("%s\n", str);
}

void print_usage(void)
{
	int major, minor, revision;

	mosquitto_lib_version(&major, &minor, &revision);
	printf("air_control is a simple mqtt client that will subscribe to a set of topics and print all messages it receives.\n");
	//	printf("air_control version %s running on libmosquitto %d.%d.%d.\n\n", VERSION, major, minor, revision);
	printf("Usage: air_control {[-h host] [-p port] [-u username [-P password]] -ts subtopic -tp pubtopic}\n");
	printf("                     [-c] [-k keepalive] [-q qos]\n");
	printf("                     [-C msg_count] [-R] [--retained-only] [-T filter_out] [-U topic ...]\n");
	printf("                     [-F format]\n");
#ifndef WIN32
	printf("                     [-W timeout_secs]\n");
#endif
#ifdef WITH_SRV
	printf("                     [-A bind_address] [-S]\n");
#else
	printf("                     [-A bind_address]\n");
#endif
	printf("                     [-i id] [-I id_prefix]\n");
	printf("                     [-d] [-N] [--quiet] [-v]\n");
	printf("                     [--will-topic [--will-payload payload] [--will-qos qos] [--will-retain]]\n");
#ifdef WITH_TLS
	printf("                     [{--cafile file | --capath dir} [--cert file] [--key file]\n");
	printf("                      [--ciphers ciphers] [--insecure]]\n");
#ifdef FINAL_WITH_TLS_PSK
	printf("                     [--psk hex-key --psk-identity identity [--ciphers ciphers]]\n");
#endif
#endif
#ifdef WITH_SOCKS
	printf("                     [--proxy socks-url]\n");
#endif
	printf("       air_control --help\n\n");
	printf(" -A : bind the outgoing socket to this host/ip address. Use to control which interface\n");
	printf("      the client communicates over.\n");
	printf(" -c : disable 'clean session' (store subscription and pending messages when client disconnects).\n");
	printf(" -C : disconnect and exit after receiving the 'msg_count' messages.\n");
	printf(" -d : enable debug messages.\n");
	printf(" -F : output format.\n");
	printf(" -h : mqtt host to connect to. Defaults to localhost.\n");
	printf(" -i : id to use for this client. Defaults to air_control_ appended with the process id.\n");
	printf(" -I : define the client id as id_prefix appended with the process id. Useful for when the\n");
	printf("      broker is using the clientid_prefixes option.\n");
	printf(" -k : keep alive in seconds for this client. Defaults to 60.\n");
	printf(" -L : specify user, password, hostname, port and topic as a URL in the form:\n");
	printf("      mqtt(s)://[username[:password]@]host[:port]/topic\n");
	printf(" -N : do not add an end of line character when printing the payload.\n");
	printf(" -p : network port to connect to. Defaults to 1883 for plain MQTT and 8883 for MQTT over TLS.\n");
	printf(" -P : provide a password\n");
	printf(" -q : quality of service level to use for the subscription. Defaults to 0.\n");
	printf(" -R : do not print stale messages (those with retain set).\n");
#ifdef WITH_SRV
	printf(" -S : use SRV lookups to determine which host to connect to.\n");
#endif
	printf(" -ts : mqtt topic to subscribe to. May be repeated multiple times.\n");
	printf(" -tp : mqtt topic to publish to. May be repeated multiple times.\n");
	printf(" -T : topic string to filter out of results. May be repeated.\n");
	printf(" -u : provide a username\n");
	printf(" -U : unsubscribe from a topic. May be repeated.\n");
	printf(" -v : print published messages verbosely.\n");
	printf(" -V : specify the version of the MQTT protocol to use when connecting.\n");
	printf("      Can be mqttv31 or mqttv311. Defaults to mqttv311.\n");
#ifndef WIN32
	printf(" -W : Specifies a timeout in seconds how long to process incoming MQTT messages.\n");
#endif
	printf(" --help : display this message.\n");
	printf(" --quiet : don't print error messages.\n");
	printf(" --retained-only : only handle messages with the retained flag set, and exit when the\n");
	printf("                   first non-retained message is received.\n");
	printf(" --will-payload : payload for the client Will, which is sent by the broker in case of\n");
	printf("                  unexpected disconnection. If not given and will-topic is set, a zero\n");
	printf("                  length message will be sent.\n");
	printf(" --will-qos : QoS level for the client Will.\n");
	printf(" --will-retain : if given, make the client Will retained.\n");
	printf(" --will-topic : the topic on which to publish the client Will.\n");
#ifdef WITH_TLS
	printf(" --cafile : path to a file containing trusted CA certificates to enable encrypted\n");
	printf("            certificate based communication.\n");
	printf(" --capath : path to a directory containing trusted CA certificates to enable encrypted\n");
	printf("            communication.\n");
	printf(" --cert : client certificate for authentication, if required by server.\n");
	printf(" --key : client private key for authentication, if required by server.\n");
	printf(" --ciphers : openssl compatible list of TLS ciphers to support.\n");
	printf(" --tls-version : TLS protocol version, can be one of tlsv1.2 tlsv1.1 or tlsv1.\n");
	printf("                 Defaults to tlsv1.2 if available.\n");
	printf(" --insecure : do not check that the server certificate hostname matches the remote\n");
	printf("              hostname. Using this option means that you cannot be sure that the\n");
	printf("              remote host is the server you wish to connect to and so is insecure.\n");
	printf("              Do not use this option in a production environment.\n");
#ifdef FINAL_WITH_TLS_PSK
	printf(" --psk : pre-shared-key in hexadecimal (no leading 0x) to enable TLS-PSK mode.\n");
	printf(" --psk-identity : client identity string for TLS-PSK mode.\n");
#endif
#endif
#ifdef WITH_SOCKS
	printf(" --proxy : SOCKS5 proxy URL of the form:\n");
	printf("           socks5h://[username[:password]@]hostname[:port]\n");
	printf("           Only \"none\" and \"username\" authentication is supported.\n");
#endif
	//	printf("\nSee http://mosquitto.org/ for more information.\n\n");
}


#define BUF_LEN 2048

int send_to_server(int argc, char *argv[],int pfd)
{
	struct mosq_config pubcfg;
	struct mosquitto *pubmosq = NULL;
	int rc;
	int rc2;
	char *buf, *buf2;
	int buf_len = 1024;
	int buf_len_actual;
	int read_len;
	int pos;
	buf = malloc(buf_len);
	if(!buf){
		fprintf(stderr, "Error: Out of memory.\n");
		return 1;
	}

	memset(&pubcfg, 0, sizeof(struct mosq_config));
	rc = client_config_load(&pubcfg, CLIENT_PUB, argc, argv);
	if(rc){
		client_config_cleanup(&pubcfg);
		if(rc == 2){
			/* --help */
			print_usage();
		}else{
			fprintf(stderr, "\nUse 'air_control --help' to see usage.\n");
		}
		free(buf);
		return 1;
	}

	pubtopic = pubcfg.topic;
	pubmessage = pubcfg.message;
	pubmsglen = pubcfg.msglen;
	pubqos = pubcfg.qos;
	pubretain = pubcfg.retain;
	pubmode = pubcfg.pub_mode;
	pubusername = pubcfg.username;
	pubpassword = pubcfg.password;
	pubquiet = pubcfg.quiet;
#ifndef WITH_THREADING
	if(pubcfg.pub_mode == MSGMODE_STDIN_LINE){
		fprintf(stderr, "Error: '-l' mode not available, threading support has not been compiled in.\n");
		free(buf);
		return 1;
	}
#endif

	if(pubcfg.pub_mode == MSGMODE_STDIN_FILE){
			fprintf(stderr, "Error loading input from stdin.\n");
			free(buf);
			return 1;
	}else if(pubcfg.file_input){
			fprintf(stderr, "Error loading input file \"%s\".\n", pubcfg.file_input);
			free(buf);
			return 1;
	}

	if(!pubtopic || pubmode == MSGMODE_NONE){
		fprintf(stderr, "Error: Both topic and message must be supplied.\n");
		print_usage();
		free(buf);
		return 1;
	}


	mosquitto_lib_init();
	if(client_id_generate(&pubcfg, "mosqpub")){
		free(buf);
		return 1;
	}

	pubmosq = mosquitto_new(pubcfg.id, true, NULL);
	if(!pubmosq){
		switch(errno){
			case ENOMEM:
				if(!pubquiet) fprintf(stderr, "Error: Out of memory.\n");
				break;
			case EINVAL:
				if(!pubquiet) fprintf(stderr, "Error: Invalid id.\n");
				break;
		}
		mosquitto_lib_cleanup();
		free(buf);
		return 1;
	}
	if(pubcfg.debug){
		mosquitto_log_callback_set(pubmosq, my_log_callback);
	}
	mosquitto_connect_callback_set(pubmosq, pub_connect_callback);
	mosquitto_disconnect_callback_set(pubmosq, pub_disconnect_callback);
	mosquitto_publish_callback_set(pubmosq, publish_callback);


	if(client_opts_set(pubmosq, &pubcfg)){
		free(buf);
		return 1;
	}
	rc = client_connect(pubmosq, &pubcfg);
	if(rc) return rc;

	if(pubmode == MSGMODE_STDIN_LINE){
		mosquitto_loop_start(pubmosq);
	}

	do{
		if(pubmode == MSGMODE_STDIN_LINE){
			if(pubstatus == STATUS_CONNACK_RECVD){
				while(true){
					if(air_cmd == CMD_REPORT){
						printf("report\n");
						rc2 = mosquitto_publish(pubmosq, &pubmid_sent, pubtopic, "test", strlen("test") + 1, pubqos, pubretain);
						if(rc2){
							if(!pubquiet) fprintf(stderr, "Error: Publish returned %d, disconnecting.\n", rc2);
							printf("disconnect pub\n");
							mosquitto_disconnect(pubmosq);
							exit(0);
						}
						air_cmd = CMD_NONE;
					}
					sleep(1);
				}
			}else if(pubstatus == STATUS_WAITING){
				if(publast_mid_sent == publast_mid && pubdisconnect_sent == false){
					mosquitto_disconnect(pubmosq);
					pubdisconnect_sent = true;
				}
				struct timespec ts;
				ts.tv_sec = 0;
				ts.tv_nsec = 100000000;
				nanosleep(&ts, NULL);
			}
			rc = MOSQ_ERR_SUCCESS;
		}else{
			rc = mosquitto_loop(pubmosq, -1, 1);
		}
	}while(rc == MOSQ_ERR_SUCCESS && pubconnected);

	if(pubmode == MSGMODE_STDIN_LINE){
		mosquitto_loop_stop(pubmosq, false);
	}

	if(pubmessage && pubmode == MSGMODE_FILE){
		free(pubmessage);
	}
	mosquitto_destroy(pubmosq);
	mosquitto_lib_cleanup();

	client_config_cleanup(&pubcfg);

	pubmessage = NULL;
	free(buf);
	buf = NULL;

	if(rc){
		fprintf(stderr, "Error: %s\n", mosquitto_strerror(rc));
	}
	return rc;
}

int recv_from_server(int argc, char *argv[],int fd){
	//	signal(SIGINT, signal_int_handler);
	fd485 = fd;

	int rc;
#ifndef WIN32
	struct sigaction alm_sigact, int_sigact;
#endif

	memset(&subcfg, 0, sizeof(struct mosq_config));

	rc = client_config_load(&subcfg, CLIENT_SUB, argc, argv);
	if(rc){
		client_config_cleanup(&subcfg);
		if(rc == 2){
			/* --help */
			print_usage();
		}else{
			fprintf(stderr, "\nUse 'air_control --help' to see usage.\n");
		}
		return 1;
	}

	if(subcfg.no_retain && subcfg.retained_only){
		fprintf(stderr, "\nError: Combining '-R' and '--retained-only' makes no sense.\n");
		return 1;
	}

	mosquitto_lib_init();

	if(client_id_generate(&subcfg, "mosqsub")){
		return 1;
	}

	submosq = mosquitto_new(subcfg.id, subcfg.clean_session, &subcfg);
	if(!submosq){
		switch(errno){
			case ENOMEM:
				if(!subcfg.quiet) fprintf(stderr, "Error: Out of memory.\n");
				break;
			case EINVAL:
				if(!subcfg.quiet) fprintf(stderr, "Error: Invalid id and/or clean_session.\n");
				break;
		}
		mosquitto_lib_cleanup();
		return 1;
	}
	if(client_opts_set(submosq, &subcfg)){
		return 1;
	}
	if(subcfg.debug){
		mosquitto_log_callback_set(submosq, my_log_callback);
		mosquitto_subscribe_callback_set(submosq, subscribe_callback);
	}
	mosquitto_connect_with_flags_callback_set(submosq, sub_connect_callback);
	mosquitto_message_callback_set(submosq, sub_message_callback);

	rc = client_connect(submosq, &subcfg);
	if(rc) return rc;

#ifndef WIN32
	alm_sigact.sa_handler = my_signal_handler;
	sigemptyset(&alm_sigact.sa_mask);
	alm_sigact.sa_flags = 0;

	if(sigaction(SIGALRM, &alm_sigact, NULL) == -1){
		perror("sigaction alm");
		return 1;
	}	

	if(subcfg.timeout){
		alarm(subcfg.timeout);
	}


	int_sigact.sa_handler = signal_int_handler;
	sigemptyset(&int_sigact.sa_mask);
	int_sigact.sa_flags = 0;

	if(sigaction(SIGINT, &int_sigact, NULL) == -1){
		perror("sigaction int");
		return 1;
	}	

#endif

	rc = mosquitto_loop_forever(submosq, -1, 1);

	mosquitto_destroy(submosq);
	mosquitto_lib_cleanup();

	if(subcfg.msg_count>0 && rc == MOSQ_ERR_NO_CONN){
		rc = 0;
	}
	if(rc){
		fprintf(stderr, "Error: %s\n", mosquitto_strerror(rc));
	}
	return rc;
}
