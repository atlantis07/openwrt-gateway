#ifndef _H_SCENE
#define _H_SCENE

#define SCENEHEAD "Scene"
#define SCENESET "SceneSet"
#define SCENEACTION "SceneAction"
#define SCENERM "SceneRm"

#define SCENE_PARAM_LEN 32
#define SCENE_FILE_MAXLEN 128
#define SCENE_NODE_MAXLEN 32
#define SCENE_CMD_MAXLEN 128

#include "cJSON.h"
#include "cJSON_Utils.h"
int scene_exec(char *name, cJSON *payload);

int scene_set(char *name, cJSON *payload);
int scene_action(char *name);
int uci_set_scene(char *name, cJSON *appliances);
#endif
