#include "scene.h"
#include "serial.h"
#include "node.h"
#include "air_condition.h"
#include <uci.h>
#include "uci.h"
#include "tl.h"
#include "cJSON.h"
#include "cJSON_Utils.h"

int scene_file_access_and_create(char *filename){
	if(!filename){
		return PARAM_ERROR;
	}   


	int fd = open(filename,O_RDWR|O_CREAT);
	if(fd < 0){ 
		tl_printf(MSG_ERROR,"create %s failed\n", filename);
		return OPEN_DEVICE_ERROR;
	}   
	tl_printf(MSG_INFO, "create %s success\n", filename);
	close(fd);
	return 0;
}

int scene_add_section(char *file, char *section, char *type){
	if(!file || !section || !type){
		return PARAM_ERROR;
	}
	char scene_set_cmd[SCENE_CMD_MAXLEN] = "";
	sprintf(scene_set_cmd, "uci set %s.%s=%s", file, section, type);
	tl_printf(MSG_INFO, "%s\n", scene_set_cmd);
	system(scene_set_cmd);
	return 0;
}

int scene_set_switch_option(char *file, char *section, int way, char *status){
	if(!file || !section || !status || (way > 4)){
		return PARAM_ERROR;
	}

	char scene_set_cmd[SCENE_CMD_MAXLEN] = "";
	sprintf(scene_set_cmd ,"uci set %s.%s.switch_%02x=\"%s\"", file, section, way, status);
	tl_printf(MSG_INFO, "%s\n", scene_set_cmd);
	system(scene_set_cmd);
	return 0;
}

int scene_set_climate_option(char *file, char *section,  int climate_addr, 
		char *series, char *power, int temperture, char *mode, char *fan){
	if(!file || !section || !series || !power || !mode || !fan){
		return PARAM_ERROR;
	}

	char scene_set_cmd[SCENE_CMD_MAXLEN] = "";
	sprintf(scene_set_cmd ,"uci set %s.%s.climate_%02x%02x=\"%s %s %02d %s %s\"", 
			file, section, climate_addr >> 8, climate_addr & 0xff, 
			series, power, temperture, mode, fan);
	tl_printf(MSG_INFO, "%s\n", scene_set_cmd);
	system(scene_set_cmd);
}

int scene_set_freq433_curtain_option(char *file, char *section, const char *brand, const int channel,
			const char *action){
	if(!file || !section || !brand || !action ){
		return PARAM_ERROR;
	}

	char scene_set_cmd[SCENE_CMD_MAXLEN] = "";
	sprintf(scene_set_cmd ,"uci set %s.%s.freq433_curtain=\"%s %d %s\"", file, section, brand, channel, action);
	tl_printf(MSG_INFO, "%s\n", scene_set_cmd);
	system(scene_set_cmd);
	return 0;
}

int scene_commit(char *ucifilename){
	char scene_commit_cmd[SCENE_CMD_MAXLEN] = "";
	sprintf(scene_commit_cmd, "uci commit %s", ucifilename);
	tl_printf(MSG_INFO, "%s\n", scene_commit_cmd);
	system(scene_commit_cmd);
	return 0;
}

int uci_set_scene(char *name, cJSON *appliances){
	int ret;

	char filename[SCENE_FILE_MAXLEN] = "";
	char ucifilename[SCENE_FILE_MAXLEN] = "";
	sprintf(ucifilename, "scene_%s", name);
	sprintf(filename, "/etc/config/%s", ucifilename);

	ret = scene_file_access_and_create(filename);
	if(ret){
		return ret;
	}

	const cJSON *appliance = NULL;
	cJSON_ArrayForEach(appliance, appliances){
		const cJSON *group = cJSON_GetObjectItemCaseSensitive(appliance, "Group");
		if(!group || !cJSON_IsNumber(group)){
			tl_printf(MSG_ERROR, "Group is not number\n");
			return PARAM_ERROR;
		}
		int _group = group->valuedouble;

		const cJSON *device = NULL;
		const cJSON *devices = cJSON_GetObjectItemCaseSensitive(appliance, "Devices");
		if(!devices || !cJSON_IsArray(devices)){
			tl_printf(MSG_ERROR, "devices is not array\n");
			continue;
		}
		cJSON_ArrayForEach(device, devices){
			const cJSON *node = cJSON_GetObjectItemCaseSensitive(device, "Node");
			if(!node || !cJSON_IsString(node)){
				tl_printf(MSG_ERROR, "node is not exist or string\n");
				continue;
			}

			char section[SCENE_CMD_MAXLEN] = "";
			sprintf(section, "%s_%02d", node->valuestring, _group);

			ret = scene_add_section(ucifilename, section, "device");
			if(ret){
				continue;
			}

			const cJSON *_switch = NULL;
			const cJSON *switches = cJSON_GetObjectItemCaseSensitive(device, "Switches");
			if(switches && cJSON_IsArray(switches)){
				cJSON_ArrayForEach(_switch, switches){
					const cJSON *way = cJSON_GetObjectItemCaseSensitive(_switch, "Way");
					const cJSON *status = cJSON_GetObjectItemCaseSensitive(_switch, "Status");
					if(!way || !status || !cJSON_IsNumber(way) || !cJSON_IsString(status)){
					}
					else{
						scene_set_switch_option(ucifilename, section, way->valuedouble, status->valuestring);
					}
				}
			}


			const cJSON *climate = NULL;
			const cJSON *climates = cJSON_GetObjectItemCaseSensitive(device, "Climates");
			if(climates && cJSON_IsArray(climates)){
				cJSON_ArrayForEach(climate, climates){
					const cJSON *climate_addr = cJSON_GetObjectItemCaseSensitive(climate, "Climate_addr");
					const cJSON *series = cJSON_GetObjectItemCaseSensitive(climate, "Series");
					const cJSON *power = cJSON_GetObjectItemCaseSensitive(climate, "Power");
					const cJSON *temperture = cJSON_GetObjectItemCaseSensitive(climate, "Temperture");
					const cJSON *mode = cJSON_GetObjectItemCaseSensitive(climate, "Mode");
					const cJSON *fan = cJSON_GetObjectItemCaseSensitive(climate, "Fan");

					if(!climate_addr || !series || !power || !temperture || !mode || !fan){
						continue;
					}
					else if(!cJSON_IsNumber(climate_addr) || !cJSON_IsString(series) || 
							!cJSON_IsString(power) || !cJSON_IsNumber(temperture) || 
							!cJSON_IsString(mode) || !cJSON_IsString(fan)){
						continue;
					}
					else{
						scene_set_climate_option(ucifilename, section, climate_addr->valuedouble, 
								series->valuestring, power->valuestring, 
								temperture->valuedouble, mode->valuestring, fan->valuestring);
					}
				}
			}

			
			const cJSON *_freq433 = NULL;
			const cJSON *freq433 = cJSON_GetObjectItemCaseSensitive(device, "Freq433");
			if(freq433 && cJSON_IsArray(freq433)){
				cJSON_ArrayForEach(_freq433, freq433){
					const cJSON *series = cJSON_GetObjectItemCaseSensitive(_freq433, "Series");
					if(!series || !cJSON_IsString(series)){
						continue;
					}
					if(!strcmp(series->valuestring, "Curtain")){
						const cJSON *brand = cJSON_GetObjectItemCaseSensitive(_freq433, "Brand");
						const cJSON *channel = cJSON_GetObjectItemCaseSensitive(_freq433, "Channel");
						const cJSON *action = cJSON_GetObjectItemCaseSensitive(_freq433, "Action");
						if(!brand  || !action || !cJSON_IsString(brand) 
							|| !cJSON_IsString(action) || !cJSON_IsNumber(channel)){
							tl_printf(MSG_ERROR, "Freq 433 Curtain PARAM ERROR");
							continue;
						}
						tl_printf(MSG_INFO, "scene set 433");
						scene_set_freq433_curtain_option(ucifilename, section,  brand->valuestring,
						 channel->valuedouble, action->valuestring);
					}
				}
			}

		}
	}
	scene_commit(ucifilename);
	return 0;
}



int scene_set(char *name, cJSON *payload){
	cJSON *Appliances = cJSON_GetObjectItemCaseSensitive(payload, "Appliances");
	if(!cJSON_IsArray(Appliances)){
		tl_printf(MSG_ERROR,"Appliances is not Array\n");
		return PARAM_ERROR;
	}

	uci_set_scene(name, Appliances);
}

int scene_parse_config(char *name){
	struct uci_context * ctx = NULL;
	struct uci_package * pkg = NULL;
	struct uci_element *e; 

	char file[SCENE_FILE_MAXLEN] = "";
	sprintf(file, "scene_%s", name);

	ctx = uci_alloc_context();
	if (UCI_OK != uci_load(ctx, file, &pkg)){
		tl_printf(MSG_ERROR, "Unknown file %s", file);
		goto cleanup;
	}


	uci_foreach_element(&pkg->sections, e)
	{
		struct uci_section *s = uci_to_section(e);

		if(!s->e.name){
			continue;
		}
		unsigned char macaddr[MACADDR_LEN] = "";
		int group = -1;

		int ret = sscanf(s->e.name, "%02x%02x%02x%02x%02x%02x%02x%02x_%02x",
				&macaddr[0], &macaddr[1], &macaddr[2], &macaddr[3],
				&macaddr[4], &macaddr[5], &macaddr[6], &macaddr[7], &group);
		if(ret != 9){
			continue;
		}

		
		struct uci_element *ee = NULL;
		for(ee = list_to_element((&s->options)->next);
				&ee->list != (&s->options);
				ee = list_to_element(ee->list.next)){
			if(!ee){
				continue;
			}
			
			struct uci_option *o;
			o = uci_to_option(ee);
			if (!o || o->type != UCI_TYPE_STRING){
				continue;
			}

			if(!ee->name || !o->v.string){
				continue;
			}

			char optparam[SCENE_PARAM_LEN] = "";
			int optparamlen = (strlen(o->v.string) > SCENE_PARAM_LEN)? SCENE_PARAM_LEN:strlen(o->v.string);
			memcpy(optparam, o->v.string, optparamlen);
			
			if(strstr(ee->name, "switch")){
				int num = -1;
				ret = sscanf(ee->name, "switch_%02x", &num);
				if((ret != 1) || (num < 0)){
					continue;
				}
				switch_prepare(macaddr, num, optparam);
				usleep(200000);
			}
			else if(strstr(ee->name, "climate")){
				int climate_addr[2] = {0};
				char series[SCENE_PARAM_LEN] = "";
				char power[SCENE_PARAM_LEN] = "";
				int temperature_set = 0;
				char _temperature_set[SCENE_PARAM_LEN] = "";
				char mode_set[SCENE_PARAM_LEN] = "";
				char fan_set[SCENE_PARAM_LEN] = "";

				ret = sscanf(ee->name, "climate_%02x%02x", &climate_addr[0], &climate_addr[1]);
				if(ret != 2){
					continue;
				}

				if(optparam){
					ret = sscanf(optparam, "%s %s %02d %s %s", 
							series, power, &temperature_set, mode_set, fan_set);
					
					if(ret != 5){
						continue;
					}
				
					if(!strcmp(series, "INFRARED_FANGWEI")){
						unsigned char target_climate_cmd[AIR_PASS_DATA_MAX] = ""; 
						int target_climate_cmd_len = 0;
						cJSON *payload = NULL;
						payload = cJSON_CreateObject();
						if(payload){
							cJSON_AddStringToObject(payload, "power", power);
							cJSON_AddNumberToObject(payload, "temperature_set", temperature_set);
							cJSON_AddStringToObject(payload, "mode_set", mode_set);
							cJSON_AddStringToObject(payload, "fan_set", fan_set);
							char *spayload = cJSON_Print(payload);
						
							write_to_climate(gwmacaddr, "tanklight_set", 
									spayload, strlen(spayload), "127.0.0.1", "INFRARED_FANGWEI", macaddr, 0);
							free(spayload);
							cJSON_Delete(payload);
							usleep(200000);
						}
					}
					else if(!strcmp(series, "INFRARED")){
						tl_printf(MSG_INFO, "scene set ac INFRARED");
						if(!strcmp(power, "OFF")){
							write_to_climate(gwmacaddr, "power", power, SCENE_PARAM_LEN,
									"127.0.0.1", "INFRARED", macaddr, 0);
						}
						else{
							write_to_climate(gwmacaddr, "power", power, SCENE_PARAM_LEN,
									"127.0.0.1", "INFRARED", macaddr, 0);
							usleep(200000);
							sprintf(_temperature_set, "%d", temperature_set);
							write_to_climate(gwmacaddr, "temperature_set", _temperature_set,  SCENE_PARAM_LEN,
									"127.0.0.1", "INFRARED", macaddr, 0);
							usleep(200000);
							write_to_climate(gwmacaddr, "mode_set", mode_set, SCENE_PARAM_LEN,
									"127.0.0.1", "INFRARED", macaddr, 0);
							usleep(200000);
							write_to_climate(gwmacaddr, "fan_set", fan_set, SCENE_PARAM_LEN,
									"127.0.0.1", "INFRARED", macaddr, 0);
							usleep(200000);
						}
					}
				}
			}
			else if(strstr(ee->name, "freq433_curtain")){
				//char series[SCENE_PARAM_LEN] = "";
				char brand[SCENE_PARAM_LEN] = "";
				int channel = -1;
				char action[SCENE_PARAM_LEN] = "";
				
				ret = sscanf(optparam, "%s %d %s", brand, &channel, action);
				if(ret != 3){
					continue;
				}

				cJSON *root = NULL;
				root = cJSON_CreateObject();
				if(root){
					cJSON *header = cJSON_AddObjectToObject(root, "Header");
					cJSON *payload = cJSON_AddObjectToObject(root, "Payload");
					if(header && payload){
						cJSON_AddStringToObject(header, "Name", "Freq433");
						
						cJSON *appliances = cJSON_AddArrayToObject(payload, "Appliances");
						cJSON *element = cJSON_CreateObject();
					    cJSON_AddStringToObject(element, "Series", "Curtain");
					    cJSON_AddStringToObject(element, "Brand", brand);
					    cJSON_AddNumberToObject(element, "Channel", channel);
					    cJSON_AddStringToObject(element, "Action", action);
					
						cJSON_AddItemToArray(appliances, element);		
					}
					else{
						cJSON_Delete(root);
						continue;
					}
					
					char *sroot = cJSON_Print(root);
					tl_printf(MSG_INFO, "433 scene curtain: %s", sroot);
					tanklight_control("topic", sroot);

					free(sroot);
					cJSON_Delete(root);
					usleep(200000);
				}
			}
		}
	}

	uci_unload(ctx, pkg);
cleanup:	  
	uci_free_context(ctx);
	ctx = NULL;
	return 0;
}

int scene_rm(char *name){
	char rmfile[SCENE_FILE_MAXLEN] = "";
	sprintf(rmfile, "rm /etc/config/scene_%s", name);
	tl_printf(MSG_INFO, "%s\n", rmfile);
	system(rmfile);
	return 0;
}

int scene_action(char *name){
	scene_parse_config(name);
}

int scene_exec(char *name, cJSON *payload){
	if(!name || !payload){
		tl_printf(MSG_ERROR, "scene action param error\n");
		return PARAM_ERROR;
	}


	cJSON *SceneName = cJSON_GetObjectItemCaseSensitive(payload, "SceneName");
	cJSON *ApplianceId = cJSON_GetObjectItemCaseSensitive(payload, "ApplianceId");

	if(!cJSON_IsString(SceneName) || !cJSON_IsString(ApplianceId)
			|| (!SceneName->valuestring) || (!ApplianceId->valuestring)){
		tl_printf(MSG_ERROR, "SceneName or ApplianceID is not exist\n");
		return PARAM_ERROR;
	}


	if(!strcmp(name, SCENESET)){
		scene_set(SceneName->valuestring, payload);
	}
	else if(!strcmp(name, SCENEACTION)){
		scene_action(SceneName->valuestring);
	}
	else if(!strcmp(name, SCENERM)){
		scene_rm(SceneName->valuestring);
	}
}
