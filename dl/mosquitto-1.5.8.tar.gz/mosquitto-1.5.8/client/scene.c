#include "scene.h"
#include "serial.h"
#include "node.h"
#include "air_condition.h"
#include <uci.h>
#include "uci.h"
#include "cJSON.h"
#include "cJSON_Utils.h"

int scene_file_access_and_create(char *filename){
	if(!filename){
		return PARAM_ERROR;
	}   


	int fd = open(filename,O_RDWR|O_CREAT);
	if(fd < 0){ 
		tl_printf(MSG_ERROR,"create %s failed\n", filename);
		return OPEN_DEVICE_ERROR;
	}   
	tl_printf(MSG_INFO, "create %s success\n", filename);
	close(fd);
	return 0;
}

int scene_add_section(char *file, char *section, char *type){
	if(!file || !section || !type){
		return PARAM_ERROR;
	}
	char scene_set_cmd[SCENE_CMD_MAXLEN] = "";
	sprintf(scene_set_cmd, "uci set %s.%s=%s", file, section, type);
	tl_printf(MSG_INFO, "%s\n", scene_set_cmd);
	system(scene_set_cmd);
	return 0;
}

int scene_set_switch_option(char *file, char *section, int way, char *status){
	if(!file || !section || !status || (way > 4)){
		return PARAM_ERROR;
	}

	char scene_set_cmd[SCENE_CMD_MAXLEN] = "";
	sprintf(scene_set_cmd ,"uci set %s.%s.switch_%02x=\"%s\"", file, section, way, status);
	tl_printf(MSG_INFO, "%s\n", scene_set_cmd);
	system(scene_set_cmd);
	return 0;
}

int scene_set_climate_option(char *file, char *section,  int climate_addr, 
		char *series, char *power, int temperture, char *mode, char *fan){
	if(!file || !section || !series || !power || !mode || !fan){
		return PARAM_ERROR;
	}

	char scene_set_cmd[SCENE_CMD_MAXLEN] = "";
	sprintf(scene_set_cmd ,"uci set %s.%s.climate_%02x%02x=\"%s %s %02d %s %s\"", 
			file, section, climate_addr >> 8, climate_addr & 0xff, 
			series, power, temperture, mode, fan);
	tl_printf(MSG_INFO, "%s\n", scene_set_cmd);
	system(scene_set_cmd);
}

int scene_commit(char *ucifilename){
	char scene_commit_cmd[SCENE_CMD_MAXLEN] = "";
	sprintf(scene_commit_cmd, "uci commit %s", ucifilename);
	tl_printf(MSG_INFO, "%s\n", scene_commit_cmd);
	system(scene_commit_cmd);
	return 0;
}

int uci_set_scene(char *name, cJSON *appliances){
	int ret;

	char filename[SCENE_FILE_MAXLEN] = "";
	char ucifilename[SCENE_FILE_MAXLEN] = "";
	sprintf(ucifilename, "scene_%s", name);
	sprintf(filename, "/etc/config/%s", ucifilename);

	ret = scene_file_access_and_create(filename);
	if(ret){
		return ret;
	}

	const cJSON *appliance = NULL;
	cJSON_ArrayForEach(appliance, appliances){
		const cJSON *group = cJSON_GetObjectItemCaseSensitive(appliance, "group");
		if(!group || !cJSON_IsNumber(group)){
			tl_printf(MSG_ERROR, "Group is not number\n");
			return PARAM_ERROR;
		}
		int _group = group->valuedouble;

		const cJSON *device = NULL;
		const cJSON *devices = cJSON_GetObjectItemCaseSensitive(appliance, "devices");
		if(!devices || !cJSON_IsArray(devices)){
			tl_printf(MSG_ERROR, "devices is not array\n");
			continue;
		}
		cJSON_ArrayForEach(device, devices){
			const cJSON *node = cJSON_GetObjectItemCaseSensitive(device, "node");
			if(!node || !cJSON_IsString(node)){
				tl_printf(MSG_ERROR, "node is not exist or string\n");
				continue;
			}

			char section[SCENE_CMD_MAXLEN] = "";
			sprintf(section, "%s_%02d", node->valuestring, _group);

			ret = scene_add_section(ucifilename, section, "device");
			if(ret){
				continue;
			}

			const cJSON *_switch = NULL;
			const cJSON *switches = cJSON_GetObjectItemCaseSensitive(device, "switches");
			if(switches && cJSON_IsArray(switches)){
				cJSON_ArrayForEach(_switch, switches){
					const cJSON *way = cJSON_GetObjectItemCaseSensitive(_switch, "way");
					const cJSON *status = cJSON_GetObjectItemCaseSensitive(_switch, "status");
					if(!way || !status || !cJSON_IsNumber(way) || !cJSON_IsString(status)){
					}
					else{
						scene_set_switch_option(ucifilename, section, way->valuedouble, status->valuestring);
					}
				}
			}


			const cJSON *climate = NULL;
			const cJSON *climates = cJSON_GetObjectItemCaseSensitive(device, "climates");
			if(climates && cJSON_IsArray(climates)){
				cJSON_ArrayForEach(climate, climates){
					const cJSON *climate_addr = cJSON_GetObjectItemCaseSensitive(climate, "climate_addr");
					const cJSON *series = cJSON_GetObjectItemCaseSensitive(climate, "series");
					const cJSON *power = cJSON_GetObjectItemCaseSensitive(climate, "power");
					const cJSON *temperture = cJSON_GetObjectItemCaseSensitive(climate, "temperture");
					const cJSON *mode = cJSON_GetObjectItemCaseSensitive(climate, "mode");
					const cJSON *fan = cJSON_GetObjectItemCaseSensitive(climate, "fan");

					if(!climate_addr || !series || !power || !temperture || !mode || !fan){
					}
					else if(!cJSON_IsNumber(climate_addr) || !cJSON_IsString(series) || 
							!cJSON_IsString(power) || !cJSON_IsNumber(temperture) || 
							!cJSON_IsString(mode) || !cJSON_IsString(fan)){
					}
					else{
						scene_set_climate_option(ucifilename, section, climate_addr->valuedouble, 
								series->valuestring, power->valuestring, 
								temperture->valuedouble, mode->valuestring, fan->valuestring);
					}
				}
			}

		}
	}
	scene_commit(ucifilename);
	return 0;
}



int scene_set(char *name, cJSON *payload){
	cJSON *Appliances = cJSON_GetObjectItemCaseSensitive(payload, "Appliances");
	if(!cJSON_IsArray(Appliances)){
		tl_printf(MSG_ERROR,"Appliances is not Array\n");
		return PARAM_ERROR;
	}

	uci_set_scene(name, Appliances);
}

int scene_parse_config(char *name){
	struct uci_context * ctx = NULL;
	struct uci_package * pkg = NULL;
	struct uci_element *e; 

	char file[SCENE_FILE_MAXLEN] = "";
	sprintf(file, "scene_%s", name);

	ctx = uci_alloc_context();
	if (UCI_OK != uci_load(ctx, file, &pkg))
		goto cleanup;


	uci_foreach_element(&pkg->sections, e)
	{
		struct uci_section *s = uci_to_section(e);

		if(!s->e.name){
			continue;
		}
		unsigned char macaddr[MACADDR_LEN] = "";
		int group = -1;

		int ret = sscanf(s->e.name, "%02x%02x%02x%02x%02x%02x%02x%02x_%02x",
				&macaddr[0], &macaddr[1], &macaddr[2], &macaddr[3],
				&macaddr[4], &macaddr[5], &macaddr[6], &macaddr[7], &group);
		if(ret != 9){
			continue;
		}

		
		struct uci_element *ee = NULL;
		for(ee = list_to_element((&s->options)->next);
				&ee->list != (&s->options);
				ee = list_to_element(ee->list.next)){
			if(!ee){
				continue;
			}
			
			struct uci_option *o;
			o = uci_to_option(ee);
			if (!o || o->type != UCI_TYPE_STRING){
				continue;
			}

			if(!ee->name || !o->v.string){
				continue;
			}

			char optparam[SCENE_PARAM_LEN] = "";
			int optparamlen = (strlen(o->v.string) > SCENE_PARAM_LEN)? SCENE_PARAM_LEN:strlen(o->v.string);
			memcpy(optparam, o->v.string, optparamlen);
			
			if(strstr(ee->name, "switch")){
				int num = -1;
				ret = sscanf(ee->name, "switch_%02x", &num);
				if((ret != 1) || (num < 0)){
					continue;
				}
				switch_prepare(macaddr, num, optparam);
			}
			else if(strstr(ee->name, "climate")){
				int climate_addr[2];
				char series[SCENE_PARAM_LEN] = "";
				char power[SCENE_PARAM_LEN] = "";
				int temperature_set = 0;
				char mode_set[SCENE_PARAM_LEN] = "";
				char fan_set[SCENE_PARAM_LEN] = "";

				ret = sscanf(ee->name, "climate_%02x%02x", &climate_addr[0], &climate_addr[1]);
				if(ret != 2){
					continue;
				}

				if(optparam){
					ret = sscanf(optparam, "%s %s %02d %s %s", 
							series, power, &temperature_set, mode_set, fan_set);
					if(ret != 5){
						continue;
					}
					
					pthread_mutex_lock(&air_mutex_lock);
					AIR_NODE *cmd_air = find_air_node(macaddr);
					if(!cmd_air){
						tl_printf(MSG_ERROR, "[cmd]air node is not exist\n");
						pthread_mutex_unlock(&air_mutex_lock);
						continue;
					}

//					if(strcmp(cmd_air->ainfo.series, series)){
//						printf("air series mismatch\n");
//						ret = PARAM_ERROR;
//						goto climate_end;
//					}

					unsigned char target_climate_cmd[AIR_PASS_DATA_MAX] = ""; 
					int target_climate_cmd_len = 0;
					cJSON *payload = NULL;
					payload = cJSON_CreateObject();
					if(payload){
						cJSON_AddStringToObject(payload, "power", power);
						cJSON_AddNumberToObject(payload, "temperature_set", temperature_set);
						cJSON_AddStringToObject(payload, "mode_set", mode_set);
						cJSON_AddStringToObject(payload, "fan_set", fan_set);
						char *spayload = cJSON_Print(payload);
						//printf("%s\n", spayload);
						
						climate_data_init(series, spayload, &target_climate_cmd ,&target_climate_cmd_len, cmd_air->ainfo.addr, cmd_air->ainfo.s_macaddr);
						if(target_climate_cmd_len){
							int ret = sendto_zigbee(target_climate_cmd, target_climate_cmd_len);
						}


						free(spayload);
						cJSON_Delete(payload);
					}
					pthread_mutex_unlock(&air_mutex_lock);

				}
			}
		}
	}

	uci_unload(ctx, pkg);
cleanup:	  
	uci_free_context(ctx);
	ctx = NULL;
	return 0;
}

int scene_rm(char *name){
	char rmfile[SCENE_FILE_MAXLEN] = "";
	sprintf(rmfile, "rm /etc/config/scene_%s", name);
	tl_printf(MSG_INFO, "%s\n", rmfile);
	system(rmfile);
	return 0;
}

int scene_action(char *name){
	scene_parse_config(name);
}

int scene_exec(char *name, cJSON *payload){
	if(!name || !payload){
		tl_printf(MSG_ERROR, "scene action param error\n");
		return PARAM_ERROR;
	}


	cJSON *SceneName = cJSON_GetObjectItemCaseSensitive(payload, "SceneName");
	cJSON *ApplianceId = cJSON_GetObjectItemCaseSensitive(payload, "ApplianceId");

	if(!cJSON_IsString(SceneName) || !cJSON_IsString(ApplianceId)
			|| (!SceneName->valuestring) || (!ApplianceId->valuestring)){
		tl_printf(MSG_ERROR, "SceneName or ApplianceID is not exist\n");
		return PARAM_ERROR;
	}


	if(!strcmp(name, SCENESET)){
		scene_set(SceneName->valuestring, payload);
	}
	else if(!strcmp(name, SCENEACTION)){
		scene_action(SceneName->valuestring);
	}
	else if(!strcmp(name, SCENERM)){
		scene_rm(SceneName->valuestring);
	}
}
