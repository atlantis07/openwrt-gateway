#include "common.h"
#include "stm32.h"
#include "mqttc.h"
#include "task.h"

void *stm32_common_pthread(void *arg){
	if(!arg){
		tl_printf(MSG_INFO, "stm32 pthread failed");
		goto exit;
	}

	if(((unsigned char*)arg)[4] == DEVSTM32_REP){ 
		STM32_DATA_T ddata;
		memset(&ddata, 0, sizeof(STM32_DATA_T));
		ddata.type = ((unsigned char*)arg)[3];
		ddata.status = ((unsigned char*)arg)[7];
		int type;
		switch(ddata.type){
			case TYPE_STM32_DETECT:
				type = DEVICE_STM32_DETECT;
				break;
			case TYPE_STM32_EBTN:
				type = DEVICE_STM32_EBTN;
				break;
			default:
				goto exit;
		}
		task_insert(ACTION_REPORT, type, (void *)&ddata, sizeof(STM32_DATA_T));
	}

exit:
	free(arg);
	arg = NULL;
	return NULL;
}

int stm32_set_status(int num, int status, int type){
    if(!serveripaddr){
        return -1; 
    }   
                                                                                        
    char sstatus[LEN256];
    char scontrol[LEN256];
    memset(sstatus, 0, LEN256);
    memset(scontrol, 0, LEN256);
    
	char *_type = NULL;
	switch(type){
		case TYPE_STM32_DETECT:
			_type = "detect";
			break;
		case TYPE_STM32_EBTN:
			_type = "ebtn";
			break;
		default:
			break;
	}
	sprintf(sstatus, STM32_DEV_STATUS, gwmacaddr, _type, num);
    sprintf(scontrol, MQTT_CMD, serveripaddr, port, username, password, sstatus, status?ON:OFF);
    system(scontrol);
    usleep(100000);
    return 0;
}

int stm32_send_foreach(int num, unsigned char status, int type){
    tl_printf(MSG_INFO, "stm32 num %d, status %02x", num, status);
    int i = 0;                                                                               
    while(num){                                    
        if(num & 0x1){                                                                         
            unsigned char new_status = (status & (1 << i)) >> i;                                
            stm32_set_status(i, new_status, type);
            status = status & ~(1 << i) | (new_status << i);                                     
        }                                                                                
        i++;                                                                   
        num = num >> 1;                                                              
    }   

    return 0;
}
