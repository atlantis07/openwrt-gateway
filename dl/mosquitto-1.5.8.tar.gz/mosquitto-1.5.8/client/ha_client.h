#ifndef _HA_CLIENT_H
#define _HA_CLIENT_H

#endif
