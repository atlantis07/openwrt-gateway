#include "switch.h"
#include "crc.h"
#include "mqttc.h"
#include "serial.h"
#include "node.h"
#include "common.h"

SWITCH_NODE *head;

void switch_alarm(int signum){
	if(!head){
		return ;
	}

	if (signum == SIGALRM)
	{
		alarm(5);      // 重置定时时间
	}

}

int switch_init(){
	head = (SWITCH_NODE*) malloc(sizeof(SWITCH_NODE));
	if(!head){
		tl_printf(MSG_INFO, "init head failed\n");
		return -1;
	}

	head->next = NULL;
	head->prev = NULL;
	return 0;
}

int find_full_mac_and_status(DPKT *dpkt, unsigned char *mac, unsigned char *status,
		unsigned char *proc){
	if(!dpkt || !mac){
		return PARAM_NOT_EXIST;
	}

	DPKT *tmp = dpkt;
	SWITCH_NODE* p = head->next;
	while(p){
		if(!memcmp(p->ninfo.s_macaddr, tmp->s_macaddr, S_MACADDR_LEN)){
			if(mac){
				memcpy(mac, p->ninfo.macaddr, MACADDR_LEN);
			}
			if(status){
				memcpy(status, &(p->ninfo.status), sizeof(unsigned char));
				//*status = p->ninfo.status;
			}
			if(proc){
				//*proc = p->ninfo.proc;
				memcpy(proc, &(p->ninfo.proc), sizeof(unsigned char));
			}
			return MAC_EXIST;
		}
		p = p->next;
	}

	return MAC_NOT_EXIST;
}

int find_switch(INIT_DPKT *dpkt){
	INIT_DPKT *tmp = dpkt;
	if(!head || !tmp){
		return PARAM_NOT_EXIST;
	}

	SWITCH_NODE* p = head->next;
	while(p){
		if(!memcmp(p->ninfo.macaddr, tmp->macaddr, MACADDR_LEN)){
			p = NULL;
			return 1;
		}
		p = p->next;
	}
	p = NULL;
	return 0;
}

int find_short_macaddr(INIT_DPKT *dpkt, unsigned char *short_mac){
	INIT_DPKT *tmp = dpkt;
	if(!head || !tmp){
		return PARAM_NOT_EXIST;
	}

	SWITCH_NODE* p = head->next;
	while(p){
		if(!memcmp(p->ninfo.macaddr, tmp->macaddr, MACADDR_LEN)){
			memcpy(short_mac, p->ninfo.s_macaddr, S_MACADDR_LEN);
			return SHORTMAC_EXIST;
		}
		p = p->next;
	}
	return SHORTMAC_NOT_EXIST;

}

int insert_tail(SWITCHINFO ninfo){
	SWITCH_NODE* pn = (SWITCH_NODE*)malloc(sizeof(SWITCH_NODE));
	if(!pn){
		return -1;
	}

	memcpy(&pn->ninfo, (const void*)&ninfo, sizeof(SWITCHINFO));
	pn->next = NULL;

	SWITCH_NODE* m = NULL;
	SWITCH_NODE *e = NULL;
	m = head;
	e = m->next;
	while(e){
		m = e;
		e = e->next;
	}

	m->next = pn;
	pn->prev = m;
	return 0;
}


void switch_action(char *cmd, INIT_DPKT* dpkt){
	if(!head){
		return;
	}

	SWITCH_NODE* p = head->next;
#if 0
	if(strcmp(cmd, "free")){
		if(!p){
			return;
		}
		else{
			p = p->next;
		}
	}
#endif
	while(p){
		if(!strcmp(cmd, "print")){
			tl_printf(MSG_INFO, "switch");

			tl_printf_array("    macaddr:", p->ninfo.macaddr, MACADDR_LEN);

			tl_printf_array("    smacaddr:",p->ninfo.s_macaddr, S_MACADDR_LEN);

			tl_printf(MSG_INFO,"    timeout: %d, status: %x\n", p->ninfo.timeout, p->ninfo.status);
			p = p->next;
		}
		else if(!strcmp(cmd, "free")){
			SWITCH_NODE* tp = p->next;
			p->next = NULL;
			p->prev = NULL;
			free(p);
			p = tp;
		}
		else if(!strcmp(cmd, "timer")){
			//			p->ninfo.timeout += 5;
			if(p->ninfo.timeout > MAX_TIME){

				int num = (p->ninfo.status & 0xf0)>> 4;
				int n = 0;
				while(num & 0x1){
					n++;
					num = num >> 1;
				}

				for(int i = 0; i < n; i++){
					switch_active(p->ninfo.macaddr, i, OFFLINE);
				}


				SWITCH_NODE* prev = p->prev;
				SWITCH_NODE* next = p->next;

				if(prev){
					prev->next = next;

				}
				if(next){
					next->prev = prev;
				}
				p->prev = NULL;
				p->next = NULL;
				free(p);

				p = next;
				continue;
			}

			p = p->next;
		}
		else if(!strcmp(cmd, "update") || !strcmp(cmd, "update_status")){
			if(!dpkt){
				break;
			}
			if(!memcmp(p->ninfo.macaddr, dpkt->macaddr, MACADDR_LEN)){
				p->ninfo.timeout = 0;
				p->ninfo.status = dpkt->status;
				if(!strcmp(cmd, "update")){
					memcpy(p->ninfo.s_macaddr, dpkt->s_macaddr, S_MACADDR_LEN);
				}
				break;
			}
			p = p->next;
		}

	}
}


void *switch_status_pthread(void *arg){
	DPKT *pkt = (DPKT *)arg;
	if(!pkt){
		tl_printf(MSG_INFO, "pkt is null\n");
		goto exit;
	}

	pthread_mutex_lock(&switch_mutex_lock);
	unsigned char mac[MACADDR_LEN];
	unsigned char status;
	memset(mac, 0, MACADDR_LEN);
	status = 0;

	int f = find_full_mac_and_status(pkt, mac, &status, NULL);
	if(f == MAC_EXIST){
		int num = (pkt->status & status) >> 4;
		int i = 0;
		while(num){
			if(num & 0x1){
				unsigned char new_status = (pkt->status & (1 << i)) >> i;
				switch_set_status(mac, i, new_status);
				status = status & ~(1 << i) | (new_status << i);
			}
			i++;
			num = num >> 1;
		}
		INIT_DPKT ipkt;
		memset(&ipkt, 0, sizeof(INIT_DPKT));
		memcpy(ipkt.macaddr, mac, MACADDR_LEN);
		memcpy(ipkt.s_macaddr, pkt->s_macaddr, S_MACADDR_LEN);
		ipkt.status = status;
		switch_action("update_status", &ipkt);
	}
	else if(f == MAC_NOT_EXIST){
		tl_printf(MSG_INFO, "mac is not exist\n");
		request_mac("short", pkt->s_macaddr, S_MACADDR_LEN);
	}
exit:
	free(arg);
	arg = NULL;
	pthread_mutex_unlock(&switch_mutex_lock);

	pkt = NULL;
	return NULL;
}

void *switch_init_pthread(void *arg){
	if(!arg){
		tl_printf(MSG_ERROR, "pkt is null\n");
		goto exit;
	}

	INIT_DPKT ipkt = ((FULL_INIT_DPKT *)arg)->ipkt;
	int preinit = ((FULL_INIT_DPKT *)arg)->preinit;

	int ret = 0;
	//	uint16_t _crc = crc16tablefast((char *)ipkt, DEV_STATUS_PKT_LEN - (CRC_LEN + TAIL_LEN) * sizeof(unsigned char));
	//	printf("%x\n", _crc);

	pthread_mutex_lock(&switch_mutex_lock);

	int n = find_switch(&ipkt);
	if(n == 1){
		tl_printf(MSG_INFO, "update swtich\n");
		switch_action("update", &ipkt);
	}
	else if(n == 0){
		tl_printf(MSG_INFO, "insert switch\n");
		SWITCHINFO snode;

		memcpy(snode.s_macaddr, ipkt.s_macaddr, S_MACADDR_LEN);// s_mac
		memcpy(snode.macaddr, ipkt.macaddr, MACADDR_LEN);// mac
		snode.status = ipkt.status;
		snode.timeout = 0;

		ret = insert_tail(snode);
	}

	pthread_mutex_unlock(&switch_mutex_lock);
	
	if(!ret){
		if(preinit){
			switch_prepare_foreach(ipkt.macaddr, ipkt.status);
		}
		else{
			query_switch("ON", ipkt.s_macaddr, 0);
		}
		//register_device(snode);
	}

exit: 
	free(arg);
	arg = NULL;
//	ipkt = NULL;
	return NULL;
}

int switch_final_init(unsigned char* macaddr, int num, unsigned char status){
	if(!macaddr){
		return -1;
	}
	FULL_INIT_DPKT *f_ipkt = malloc(FULL_INIT_DEV_STATUS_PKT_LEN);
	if(f_ipkt){
		memset(f_ipkt, 0, sizeof(FULL_INIT_DEV_STATUS_PKT_LEN));
		f_ipkt->ipkt.h[0] = 0xfe;
		f_ipkt->ipkt.h[1] = 0xfd;
		f_ipkt->ipkt.parent[0] = 0x0;
		f_ipkt->ipkt.parent[1] = 0x1;

		memcpy(f_ipkt->ipkt.macaddr, macaddr, MACADDR_LEN);
		pthread_mutex_lock(&node_mutex_lock);
		NODE* p = find_node(macaddr);
		if(p){
			f_ipkt->ipkt.s_macaddr[0] = p->ninfo.s_macaddr[0];
			f_ipkt->ipkt.s_macaddr[1] = p->ninfo.s_macaddr[1];
			p = NULL;
		}
		else{
			free(f_ipkt);
			f_ipkt = NULL;
			pthread_mutex_unlock(&node_mutex_lock);
			return -1;
		}

		pthread_mutex_unlock(&node_mutex_lock);


		if(status){
			f_ipkt->ipkt.status = status;
			f_ipkt->preinit = 1;
		}
		else{
			f_ipkt->preinit = 0;
			if(num > 4){
				num = 4;
			}
			if(num == 1){
				f_ipkt->ipkt.status = 0x10;
			}
			else if (num == 2){
				f_ipkt->ipkt.status = 0x30;
			}
			else if (num == 3){
				f_ipkt->ipkt.status = 0x70;
			}
			else if (num == 4){
				f_ipkt->ipkt.status = 0xf0;
			}
		}
		f_ipkt->ipkt.crc[0] = 0x0;
		f_ipkt->ipkt.crc[1] = 0x0;
		f_ipkt->ipkt.t[0] = 0xef;
		f_ipkt->ipkt.t[1] = 0xdf;
		pthread_t pid;
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

		int ret;
		ret = pthread_create(&pid, &attr, switch_init_pthread, (void *)f_ipkt);
		pthread_attr_destroy(&attr);
		if(ret < 0){
			tl_printf(MSG_ERROR, "pthread_create error,ret=%d\n",ret);
		}

	}
	return 0;
}

int switch_prepare(unsigned char *macaddr, int num, char *message)
{
	if(!macaddr){
		return PARAM_ERROR;
	}   

	INIT_DPKT dpkt;
	memset(&dpkt, 0, DEV_STATUS_PKT_LEN);
	memcpy(&dpkt.macaddr, macaddr, MACADDR_LEN);

	unsigned char short_mac[S_MACADDR_LEN];
	memset(short_mac, 0, S_MACADDR_LEN);

	pthread_mutex_lock(&switch_mutex_lock);

	int ret = find_short_macaddr(&dpkt, short_mac);

	pthread_mutex_unlock(&switch_mutex_lock);
	if(ret == PARAM_NOT_EXIST){
	}   
	else if(ret == SHORTMAC_NOT_EXIST){
		request_mac("long", macaddr, MACADDR_LEN);
	}   
	else if(ret == SHORTMAC_EXIST){
		parse_switch_message(message, short_mac, num);
	} 
}

int switch_prepare_foreach(unsigned char *macaddr, unsigned char switch_status){
	if(!macaddr){
		return PARAM_ERROR;
	}

	int num;
	int status;
	num = switch_status >> 4;
	status = switch_status & 0xf;
	int i = 0;
	while(num){
		if(num & 0x1){
			int s = status & 0x1;
			switch_prepare(macaddr, i, (s?"ON":"OFF"));
		}
		num = num >> 1;
		status = status >> 1;
		i++;
	}
	return 0;
}

