#include "switch.h"
#include "crc.h"
#include "mqttc.h"
#include "serial.h"
#include "node.h"
#include "task.h"
#include "common.h"
#include "node.h"
#include "tl.h"

SWITCH_NODE *head;

void switch_alarm(int signum){
	if(!head){
		return ;
	}

	if (signum == SIGALRM)
	{
		alarm(5);      // 重置定时时间
	}

}

int switch_init(){
	head = (SWITCH_NODE*) malloc(sizeof(SWITCH_NODE));
	if(!head){
		tl_printf(MSG_INFO, "init head failed\n");
		return -1;
	}

	head->next = NULL;
	head->prev = NULL;
	return 0;
}

int find_switch(INIT_DPKT *dpkt){
	INIT_DPKT *tmp = dpkt;
	if(!head || !tmp){
		return PARAM_NOT_EXIST;
	}

	SWITCH_NODE* p = head->next;
	while(p){
		if(!memcmp(p->ninfo.macaddr, tmp->macaddr, MACADDR_LEN)){
			p = NULL;
			return 1;
		}
		p = p->next;
	}
	p = NULL;
	return 0;
}

int insert_tail(SWITCHINFO ninfo){
	SWITCH_NODE* pn = (SWITCH_NODE*)malloc(sizeof(SWITCH_NODE));
	if(!pn){
		return -1;
	}

	memcpy(&pn->ninfo, (const void*)&ninfo, sizeof(SWITCHINFO));
	pn->next = NULL;

	SWITCH_NODE* m = NULL;
	SWITCH_NODE *e = NULL;
	m = head;
	e = m->next;
	while(e){
		m = e;
		e = e->next;
	}

	m->next = pn;
	pn->prev = m;
	return 0;
}


void switch_action(char *cmd, INIT_DPKT* dpkt, SWITCH_SCENE_INFO *scene){
	if(!head){
		return;
	}

	SWITCH_NODE* p = head->next;
	while(p){
		if(!strcmp(cmd, "print")){
			tl_printf(MSG_INFO, "switch");

			tl_printf_array("    macaddr:", p->ninfo.macaddr, MACADDR_LEN);

			tl_printf(MSG_INFO,"    timeout: %d, status: %x\n", p->ninfo.timeout, p->ninfo.status);

			if(p->ninfo.scene.switch_mode[0]){
				tl_printf(MSG_INFO,"    mode: %s\n", p->ninfo.scene.switch_mode);
				if(p->ninfo.scene.switch_scene1[0]){
					tl_printf(MSG_INFO,"    scene1: %s, current %d\n", 
							p->ninfo.scene.switch_scene1, p->ninfo.scene.scene1_current);
				}
				if(p->ninfo.scene.switch_scene2[0]){
					tl_printf(MSG_INFO,"    scene2: %s, current %d\n", 
							p->ninfo.scene.switch_scene2, p->ninfo.scene.scene2_current);
				}
				if(p->ninfo.scene.switch_scene3[0]){
					tl_printf(MSG_INFO,"    scene3: %s, current %d\n", 
							p->ninfo.scene.switch_scene3, p->ninfo.scene.scene3_current);
				}
				if(p->ninfo.scene.switch_scene4[0]){
					tl_printf(MSG_INFO,"    scene4: %s, current %d\n", 
							p->ninfo.scene.switch_scene4, p->ninfo.scene.scene4_current);
				}
			}
			p = p->next;
		}
		else if(!strcmp(cmd, "free")){
			SWITCH_NODE* tp = p->next;
			p->next = NULL;
			p->prev = NULL;
			free(p);
			p = tp;
		}
		else if(!strcmp(cmd, "timer")){
			//			p->ninfo.timeout += 5;
			if(p->ninfo.timeout > MAX_TIME){

				int num = (p->ninfo.status & 0xf0)>> 4;
				int n = 0;
				while(num & 0x1){
					n++;
					num = num >> 1;
				}

				for(int i = 0; i < n; i++){
					switch_active(p->ninfo.macaddr, i, OFFLINE);
				}


				SWITCH_NODE* prev = p->prev;
				SWITCH_NODE* next = p->next;

				if(prev){
					prev->next = next;

				}
				if(next){
					next->prev = prev;
				}
				p->prev = NULL;
				p->next = NULL;
				free(p);

				p = next;
				continue;
			}

			p = p->next;
		}
		else if(!strcmp(cmd, "update") || !strcmp(cmd, "update_status") || !strcmp(cmd, "update_scene")){
			if(!dpkt){
				break;
			}
			if(!memcmp(p->ninfo.macaddr, dpkt->macaddr, MACADDR_LEN)){
				p->ninfo.timeout = 0;
				p->ninfo.status = dpkt->status;
			
				if(!strcmp(cmd, "update") || !strcmp(cmd, "update_scene")){
					memset(&p->ninfo.scene, 0, sizeof(SWITCH_SCENE_INFO));
					memcpy(&p->ninfo.scene, scene, sizeof(SWITCH_SCENE_INFO));
				}
				break;
			}
			p = p->next;
		}
	}
}

int switch_send_foreach(unsigned char *mac, int num, unsigned char status){
	//tl_printf_array("switch report mac",  mac, MACADDR_LEN);
	tl_printf(MSG_INFO, "num %d, status %02x", num, status);
	int i = 0;                                                                                                
	while(num){                                                                                               
		if(num & 0x1){                                                                                        
			unsigned char new_status = (status & (1 << i)) >> i;                                         
			switch_set_status(mac, i, new_status);
			status = status & ~(1 << i) | (new_status << i);                                                  
		}                                                                                                     
		i++;                                                                                                  
		num = num >> 1;                                                                                       
	}  

	return 0;
}

void *switch_status_pthread(void *arg){
	DPKT *pkt = (DPKT *)arg;
	if(!pkt){
		tl_printf(MSG_INFO, "pkt is null\n");
		goto exit;
	}
	unsigned char mac[MACADDR_LEN] = "";
	
	//mac in node table
	pthread_mutex_lock(&node_mutex_lock);
	NODE* node = find_s_node(pkt->s_macaddr);
	if(node){
		memcpy(mac, node->ninfo.macaddr, MACADDR_LEN);
	}
	else{
		tl_printf(MSG_INFO, "mac is not exist\n");
		request_mac("short", pkt->s_macaddr, S_MACADDR_LEN);
		free(arg);
		arg = NULL;
		pkt = NULL;
		pthread_mutex_unlock(&node_mutex_lock);
		return;
	}
	pthread_mutex_unlock(&node_mutex_lock);
	

	pthread_mutex_lock(&switch_mutex_lock);
	unsigned char status = 0;

	int f = find_switch_status(mac, &status);
	if(f == 0){
		SWITCHINFO sdata;
		memset(&sdata, 0, sizeof(SWITCHINFO));
		memcpy(sdata.macaddr, mac, MACADDR_LEN);
		sdata.status = pkt->status & (status | 0x0f);
		
		int is_scene = switch_scene_mode(mac, &sdata.scene);
		
		tl_printf(MSG_INFO, "iscene:%d", is_scene);

		pthread_mutex_lock(&task_mutex_lock);
		int action = ACTION_REPORT;
		if(is_scene){
			action = ACTION_SCENE;
		}
		task_insert(action, DEVICE_SWITCH, (void *)&sdata, sizeof(SWITCHINFO));
		pthread_mutex_unlock(&task_mutex_lock);

	}
exit:
	free(arg);
	arg = NULL;
	pthread_mutex_unlock(&switch_mutex_lock);

	pkt = NULL;
	return NULL;
}

void *switch_init_pthread(void *arg){
	if(!arg){
		tl_printf(MSG_ERROR, "pkt is null\n");
		goto exit;
	}

	INIT_DPKT ipkt = ((FULL_INIT_DPKT *)arg)->ipkt;
	int preinit = ((FULL_INIT_DPKT *)arg)->preinit;
	SWITCH_SCENE_INFO scene = ((FULL_INIT_DPKT *)arg)->scene;

	int ret = 0;
	//	uint16_t _crc = crc16tablefast((char *)ipkt, DEV_STATUS_PKT_LEN - (CRC_LEN + TAIL_LEN) * sizeof(unsigned char));
	//	printf("%x\n", _crc);

	pthread_mutex_lock(&switch_mutex_lock);

	int n = find_switch(&ipkt);
	if(n == 1){
		tl_printf(MSG_INFO, "update swtich\n");
		switch_action("update", &ipkt, &scene);
	}
	else if(n == 0){
		tl_printf(MSG_INFO, "insert switch\n");
		SWITCHINFO snode;

		//memcpy(snode.s_macaddr, ipkt.s_macaddr, S_MACADDR_LEN);// s_mac
		memcpy(snode.macaddr, ipkt.macaddr, MACADDR_LEN);// mac
		snode.status = ipkt.status;
		snode.timeout = 0;
		if(scene.switch_mode[0]){
			memcpy(snode.scene.switch_mode, scene.switch_mode, SWITCH_MODE_LEN);
			if(scene.switch_scene1[0]){
				memcpy(snode.scene.switch_scene1, scene.switch_scene1, SWITCH_SCENE_LEN);
			}
			if(scene.switch_scene2[0]){
				memcpy(snode.scene.switch_scene2, scene.switch_scene2, SWITCH_SCENE_LEN);
			}
			if(scene.switch_scene3[0]){
				memcpy(snode.scene.switch_scene3, scene.switch_scene3, SWITCH_SCENE_LEN);
			}
			if(scene.switch_scene4[0]){
				memcpy(snode.scene.switch_scene4, scene.switch_scene4, SWITCH_SCENE_LEN);
			}
		}

		ret = insert_tail(snode);
	}

	pthread_mutex_unlock(&switch_mutex_lock);
	
	if(!ret){
		if(preinit){
			switch_prepare_foreach(ipkt.macaddr, ipkt.status);
		}
		else{
			if(!scene.switch_mode[0]){
				query_switch("ON", ipkt.s_macaddr, 0);
			}
		}
	}

exit: 
	free(arg);
	arg = NULL;
	return NULL;
}

int switch_final_init(unsigned char* macaddr, SWITCH_REG_INFO sreginfo){
	if(!macaddr){
		return -1;
	}
	int num = sreginfo.switch_num;
	const unsigned char status = sreginfo.switch_status;
	const char* mode = sreginfo.switch_scene.switch_mode;
	const char* scene1 = sreginfo.switch_scene.switch_scene1;
	const char* scene2 = sreginfo.switch_scene.switch_scene2;
	const char* scene3 = sreginfo.switch_scene.switch_scene3;
	const char* scene4 = sreginfo.switch_scene.switch_scene4;

	tl_printf(MSG_INFO,"switch init num:%d, status:0x%02x", num, status);
	if(mode[0])
		tl_printf(MSG_INFO, "mode:%s", mode);
	if(scene1[0])
		tl_printf(MSG_INFO, "scene 1:%s", scene1);
	if(scene2[0])
		tl_printf(MSG_INFO, "scene 2:%s", scene2);
	if(scene3[0])
		tl_printf(MSG_INFO, "scene 3:%s", scene3);
	if(scene4[0])
		tl_printf(MSG_INFO, "scene 4:%s", scene4);

	FULL_INIT_DPKT *f_ipkt = malloc(FULL_INIT_DEV_STATUS_PKT_LEN);
	if(f_ipkt){
		memset(f_ipkt, 0, sizeof(FULL_INIT_DEV_STATUS_PKT_LEN));
		pthread_mutex_lock(&node_mutex_lock);
		NODE* p = find_node(macaddr);
		if(p){
			f_ipkt->ipkt.s_macaddr[0] = p->ninfo.s_macaddr[0];
			f_ipkt->ipkt.s_macaddr[1] = p->ninfo.s_macaddr[1];
			p = NULL;
		}
		else{
			free(f_ipkt);
			f_ipkt = NULL;
			pthread_mutex_unlock(&node_mutex_lock);
			return -1;
		}

		pthread_mutex_unlock(&node_mutex_lock);

		f_ipkt->ipkt.h[0] = 0xfe;
		f_ipkt->ipkt.h[1] = 0xfd;
		f_ipkt->ipkt.parent[0] = 0x0;
		f_ipkt->ipkt.parent[1] = 0x1;

		memcpy(f_ipkt->ipkt.macaddr, macaddr, MACADDR_LEN);

		if(status){
			f_ipkt->ipkt.status = status;
			f_ipkt->preinit = 1;
		}
		else{
			f_ipkt->preinit = 0;
			if(num > 4){
				num = 4;
			}
			if(num == 1){
				f_ipkt->ipkt.status = 0x10;
			}
			else if (num == 2){
				f_ipkt->ipkt.status = 0x30;
			}
			else if (num == 3){
				f_ipkt->ipkt.status = 0x70;
			}
			else if (num == 4){
				f_ipkt->ipkt.status = 0xf0;
			}
		}
		f_ipkt->ipkt.crc[0] = 0x0;
		f_ipkt->ipkt.crc[1] = 0x0;
		f_ipkt->ipkt.t[0] = 0xef;
		f_ipkt->ipkt.t[1] = 0xdf;

		if(mode){
			memcpy(f_ipkt->scene.switch_mode, mode, SWITCH_MODE_LEN);
			if(scene1){
				memcpy(f_ipkt->scene.switch_scene1, scene1, SWITCH_SCENE_LEN);
			}
			if(scene2){
				memcpy(f_ipkt->scene.switch_scene2, scene2, SWITCH_SCENE_LEN);
			}
			if(scene3){
				memcpy(f_ipkt->scene.switch_scene3, scene3, SWITCH_SCENE_LEN);
			}
			if(scene4){
				memcpy(f_ipkt->scene.switch_scene4, scene4, SWITCH_SCENE_LEN);
			}
			f_ipkt->scene.scene1_current = 0;
			f_ipkt->scene.scene2_current = 0;
			f_ipkt->scene.scene3_current = 0;
			f_ipkt->scene.scene4_current = 0;
		}

		pthread_t pid;
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

		int ret;
		ret = pthread_create(&pid, &attr, switch_init_pthread, (void *)f_ipkt);
		pthread_attr_destroy(&attr);
		if(ret < 0){
			tl_printf(MSG_ERROR, "pthread_create error,ret=%d\n",ret);
		}

	}
	return 0;
}

int switch_prepare(unsigned char *macaddr, int num, char *message)
{
	if(!macaddr){
		return PARAM_ERROR;
	}   
	//check if duplex mode
	

	int ret = 0;
	unsigned char short_mac[S_MACADDR_LEN] = "";

	pthread_mutex_lock(&node_mutex_lock);
	NODE* p = find_node(macaddr);
	if(p){
		memcpy(short_mac, p->ninfo.s_macaddr, S_MACADDR_LEN);
		ret = 1;
		p = NULL;
	}
	pthread_mutex_unlock(&node_mutex_lock);

	//request_mac("long", macaddr, MACADDR_LEN);
	if(ret){
		parse_switch_message(message, short_mac, num);
	} 
}

int switch_prepare_foreach(unsigned char *macaddr, unsigned char switch_status){
	if(!macaddr){
		return PARAM_ERROR;
	}

	int num;
	int status;
	num = switch_status >> 4;
	status = switch_status & 0xf;
	int i = 0;
	while(num){
		if(num & 0x1){
			int s = status & 0x1;
			switch_prepare(macaddr, i, (s?"ON":"OFF"));
		}
		num = num >> 1;
		status = status >> 1;
		i++;
	}
	return 0;
}

int switch_scene_mode(unsigned char *macaddr, SWITCH_SCENE_INFO *scene){
	if(!macaddr || !scene){
		return 0;
	}
	
	SWITCH_NODE* p = head->next;
	while(p){
		if(!memcmp(p->ninfo.macaddr, macaddr, MACADDR_LEN)){
			if(p->ninfo.scene.switch_mode[0]){
				memcpy(scene, &p->ninfo.scene, sizeof(SWITCH_SCENE_INFO));
				return 1;
			}
		}
		p = p->next;
	}
	return 0;
}

int find_switch_status(unsigned char *macaddr, unsigned char *status){
	if(!macaddr){
		return -1;
	}

	SWITCH_NODE* p = head->next;
	while(p){
		if(!memcmp(p->ninfo.macaddr, macaddr, MACADDR_LEN)){
			memcpy(status, &p->ninfo.status, sizeof(unsigned char));
			p = NULL;
			return 0;
		}
		p = p->next;
	}
	return -1;
}
