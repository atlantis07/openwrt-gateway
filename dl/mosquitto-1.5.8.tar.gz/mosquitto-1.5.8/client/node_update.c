#include "common.h"
#include "node_update.h"
#include "node.h"
#include "serial.h"
void next_img_response(unsigned char *n){
	NODE_UPDATE_FILE_HEADER header;
	zclOTA_QueryImageRspParams_t queryRsp;
	NODE_NEXTIMG_REQ *_n = (NODE_NEXTIMG_REQ *)n; 	

	memset(&header, 0, NODE_UPDATE_FILE_HEADER_LEN);
	memset(&queryRsp, 0, sizeof(zclOTA_QueryImageRspParams_t));
	memcpy ( &queryRsp.fileId, &_n->f, sizeof ( zclOTA_FileID_t ));

    queryRsp.imageSize = 0;
	queryRsp.status = ZOtaNoImageAvailable;

	int status = check_image(_n->dt, &header);
	if(status == ZSuccess){
    	if((header.manufacturer == _n->f.manufacturer) &&
			(header.type == _n->f.type)){
			if(header.filever > _n->f.version){
				queryRsp.status = ZSuccess;
				queryRsp.imageSize = header.imgsize;
			}
		}	
	}

	//unsigned char data[] = {0x1, 0x0, 0x2, 0x00, 0x80, 0xff, 0xff};
						//event status
	//sendto_zigbee(data, 7);
	return;
}

void img_block_response(unsigned char *n){
	NODE_UPDATE_FILE_HEADER header;
	NODE_BLOCK_REQ *_n = (NODE_BLOCK_REQ *)n; 	

	memset(&header, 0, NODE_UPDATE_FILE_HEADER_LEN);
	
	zclOTA_ImageBlockRspParams_t blockRsp;
	int status = check_image(_n->dt, &header);
	if(status == ZSuccess){
    	if((header.manufacturer == _n->f.manufacturer) &&
			(header.type == _n->f.type)&&
			(header.filever == _n->f.version)){
			uint8 data[NODE_BLOCK_REQ_MAX_DATA_LEN];
			memset(data, 0, NODE_BLOCK_REQ_MAX_DATA_LEN);

			get_image(_n->dt, _n->offset, _n->reqlen, data);
			blockRsp.status = ZSuccess;
			memcpy ( &blockRsp.rsp.success.fileId, &_n->f, sizeof ( zclOTA_FileID_t ));
			blockRsp.rsp.success.fileOffset = _n->offset;
			blockRsp.rsp.success.dataSize = _n->reqlen;
			blockRsp.rsp.success.pData = data;	
		}
		else{
		}
	}

	return;
}

int get_image(uint8 dt, uint32 offset, uint8 len, uint8 *data){
	int status = ZSuccess;
	int fd;
	if(dt != 0x00){
		fd = open(ED_UPDATE_FILE, O_RDONLY);
	}
	else{
		fd = open(ZR_UPDATE_FILE, O_RDONLY);
	}

	
	if(fd < 0){
		status = ZOtaAbort;
		goto end;
	}

	int ret = lseek(fd, offset, SEEK_SET);
	if(ret < 0){
		close(fd);
		status = ZOtaAbort;
		goto end;
	}

	ret = read(fd, data, len);
	if(ret != len){
		close(fd);
		status = ZOtaAbort;
		goto end;
	}
	close(fd);
end:
	return status;
}

int check_image(uint8 dt, NODE_UPDATE_FILE_HEADER *header){
	int status = ZSuccess;
	int fd;
	if(dt != 0x00){
		fd = open(ED_UPDATE_FILE, O_RDONLY);
	}
	else{
		fd = open(ZR_UPDATE_FILE, O_RDONLY);
	}
	if(fd < 0){
		status = ZOtaNoImageAvailable;
		goto end;
	}

	NODE_UPDATE_FILE_HEADER fh;
	int ret = read(fd, (void *)&fh, NODE_UPDATE_FILE_HEADER_LEN);
	if(ret != NODE_UPDATE_FILE_HEADER_LEN){
		close(fd);
		status = ZOtaAbort;
		goto end;
	}

	memcpy(header, &fh, NODE_UPDATE_FILE_HEADER_LEN);
	close(fd);
end:
	return status;
}


void *node_update(void *arg){
    tl_printf(MSG_INFO, "node update");
	uint8 *n = (uint8 *)arg;
    if(!n){
        tl_printf(MSG_INFO, "node update failed\n");
        goto exit;
    }   
    pthread_mutex_lock(&node_mutex_lock);
//    NODE* f = find_s_node(&n->edev.saddr);
//    if(f){
	switch(n[5]){
		case COMMAND_QUERY_NEXT_IMAGE_REQ:
			if(n[3] == 25){
				next_img_response(n);
			}
			break;
		case COMMAND_IMAGE_BLOCK_REQ:
			if(n[3] == 29){
				img_block_response(n); 
			}
		default:
			break;
	}
//    }   
//    else{
//        request_mac("short", n->s_macaddr, S_MACADDR_LEN);
//    }   
//    f = NULL;
    pthread_mutex_unlock(&node_mutex_lock);
exit:
    n = NULL;
    free(arg);
    arg = NULL;
    return NULL;
}

