#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include "uci.h"
#include "common.h"

bool load_config(char *mac, int len)
{
	struct uci_context * ctx = NULL;
	struct uci_package * pkg = NULL;
	struct uci_element *e;
	char *value = NULL;

	ctx = uci_alloc_context();//  申请一个UCI上下文.
	if (UCI_OK != uci_load(ctx, UCI_CONFIG_FILE, &pkg))
		goto cleanup;// 如果打开UCI文件失败,则跳到末尾 清理 UCI 上下文.


	/*遍历UCI的每一个节*/
	uci_foreach_element(&pkg->sections, e)
	{
		struct uci_section *s = uci_to_section(e);
		//将一个 element 转换为 section类型, 如果节点有名字,则 s->anonymous 为 false.
		// 此时通过 s->e->name 来获取.
		// 此时 您可以通过 uci_lookup_option()来获取 当前节下的一个值.
		
		if(!strcmp(s->e.name, "wan_dev")){
			if (NULL != (value = uci_lookup_option_string(ctx, s, "macaddr")))
			{

				memcpy(mac, value, strlen(value) < len? strlen(value):len);
			}
		}

		// 如果您不确定是 string类型 可以先使用 uci_lookup_option() 函数得到Option 然后再判断.
		// Option 的类型有 UCI_TYPE_STRING 和 UCI_TYPE_LIST 两种.


	}
	uci_unload(ctx, pkg); // 释放 pkg 
cleanup:
	uci_free_context(ctx);
	ctx = NULL;
}

bool uci_load_macaddr(char *mac){
	char macaddr[MAX_SMACADDR];
	unsigned char _macaddr[MAX_MACADDR];
	memset(macaddr, 0, MAX_SMACADDR);
	memset(_macaddr, 0, MAX_MACADDR);

	load_config(macaddr, MAX_SMACADDR);
	int ret = sscanf(macaddr, "%02x:%02x:%02x:%02x:%02x:%02x", &_macaddr[0], &_macaddr[1],
			&_macaddr[2], &_macaddr[3],
			&_macaddr[4], &_macaddr[5]);
	if(ret != MAX_MACADDR)
		return false;

	memset(macaddr, 0, MAX_SMACADDR);
	ret = sprintf(macaddr, "%02x%02x%02x%02x%02x%02x", _macaddr[0], _macaddr[1], 
			_macaddr[2], _macaddr[3], _macaddr[4], _macaddr[5]);

	if(ret != 2*MAX_MACADDR)
		return false;

	memcpy(mac, macaddr, ret);
	return true;
}

int uci_checktype(char *macaddr, char *type){
	struct uci_context * ctx = NULL;
	struct uci_package * pkg = NULL;
	struct uci_element *e;
	char *value = NULL;
	int ret = TYPE_UNKNOWN;
	ctx = uci_alloc_context();//  申请一个UCI上下文.
	if (UCI_OK != uci_load(ctx, DEV_CONFIG_FILE, &pkg)){
		printf("uci load error\n");
		goto cleanup;// 如果打开UCI文件失败,则跳到末尾 清理 UCI 上下文.
	}

	uci_foreach_element(&pkg->sections, e)
	{
		struct uci_section *s = uci_to_section(e);
		//将一个 element 转换为 section类型, 如果节点有名字,则 s->anonymous 为 false.
		// 此时通过 s->e->name 来获取.
		// 此时 您可以通过 uci_lookup_option()来获取 当前节下的一个值.

		if(!strcmp(s->e.name, macaddr)){
			if (NULL != (value = uci_lookup_option_string(ctx, s, type)))
			{
				if(!strcmp(value, "1")){
					ret = 0;
				}
			}
		}
		// 如果您不确定是 string类型 可以先使用 uci_lookup_option() 函数得到Option 然后再判断.
		// Option 的类型有 UCI_TYPE_STRING 和 UCI_TYPE_LIST 两种.


	}
	uci_unload(ctx, pkg); // 释放 pkg 
cleanup:
	uci_free_context(ctx);
	ctx = NULL;
	return ret;
}

int uci_get_switch(char *macaddr, unsigned char *status, unsigned char *way){
	struct uci_context * ctx = NULL;
	struct uci_package * pkg = NULL;
	struct uci_element *e;
	char *value = NULL;
	int ret = -1;
	int rway = -1, rstatus = -1;
	ctx = uci_alloc_context();
	if (UCI_OK != uci_load(ctx, DEV_CONFIG_FILE, &pkg))
		goto cleanup;

	uci_foreach_element(&pkg->sections, e)
	{
		struct uci_section *s = uci_to_section(e);
		
		if(!strcmp(s->e.name, macaddr)){
			if (NULL != (value = uci_lookup_option_string(ctx, s, "switch_way")))
			{
				int ret = sscanf(value, "%d", way);
				rway = 0;
			}
			
			if (NULL != (value = uci_lookup_option_string(ctx, s, "switch_status"))){
				int ret = sscanf(value, "%02x", status);
				rstatus = 0;
			}
		}
		// 如果您不确定是 string类型 可以先使用 uci_lookup_option() 函数得到Option 然后再判断.
		// Option 的类型有 UCI_TYPE_STRING 和 UCI_TYPE_LIST 两种.
	}
	uci_unload(ctx, pkg); // 释放 pkg 
	if(!rway && !rstatus){
		ret = 0;
	}
cleanup:
	uci_free_context(ctx);
	ctx = NULL;
	return ret;
}

int uci_get_aircondition(char *macaddr, unsigned char *addr){
	struct uci_context * ctx = NULL;
	struct uci_package * pkg = NULL;
	struct uci_element *e;
	char *value = NULL;
	int ret = -1;
	int raddr = -1;
	ctx = uci_alloc_context();
	if (UCI_OK != uci_load(ctx, DEV_CONFIG_FILE, &pkg))
		goto cleanup;

	uci_foreach_element(&pkg->sections, e)
	{
		struct uci_section *s = uci_to_section(e);
		
		if(!strcmp(s->e.name, macaddr)){
			if (NULL != (value = uci_lookup_option_string(ctx, s, "aircondition_addr")))
			{
				sscanf(value, "%02x%02x", &addr[0], &addr[1]);
				raddr = 0;
			}
		}
		// 如果您不确定是 string类型 可以先使用 uci_lookup_option() 函数得到Option 然后再判断.
		// Option 的类型有 UCI_TYPE_STRING 和 UCI_TYPE_LIST 两种.
	}
	uci_unload(ctx, pkg); // 释放 pkg 
	if(!raddr){
		ret = 0;
	}
cleanup:
	uci_free_context(ctx);
	ctx = NULL;
	return ret;
}
