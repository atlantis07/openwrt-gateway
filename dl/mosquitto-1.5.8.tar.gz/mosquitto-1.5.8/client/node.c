#include "node.h"
NODE* node_head = NULL;

int node_init(){
	node_head = (NODE*) malloc(sizeof(NODE));
	if(!node_head){
		tl_printf(MSG_ERROR,"init node failed\n");
		return -1; 
	}   

	node_head->next = NULL;
	node_head->prev = NULL;
	return 0;
}

NODE* find_node(unsigned char* nodemacaddr){
	NODE* p = node_head->next;
	while(p){
		if(!memcmp(p->ninfo.macaddr, nodemacaddr, MACADDR_LEN)){
			return p;
		}   
		p = p->next;
	}   
	return p;
}

NODE* find_s_node(unsigned char* nodesmacaddr){
	NODE* p = node_head->next;
	while(p){
		if(!memcmp(p->ninfo.s_macaddr, nodesmacaddr, S_MACADDR_LEN)){
			return p;
		}   
		p = p->next;
	}   
	return p;
}

int node_insert_tail(NODE_INFO info){
	NODE* pn = (NODE*)malloc(sizeof(NODE));
	if(!pn){
		return -1;
	}

	//memcpy(&pn->ninfo, (const void*)&info, sizeof(NODE_INFO));
	memcpy(pn->ninfo.s_macaddr, (const void*)info.s_macaddr, S_MACADDR_LEN);
	memcpy(pn->ninfo.macaddr, (const void*)info.macaddr, MACADDR_LEN);
	pn->ninfo.reg = info.reg;

	pn->next = NULL;

	NODE* m = NULL;
	NODE *e = NULL;
	m = node_head;
	e = m->next;
	while(e){
		m = e;
		e = e->next;
	}

	m->next = pn;
	pn->prev = m;
	return 0;
}

void *node_preinit(void *arg){
	unsigned char *addr = (unsigned char *)arg;
	if(!addr){
		tl_printf(MSG_INFO, "node init failed\n");
		goto exit;
	}
 
	NODE_INFO ninfo;
//	if(!addr || (len < (S_MACADDR_LEN + MACADDR_LEN))){
//		return -1;
//	}

	memcpy(ninfo.s_macaddr, addr, S_MACADDR_LEN);
	memcpy(ninfo.macaddr, addr + S_MACADDR_LEN, MACADDR_LEN);
	ninfo.reg = 0;

	pthread_mutex_lock(&node_mutex_lock);
	int ret;
	if(ninfo.macaddr){
		NODE* f = find_node(ninfo.macaddr);
		if(!f){
			ret = node_insert_tail(ninfo);
		}
		else{
			memcpy(f->ninfo.s_macaddr, ninfo.s_macaddr, S_MACADDR_LEN);
			//update node
		}
		f = NULL;
	}

	pthread_mutex_unlock(&node_mutex_lock);
	if(ret < 0){
		goto exit;
	}

	char strmacaddr[LEN64] = "";
	char topic[LEN128] = "";
	char get_config[LEN256] = "";

	sprintf(strmacaddr, "%02x%02x%02x%02x%02x%02x%02x%02x", 
			ninfo.macaddr[0], ninfo.macaddr[1], ninfo.macaddr[2], ninfo.macaddr[3],
			ninfo.macaddr[4], ninfo.macaddr[5], ninfo.macaddr[6], ninfo.macaddr[7]
			);
	sprintf(topic, "%s/node/%s/get_config", gwmacaddr, strmacaddr);
	sprintf(get_config, "mosquitto_pub -h %s -t '%s' -m 'test' ", serveripaddr, topic);
	tl_printf(MSG_INFO, "%s\n", get_config);
	system(get_config);

exit:
	free(arg);
	arg = NULL;
	addr = NULL;
	return NULL;
}

void *node_heartbeat(void *arg){
	int sig;
	char sig_cmd[128] = "";
	char smac[128] = "";

	NODE_INFO *n = (NODE_INFO *)arg;
	if(!n){
		tl_printf(MSG_INFO, "node init failed\n");
		goto exit;
	}
	pthread_mutex_lock(&node_mutex_lock);
	NODE* f = find_s_node(n->s_macaddr);
	if(f){
		int symbol = ((n->signal & 0x80) >> 7)? -1:1;
		f->ninfo.signal = symbol * ( n->signal & 0x7f);
		sig = f->ninfo.signal;		

		sprintf(smac, "%02x%02x%02x%02x%02x%02x%02x%02x", 
				f->ninfo.macaddr[0], f->ninfo.macaddr[1], f->ninfo.macaddr[2], f->ninfo.macaddr[3],
				f->ninfo.macaddr[4], f->ninfo.macaddr[5], f->ninfo.macaddr[6], f->ninfo.macaddr[7]
				);

		sprintf(sig_cmd, "mosquitto_pub -h %s -t '%s/signal/%s/value' -m '%02d'", serveripaddr, gwmacaddr, smac, f->ninfo.signal);
	}
	else{
		request_mac("short", n->s_macaddr, S_MACADDR_LEN);
	}
	f = NULL;
	pthread_mutex_unlock(&node_mutex_lock);

	if(sig){
		system(sig_cmd);
	}
exit:
	n = NULL;
	free(arg);
	arg = NULL;
	return NULL;
}


void node_action(char *type){
	if(!type)
		return;

	if(!strcmp(type, "print")){
		NODE *p = node_head->next;
		while(p){
			tl_printf(MSG_INFO, "node	");
			tl_printf_array("    macaddr:", p->ninfo.macaddr, MACADDR_LEN);
			tl_printf_array("    smacaddr:", p->ninfo.s_macaddr, S_MACADDR_LEN);

			tl_printf(MSG_INFO, "    signal: %d\n", p->ninfo.signal);

			p = p->next;
		}   
	}   
}
