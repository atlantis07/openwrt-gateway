#include "node.h"
#include "timer.h"
NODE* node_head = NULL;

int node_init(){
	node_head = (NODE*) malloc(sizeof(NODE));
	if(!node_head){
		tl_printf(MSG_ERROR,"init node failed\n");
		return -1; 
	}   

	node_head->next = NULL;
	node_head->prev = NULL;
	return 0;
}

NODE* find_node(unsigned char* nodemacaddr){
	NODE* p = node_head->next;
	while(p){
		if(!memcmp(p->ninfo.macaddr, nodemacaddr, MACADDR_LEN)){
			return p;
		}   
		p = p->next;
	}   
	return p;
}

NODE* find_s_node(unsigned char* nodesmacaddr){
	NODE* p = node_head->next;
	while(p){
		if(!memcmp(p->ninfo.s_macaddr, nodesmacaddr, S_MACADDR_LEN)){
			return p;
		}   
		p = p->next;
	}   
	return p;
}

int node_insert_tail(NODE_INFO info){
	NODE* pn = (NODE*)malloc(sizeof(NODE));
	if(!pn){
		return -1;
	}

	//memcpy(&pn->ninfo, (const void*)&info, sizeof(NODE_INFO));
	memcpy(pn->ninfo.s_macaddr, (const void*)info.s_macaddr, S_MACADDR_LEN);
	memcpy(pn->ninfo.macaddr, (const void*)info.macaddr, MACADDR_LEN);
	pn->ninfo.reg = info.reg;

	pn->next = NULL;

	NODE* m = NULL;
	NODE *e = NULL;
	m = node_head;
	e = m->next;
	while(e){
		m = e;
		e = e->next;
	}

	m->next = pn;
	pn->prev = m;
	return 0;
}

void *node_preinit(void *arg){
	unsigned char *addr = (unsigned char *)arg;
	if(!addr){
		tl_printf(MSG_INFO, "node init failed\n");
		goto exit;
	}
 
	NODE_INFO ninfo;
//	if(!addr || (len < (S_MACADDR_LEN + MACADDR_LEN))){
//		return -1;
//	}

	memcpy(ninfo.s_macaddr, addr, S_MACADDR_LEN);
	memcpy(ninfo.macaddr, addr + S_MACADDR_LEN, MACADDR_LEN);
	ninfo.reg = 0;
	ninfo.signal = 0;
	ninfo.timeout = 0;

	pthread_mutex_lock(&node_mutex_lock);
	int ret;
	if(ninfo.macaddr){
		NODE* f_s = find_s_node(ninfo.s_macaddr);
		if(f_s){
			//short mac is already exist, del that node
			tl_printf(MSG_WARNING, "short mac %02x %02x is already exist, remove it", ninfo.s_macaddr[0],
				ninfo.s_macaddr[1]);
			del_s_node(ninfo.s_macaddr);
		}

		NODE* f = find_node(ninfo.macaddr);
		if(!f){
			ret = node_insert_tail(ninfo);
		}
		else{
			memcpy(f->ninfo.s_macaddr, ninfo.s_macaddr, S_MACADDR_LEN);
			f->ninfo.reg = 0;
			f->ninfo.signal = 0;
			f->ninfo.timeout = 0;
			//update node
		}
		f = NULL;
	}

	pthread_mutex_unlock(&node_mutex_lock);
	if(ret < 0){
		goto exit;
	}

	char strmacaddr[LEN64] = "";
	char topic[LEN128] = "";
	char get_config[LEN256] = "";

	sprintf(strmacaddr, "%02x%02x%02x%02x%02x%02x%02x%02x", 
			ninfo.macaddr[0], ninfo.macaddr[1], ninfo.macaddr[2], ninfo.macaddr[3],
			ninfo.macaddr[4], ninfo.macaddr[5], ninfo.macaddr[6], ninfo.macaddr[7]
			);
	sprintf(topic, "%s/node/%s/get_config", gwmacaddr, strmacaddr);
	sprintf(get_config, "mosquitto_pub -h %s -t '%s' -m 'test' ", serveripaddr, topic);
//	tl_printf(MSG_INFO, "%s\n", get_config);
	system(get_config);

exit:
	free(arg);
	arg = NULL;
	addr = NULL;
	return NULL;
}

int node_finalinit(unsigned char *macaddr){
	if(!macaddr){
		return PARAM_ERROR;
	}
	
	pthread_mutex_lock(&node_mutex_lock);
	int ret;
	if(macaddr){
		NODE* f = find_node(macaddr);
		if(f){
			//memcpy(f->ninfo.s_macaddr, ninfo.s_macaddr, S_MACADDR_LEN);
			f->ninfo.reg = 1;
			f->ninfo.signal = 0;
			f->ninfo.timeout = 0;
			//update node
		}
		f = NULL;
	}

	pthread_mutex_unlock(&node_mutex_lock);
	return 0;
}

void *node_heartbeat(void *arg){
	NODE_INFO *n = (NODE_INFO *)arg;
	if(!n){
		tl_printf(MSG_INFO, "node heartbeat failed\n");
		goto exit;
	}
	pthread_mutex_lock(&node_mutex_lock);
	NODE* f = find_s_node(n->s_macaddr);
	if(f){
		int symbol = (n->signal >> 7)? -1:1;
		f->ninfo.signal = symbol * ( n->signal & 0x7f);
		f->ninfo.timeout = 0;
	}
	else{
		request_mac("short", n->s_macaddr, S_MACADDR_LEN);
	}
	f = NULL;
	pthread_mutex_unlock(&node_mutex_lock);
exit:
	n = NULL;
	free(arg);
	arg = NULL;
	return NULL;
}

void *node_scene_heartbeat(void *arg){
	NODE_INFO *n = (NODE_INFO *)arg;
	if(!n){
		tl_printf(MSG_INFO, "node heartbeat failed\n");
		goto exit;
	}
	unsigned find = 0;
	pthread_mutex_lock(&node_mutex_lock);
	NODE* f = find_s_node(n->s_macaddr);
	if(f){
		int symbol = (n->signal >> 7)? -1:1;
		f->ninfo.signal = symbol * ( n->signal & 0x7f);
		f->ninfo.timeout = 0;
		find = 1;
	}
	f = NULL;
	pthread_mutex_unlock(&node_mutex_lock);


	if(!find){
		unsigned char pkt[PKT_INIT_LEN] = {0xfe, 0xfd, 0xf2, 0x0f,
										n->s_macaddr[0], n->s_macaddr[1], 0x0, 0x0, 
										n->s_macaddr[0], n->s_macaddr[1],
										n->macaddr[0], n->macaddr[1], n->macaddr[2], n->macaddr[3],
										n->macaddr[4], n->macaddr[5], n->macaddr[6], n->macaddr[7],
										0xf0, 0x0, 0x0, 0xef, 0xdf};
		unsigned short crc = crc16table(pkt, PKT_INIT_LEN - 4);
		pkt[PKT_INIT_LEN - 4] = crc & 0xff;
		pkt[PKT_INIT_LEN - 3] = crc >> 8;
		parse_packets(pkt, PKT_INIT_LEN);
	}
exit:
	n = NULL;
	free(arg);
	arg = NULL;
	return NULL;
}

void node_action(char *type){
	if(!type)
		return;

	NODE *p = node_head->next;
	while(p){
		NODE  *next = p->next;
		p->ninfo.timeout += TIMER_INTERVAL;
		char strmacaddr[LEN64] = ""; 
		sprintf(strmacaddr, "%02x%02x%02x%02x%02x%02x%02x%02x", 
				p->ninfo.macaddr[0], p->ninfo.macaddr[1], 
				p->ninfo.macaddr[2], p->ninfo.macaddr[3],
				p->ninfo.macaddr[4], p->ninfo.macaddr[5], 
				p->ninfo.macaddr[6], p->ninfo.macaddr[7]);

		if(strstr(type, "print")){
			tl_printf(MSG_INFO, "node	");
			tl_printf_array("    macaddr:", p->ninfo.macaddr, MACADDR_LEN);
			tl_printf_array("    smacaddr:", p->ninfo.s_macaddr, S_MACADDR_LEN);
			tl_printf(MSG_INFO, "    signal: %d\n", p->ninfo.signal);
			tl_printf(MSG_INFO, "   timeout: %d\n", p->ninfo.timeout);
			tl_printf(MSG_INFO, "    reg: %d\n", p->ninfo.reg);
		}
		if(strstr(type, "reg")){
			if(p->ninfo.reg == 0){
				char topic[LEN128] = ""; 
				char get_config[LEN256] = ""; 
				sprintf(topic, "%s/node/%s/get_config", gwmacaddr, strmacaddr);
				sprintf(get_config, "mosquitto_pub -h %s -t '%s' -m 'test' ", serveripaddr, topic);
				tl_printf(MSG_INFO, "%s\n", get_config);
				system(get_config);
			}
		}
		if(strstr(type, "signal")){
			if((p->ninfo.timeout < NODE_MAX_TIMEOUT)&&(p->ninfo.signal != 0)){
				char sig_cmd[128] = "";
				sprintf(sig_cmd, "mosquitto_pub -h %s -t '%s/signal/%s/value' -m '%02d'", 
					serveripaddr, gwmacaddr, strmacaddr, p->ninfo.signal);
				system(sig_cmd);
			}
		}
		if(strstr(type, "free")){
			p->prev = NULL;
			p->next = NULL;
			free(p);
		}
		if(strstr(type, "timeout")){
			if(p->ninfo.timeout >= NODE_MAX_TIMEOUT){
				NODE *prev = p->prev;		
				prev->next = next;
				if(next){
					next->prev = prev;
				}
				p->prev = NULL;
				p->next = NULL;
				free(p);
			}
		}
		p = next;
	}
	p = NULL;
}

void del_s_node(unsigned char *s_macaddr){
	NODE *p = node_head->next;
	while(p){
		NODE *prev = p->prev;
		NODE *next = p->next;
		if(!memcmp(s_macaddr, p->ninfo.s_macaddr, S_MACADDR_LEN)){
			tl_printf(MSG_WARNING, "DEL Node:%02x %02x", p->ninfo.s_macaddr[0], p->ninfo.s_macaddr[1]);
			prev->next = next;
			if(next){
				next->prev = prev;
			}
			p->prev = NULL;
			p->next = NULL;
			free(p);
		}
		p = next;
	}
	p = NULL;
	return ;
}
