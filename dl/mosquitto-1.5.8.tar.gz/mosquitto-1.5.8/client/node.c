#include "node.h"
#include "crc.h"
#include "mqttc.h"
#include "serial.h"
#include "common.h"

NODE *head;

void node_alarm(int signum){
	if(!head){
		return ;
	}

	if (signum == SIGALRM)
	{
		alarm(5);      // 重置定时时间
	}

}

int node_init(){
	head = (NODE*) malloc(sizeof(NODE));
	if(!head){
		printf("init head failed\n");
		return -1;
	}

	head->next = NULL;
	head->prev = NULL;
	return 0;
}

int find_full_mac_and_status(DPKT *dpkt, unsigned char *mac, unsigned char *status,
		unsigned char *proc){
	if(!dpkt || !mac){
		return PARAM_NOT_EXIST;
	}

	DPKT *tmp = dpkt;
	NODE* p = head->next;
	while(p){
		if(!memcmp(p->ninfo.s_macaddr, tmp->s_macaddr, S_MACADDR_LEN)){
			if(mac){
				memcpy(mac, p->ninfo.macaddr, MACADDR_LEN);
			}
			if(status){
				memcpy(status, &(p->ninfo.status), sizeof(unsigned char));
				//*status = p->ninfo.status;
			}
			if(proc){
				//*proc = p->ninfo.proc;
				memcpy(proc, &(p->ninfo.proc), sizeof(unsigned char));
			}
			return MAC_EXIST;
		}
		p = p->next;
	}

	return MAC_NOT_EXIST;
}

int find_node(INIT_DPKT *dpkt){
	INIT_DPKT *tmp = dpkt;
	if(!head || !tmp){
		return PARAM_NOT_EXIST;
	}

	NODE* p = head->next;
	while(p){
		if(!memcmp(p->ninfo.macaddr, tmp->macaddr, MACADDR_LEN)){
			return 1;
		}
		p = p->next;
	}
	return 0;
}

int find_short_macaddr(INIT_DPKT *dpkt, unsigned char *short_mac){
	INIT_DPKT *tmp = dpkt;
	if(!head || !tmp){
		return PARAM_NOT_EXIST;
	}

	NODE* p = head->next;
	while(p){
		if(!memcmp(p->ninfo.macaddr, tmp->macaddr, MACADDR_LEN)){
			memcpy(short_mac, p->ninfo.s_macaddr, S_MACADDR_LEN);
			return SHORTMAC_EXIST;
		}
		p = p->next;
	}
	return SHORTMAC_NOT_EXIST;

}

int insert_tail(struct nodeinfo ninfo){
	NODE* pn = (NODE*)malloc(sizeof(NODE));
	if(!pn){
		return -1;
	}

	memcpy(&pn->ninfo, (const void*)&ninfo, sizeof(struct nodeinfo));
	pn->next = NULL;

	NODE* m = NULL;
	NODE *e = NULL;
	m = head;
	e = m->next;
	while(e){
		m = e;
		e = e->next;
	}

	m->next = pn;
	pn->prev = m;
	return 0;
}


void node_action(char *cmd, INIT_DPKT* dpkt){
	NODE* p = head;

	if(strcmp(cmd, "free")){
		if(!p){
			return;
		}
		else{
			p = p->next;
		}
	}

	while(p){
		if(!strcmp(cmd, "print")){
			printf("short mac:");
			for(int i = 0;i < 2; i++){
				printf("%02x ", p->ninfo.s_macaddr[i]);
			}
			printf(", mac:");
			for(int i = 0;i < 8; i++){
				printf("%02x ", p->ninfo.macaddr[i]);
			}
			printf(", timeout: %d, status: %x\n", p->ninfo.timeout, p->ninfo.status);
			p = p->next;
		}
		else if(!strcmp(cmd, "free")){
			NODE* tp = p->next;
			p->next = NULL;
			p->prev = NULL;
			free(p);
			p = tp;
		}
		else if(!strcmp(cmd, "timer")){
//			p->ninfo.timeout += 5;
			if(p->ninfo.timeout > MAX_TIME){

				int num = (p->ninfo.status & 0xf0)>> 4;
				int n = 0;
				while(num & 0x1){
					n++;
					num = num >> 1;
				}

				for(int i = 0; i < n; i++){
					switch_active(p->ninfo.macaddr, i, OFFLINE);
				}


				NODE* prev = p->prev;
				NODE* next = p->next;

				if(prev){
					prev->next = next;

				}
				if(next){
					next->prev = prev;
				}
				p->prev = NULL;
				p->next = NULL;
				free(p);

				p = next;
				continue;
			}

			p = p->next;
		}
		else if(!strcmp(cmd, "update")){
			if(!dpkt){
				break;
			}
			if(!memcmp(p->ninfo.macaddr, dpkt->macaddr, MACADDR_LEN)){
				p->ninfo.timeout = 0;
				p->ninfo.status = dpkt->status;
//				memcpy(p->ninfo.s_macaddr, dpkt->s_macaddr, S_MACADDR_LEN);
				break;
			}
			p = p->next;
		}

	}
}


void *set_pthread(void *arg){
	DPKT *pkt = (DPKT *)arg;
	if(!pkt){
		printf("pkt is null\n");
		goto exit;
	}

	pthread_mutex_lock(&mutex_lock);
	unsigned char mac[MACADDR_LEN];
	unsigned char status;
	memset(mac, 0, MACADDR_LEN);
	status = 0;

	int f = find_full_mac_and_status(pkt, mac, &status, NULL);
	if(f == MAC_EXIST){
		int num = (pkt->status & 0xf0) >> 4;
		int i = 0;
		while(num){
			if(num & 0x1){
				unsigned char new_status = (pkt->status & (1 << i)) >> i;
				switch_set_status(mac, i, new_status);
				status = status & ~(1 << i) | (new_status << i);
			}
			i++;
			num = num >> 1;
		}
		INIT_DPKT ipkt;
		memset(&ipkt, 0, sizeof(INIT_DPKT));
		memcpy(&ipkt.macaddr, mac, MACADDR_LEN);
//		memcpy(&ipkt.s_macaddr, mac, S_MACADDR_LEN);
		ipkt.status = status;
		node_action("update", &ipkt);
	}
	else if(f == MAC_NOT_EXIST){
		printf("mac is not exist\n");
		request_mac("short", pkt->s_macaddr, S_MACADDR_LEN);
	}
exit:
	free(arg);
	arg = NULL;
	pthread_mutex_unlock(&mutex_lock);

	pkt = NULL;
	return NULL;
}

void *record_pthread(void *arg){
	INIT_DPKT *ipkt = (INIT_DPKT *)arg; 
	if(!ipkt){
		printf("pkt is null\n");
		goto exit;
	}
//	uint16_t _crc = crc16tablefast((char *)ipkt, DEV_STATUS_PKT_LEN - (CRC_LEN + TAIL_LEN) * sizeof(unsigned char));
//	printf("%x\n", _crc);

	pthread_mutex_lock(&mutex_lock);

	int n = find_node(ipkt);
	if(n == 1){
		printf("update swtich\n");
		node_action("update", ipkt);
	}
	else if(n == 0){
		printf("insert switch\n");
		NODEINFO node;

		memcpy(node.s_macaddr, ipkt->s_macaddr, S_MACADDR_LEN);// s_mac
		memcpy(node.macaddr, ipkt->macaddr, MACADDR_LEN);// mac
		node.status = ipkt->status;
		node.timeout = 0;

		int ret = insert_tail(node);
		if(!ret){
			register_device(node);
		}
	}

	pthread_mutex_unlock(&mutex_lock);
exit: 
	free(arg);
	arg = NULL;
	ipkt = NULL;
	return NULL;
}

