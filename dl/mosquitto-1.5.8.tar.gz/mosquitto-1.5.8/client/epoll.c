#include "common.h"
#include "epoll.h"

int setnonblocking(int fd)
{
	int old_option = fcntl(fd, F_GETFL);
	int new_option = old_option | O_NONBLOCK;
	fcntl(fd, F_SETFL, new_option);
	return fd;
}

void reset_oneshot(int epollfd, int fd)
{
	struct epoll_event event;
	event.data.fd = fd;
	event.events = EPOLLIN | EPOLLET | EPOLLONESHOT;
	epoll_ctl(epollfd, EPOLL_CTL_MOD, fd, &event);
}

void add_fd(int epollfd, int fd, bool enable_et)
{
	struct epoll_event event = {};
	event.data.fd = fd;
	event.events = EPOLLIN;
	if(enable_et){
		event.events |= EPOLLET;
	}

	epoll_ctl(epollfd, EPOLL_CTL_ADD, fd, &event);
	setnonblocking(fd);
}

void add_oneshot_fd(int epollfd, int fd, bool oneshot)
{
	struct epoll_event event;
	memset(&event, 0, sizeof(struct epoll_event));

	event.data.fd = fd;
	event.events = EPOLLIN | EPOLLET;
	if(oneshot)
	{
		event.events |= EPOLLONESHOT;
	}

	epoll_ctl(epollfd, EPOLL_CTL_ADD, fd, &event);
	setnonblocking(fd);
}


void del_fd(int epollfd, int fd)
{
	struct epoll_event event;
	event.data.fd = fd;
	event.events = EPOLLIN;

	epoll_ctl(epollfd, EPOLL_CTL_DEL, fd, &event);
}
