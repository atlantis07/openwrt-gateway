#include "common.h"
int check_type(unsigned char pkt){  
	if(!pkt)	
		return -1;                                          
	unsigned char type = pkt >> 4;
	return type;                       
}

int check_action(unsigned char pkt){
	if(!pkt)
		return -1;

	unsigned action = pkt & 0x0f;
	return action;
}

int find_char(char *p, char c, int cnt){                                       
	for(int i = 0;i < strlen(p);i++){
		if(c == p[i]){
			cnt--;
			if(!cnt){
				return i;
			}   
		}                                                                                       
	}                                                                                 
	return -1; 
}

int find_char_max(char *p, char c){
	if(!p){
		return -1;
	}
	
	int ret = 0;

	for(int i = 0;i < strlen(p);i++){
		if(c == p[i]){
			ret++;
		}
	}

	return ret;
}
