#include "common.h"
int check_type(unsigned char type){                                                                     
	if(!type)	
		return -1;                                          
	 unsigned char _type = type >> 4;
	 return _type;                       
}

int device_action(unsigned char pkt){
	if(!pkt)
		return -1;
	
	unsigned action = pkt & 0xf0;
	return action;
}
