#include "common.h"
int check_type(unsigned char pkt){  
	if(!pkt)	
		return -1;                                          
	 unsigned char type = pkt >> 4;
	 return type;                       
}

int check_action(unsigned char pkt){
	if(!pkt)
		return -1;
	
	unsigned action = pkt & 0x0f;
	return action;
}
