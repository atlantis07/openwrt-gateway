#include "node.h"
#include "crc.h"
#include "mqttc.h"
#include "common.h"
#include <pthread.h>
static void *set_pthread(void *arg){
	//pthread_detach(pthread_self());
	DPKT *pkt = (DPKT *)arg; 
	if(!pkt){
		printf("pkt is null\n");
		return NULL;
	}

	pthread_mutex_lock(&mutex_lock);
	unsigned char mac[MACADDR_LEN];
	unsigned char status;
	memset(mac, 0, MACADDR_LEN);
	status = 0;

	int f = find_full_mac_and_status(pkt, mac, &status, NULL);
	if(f == MAC_EXIST){
		int num = (pkt->status & 0xf0) >> 4;
		int i = 0;
		while(num){
			if(num & 0x1){
				unsigned char new_status = (pkt->status & (1 << i)) >> i;
				switch_set_status(mac, i, new_status);
				status = status & ~(1 << i) | (new_status << i);
			}
			i++;
			num = num >> 1;
		}
		INIT_DPKT ipkt;
		memset(&ipkt, 0, sizeof(INIT_DPKT));
		memcpy(&ipkt.macaddr, mac, MACADDR_LEN);
		ipkt.status = status;
		node_action("update", &ipkt);
	}
	else if(f == MAC_NOT_EXIST){
		request_mac("short", pkt->s_macaddr, S_MACADDR_LEN);
	}
	free(arg);
	arg = NULL;
	pthread_mutex_unlock(&mutex_lock);

	pkt = NULL;
	return NULL;
}

static void *record_pthread(void *arg){
	//pthread_detach(pthread_self());
	INIT_DPKT *ipkt = (INIT_DPKT *)arg; 
	if(!ipkt){
		printf("pkt is null\n");
		goto exit;
	}
	//uint16_t _crc = crc16tablefast((char *)ipkt, DEV_STATUS_PKT_LEN - (CRC_LEN + TAIL_LEN) * sizeof(unsigned char));
//	printf("%x\n", _crc);

	pthread_mutex_lock(&mutex_lock);

	int n = find_node(ipkt);
	if(n == 1){
//		printf("update\n");
		node_action("update", ipkt);
	}
	else if(n == 0){
//		printf("insert\n");
		NODEINFO node;
		
		memcpy(node.s_macaddr, ipkt->s_macaddr, S_MACADDR_LEN);// s_mac
		memcpy(node.macaddr, ipkt->macaddr, MACADDR_LEN);// mac
		node.status = ipkt->status;
		node.timeout = 0;

		int ret = insert_tail(node);
		if(!ret){
			//mqtt send to server
			register_device(node);
		}
	}

	pthread_mutex_unlock(&mutex_lock);
exit:
	free(arg);
	arg = NULL;

	ipkt = NULL;
	return NULL;
}


int find_edge(unsigned char* pkt, unsigned int len, int type){
	if(len < 0 ){
		return -1;	
	}

	for(int i = 0; i < len - 1; i++){
		if(type == PKT_HEAD){
			if((pkt[i] == 0xfe) && (pkt[i+1] == 0xfd)){
				return i;
			}
		}

		if(type == PKT_TAIL){
			if((pkt[i] == 0xef) && (pkt[i+1] == 0xdf)){
				return i + 1;
			}
		}

	}

	return -1;
}

int parse_packets(unsigned char* pkt, unsigned int len){
	for(int i = 0; i < len; i++){
		printf("%02x ", pkt[i]);
	}
	printf("\n");

	if(len < 0 || !pkt)
		return 0;

	int pktlen = len; 
	unsigned char buf[BUF_LEN];
	memset(buf, 0, BUF_LEN);

	memcpy(buf, pkt, len);
	// ... 0xfe 0xfd...  0xef 0xdf ......
	// ... 0xef 0xdf ... 0xfe 0xfd ......

	while(pktlen > 0){
		int h = -1, t = -1;
		h = find_edge(buf, pktlen, PKT_HEAD);
		t = find_edge(buf, pktlen, PKT_TAIL);
		if(h < 0 || t < 0){
			break;
		}

		if(t - h + 1 < MIN_PKT_LEN){
			goto next;
		}

		//printf("h %d t %d\n", h, t);
		if(check_type(buf[h + TYPE_POS]) == TYPE_SWITCH){
			if(device_action(buf[h + TYPE_POS]) == SWITCH_INIT){
				INIT_DPKT *ipkt = malloc(INIT_DEV_STATUS_PKT_LEN);
				memcpy(ipkt, buf, INIT_DEV_STATUS_PKT_LEN);

				//thread 
				pthread_t pid;
				pthread_attr_t attr;
				pthread_attr_init(&attr);

				int ret;
				pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
				ret = pthread_create(&pid, &attr, record_pthread, (void *)ipkt);
				if(ret < 0){
					printf("pthread_create error,ret=%d\n",ret);
				}
			}
			else if(device_action(buf[h + TYPE_POS]) == SWITCH_STATUS){
				DPKT *pkt = malloc(DEV_STATUS_PKT_LEN);
				memcpy(pkt, buf, DEV_STATUS_PKT_LEN);

				//thread 
				pthread_t pid;
				pthread_attr_t attr;
				pthread_attr_init(&attr);

				int ret;
				pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
				ret = pthread_create(&pid, &attr, set_pthread, (void *)pkt);
				if(ret < 0){
					printf("pthread_create error,ret=%d\n",ret);
				}
				pkt = NULL;
			}
		}
		else if(check_type(buf[h + TYPE_POS]) == TYPE_AIRCONDITION){
			if(device_action(buf[h + TYPE_POS]) == AIRCONDITION_RECVFROM){

			}
		}
next:
		pktlen = pktlen - t - 1;
		if(pktlen <= 0)
			break;

		unsigned char tmp[BUF_LEN];
		memset(tmp, 0, BUF_LEN);
		memcpy(tmp, buf + t + 1, pktlen);
		
		memset(buf, 0, BUF_LEN);
		memcpy(buf, tmp, pktlen);
		continue;
	}

	return 0;
}
