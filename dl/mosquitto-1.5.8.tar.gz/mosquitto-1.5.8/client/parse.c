#include "crc.h"
#include "common.h"

#include "node.h"
#include "air_condition.h"

#include <pthread.h>
int find_edge(unsigned char* pkt, unsigned int len, int type){
	if(len < 0 ){
		return -1;	
	}

	for(int i = 0; i < len - 1; i++){
		if(type == PKT_HEAD){
			if((pkt[i] == 0xfe) && (pkt[i+1] == 0xfd)){
				return i;
			}
		}

		if(type == PKT_TAIL){
			if((pkt[i] == 0xef) && (pkt[i+1] == 0xdf)){
				return i + 1;
			}
		}

	}

	return -1;
}

int parse_packets(unsigned char* pkt, unsigned int len){
	for(int i = 0; i < len; i++){
		printf("%02x ", pkt[i]);
	}
	printf("\n");

	if(len < 0 || !pkt)
		return 0;

	int pktlen = len; 
	unsigned char buf[BUF_LEN];
	memset(buf, 0, BUF_LEN);

	memcpy(buf, pkt, len);
	// ... 0xfe 0xfd...  0xef 0xdf ......
	// ... 0xef 0xdf ... 0xfe 0xfd ......

	while(pktlen > 0){
		int h = -1, t = -1;
		h = find_edge(buf, pktlen, PKT_HEAD);
		t = find_edge(buf, pktlen, PKT_TAIL);
		if(h < 0 || t < 0){
			break;
		}

		if(t - h + 1 < MIN_PKT_LEN){
			goto next;
		}

		printf("h %d t %d\n", h, t);
		//fe fd f0 len short1 short2 par1 par2 short1 short2 mac1 mac2 mac3 mac4 mac5 mac6 mac7 mac8 crc1 crc2 ef df
		if(t - h + 1 == 19){
			char initmac[DEV_MAC_LEN];
			memset(initmac, 0, DEV_MAC_LEN);
			int rs = sprintf(initmac, "%02x%02x%02x%02x%02x%02x%02x%02x", buf[INIT_MACADDR_POS],
					buf[INIT_MACADDR_POS + 1], buf[INIT_MACADDR_POS + 2], buf[INIT_MACADDR_POS + 3],
					buf[INIT_MACADDR_POS + 4], buf[INIT_MACADDR_POS + 5], buf[INIT_MACADDR_POS + 6],
					buf[INIT_MACADDR_POS + 7]);
			if(!initmac){
				goto next;
			}

			if(!uci_checktype(initmac, "switch")){
				unsigned char switch_status;
				unsigned char switch_way;
				printf("switch init\n");
				int sret = uci_get_switch(initmac, &switch_status, &switch_way);
				printf("%02x %02x %d\n", switch_status, switch_way, sret);

				if(sret == -1){
					goto next;
				}

				INIT_DPKT *ipkt = malloc(INIT_DEV_STATUS_PKT_LEN);
				if(!ipkt){
					goto next;
				}
				memcpy(ipkt, buf, INIT_DEV_STATUS_PKT_LEN);
				ipkt->status = switch_status;

				//thread 
				pthread_t pid;
				pthread_attr_t attr;
				pthread_attr_init(&attr);
				pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

				int ret;
				ret = pthread_create(&pid, &attr, record_pthread, (void *)ipkt);
				pthread_attr_destroy(&attr);
				if(ret < 0){
					printf("pthread_create error,ret=%d\n",ret);
				}
			}

			if(!uci_checktype(initmac, "aircondition")){
				printf("air condition init\n");
				unsigned char addr[AIR_ADDR_LEN];
				int aret = uci_get_aircondition(initmac, addr);
				if(aret){
					goto next;
				}

				AIR_INFO *ainfo = (AIR_INFO *)malloc(AIR_INFO_LEN);
				if(!ainfo){
					goto next;
				}  

				memcpy(ainfo->addr, addr, AIR_ADDR_LEN);
				memcpy(ainfo->s_macaddr, buf + h + INIT_SMACADDR_POS, S_MACADDR_LEN);
				memcpy(ainfo->macaddr, buf + h + INIT_MACADDR_POS, MACADDR_LEN);
				memset(ainfo->status, 0, AIR_STATUS_LEN);

				pthread_t air_t;
				pthread_attr_t attr;
				pthread_attr_init(&attr);
				pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

				int ret;
				ret = pthread_create(&air_t, &attr, air_init_pthread, (void *)ainfo);
				pthread_attr_destroy(&attr);
				if(ret < 0){
					printf("pthread_create error,ret=%d\n",ret);
				}
			}
		}
		else if(check_type(buf[h + TYPE_POS]) == TYPE_SWITCH){
			if(check_action(buf[h + TYPE_POS]) == SWITCH_STATUS){
				printf("set status\n");
				DPKT *pkt = malloc(DEV_STATUS_PKT_LEN);
				if(!pkt){
					goto next;
				}
				memcpy(pkt, buf, DEV_STATUS_PKT_LEN);

				//thread 
				pthread_t pid;
				pthread_attr_t attr;
				pthread_attr_init(&attr);
				pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

				int ret;
				ret = pthread_create(&pid, &attr, set_pthread, (void *)pkt);
				pthread_attr_destroy(&attr);
				if(ret < 0){
					printf("pthread_create error,ret=%d\n",ret);
				}
			}
		}
		else if(check_type(buf[h + TYPE_POS]) == TYPE_AIRCONDITION){
			if(check_action(buf[h + TYPE_POS]) == AIRCONDITION_RECVFROM){
				if(buf[h + 3] != 0x0a){
					goto next;
				}
				printf("air passthrough\n");
				AIR_INFO *ainfo = (AIR_INFO *)malloc(AIR_INFO_LEN);
				if(!ainfo){
					goto next;
				}
				//	memcpy(ainfo->nodeaddr, buf + h + NODEADDR_POS, AIR_NODE_ADDR_LEN);
				memcpy(ainfo->s_macaddr, buf + h + 4, S_MACADDR_LEN);
				//	memcpy(ainfo->status , buf + h + DATA_POS, AIR_STATUS_LEN);

				pthread_t air_t;
				pthread_attr_t attr;
				pthread_attr_init(&attr);

				pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);



				int ret;
				ret = pthread_create(&air_t, &attr, air_passthrough_pthread, (void *)ainfo);
				pthread_attr_destroy(&attr);
				if(ret < 0){
					printf("pthread_create error,ret=%d\n",ret);
				}
			}
		}

next:
		pktlen = pktlen - t - 1;
		if(pktlen <= 0)
			break;

		unsigned char tmp[BUF_LEN];
		memset(tmp, 0, BUF_LEN);
		memcpy(tmp, buf + t + 1, pktlen);

		memset(buf, 0, BUF_LEN);
		memcpy(buf, tmp, pktlen);
		continue;
	}

	return 0;
}
