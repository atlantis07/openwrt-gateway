#include "crc.h"
#include "common.h"
#include "node.h"
#include "node_update.h"
#include "switch.h"
#include "air_condition.h" //climate
#include "stm32.h"
#include "parse.h"
#include <pthread.h>

int find_edge(unsigned char* pkt, unsigned int len, int type){
	if(len < 0 ){
		return -1;	
	}

	for(int i = 0; i < len - 1; i++){
		if(type == PKT_HEAD){
			if((pkt[i] == 0xfe) && (pkt[i+1] == 0xfd)){
				return i;
			}
		}

		if(type == PKT_TAIL){
			if((pkt[i] == 0xef) && (pkt[i+1] == 0xdf)){
				return i + 1;
			}
		}

	}

	return -1;
}

int parse_packets(unsigned char* pkt, unsigned int len){
	if(len < 0 || !pkt)
		return 0;

	//tl_printf_array("received:", pkt, len);

	int pktlen = len; 
	unsigned char buf[BUF_LEN];
	memset(buf, 0, BUF_LEN);

	memcpy(buf, pkt, len);
	// ... 0xfe 0xfd...  0xef 0xdf ......
	// ... 0xef 0xdf ... 0xfe 0xfd ......

	while(pktlen > 0){
		int h = -1, t = -1;
		int pkglen = -1;
		h = find_edge(buf, pktlen, PKT_HEAD);
		t = find_edge(buf, pktlen, PKT_TAIL);
		if(h < 0 || t < 0){
			break;
		}

		pkglen = t - h + 1;
		if(pkglen < MIN_PKT_LEN){
			goto next;
		}

		//		printf("h %d t %d\n", h, t);
		tl_printf_array("parse:   ", buf + h, pkglen);

		//thread 
		pthread_t pid;
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
		int ret = 0;

		if(buf[h + DTYPE_POS] == DEV_ZIGBEE){
			if(check_type(buf[h + TYPE_POS]) == TYPE_ZIGBEE_MACERROR){ 
				if((pkglen == PKT_INIT_LEN ) && 
						(check_action(buf[h + TYPE_POS]) == NODE_INIT)){
					//fe fd 01 f2 0f 79 6f 00 00 79 6f 98 73 d4 02 00 4b 12 00 f3 c0 ef df
					int pos = h + REINIT_SMACADDR_POS;

					unsigned char *msg = malloc(MACADDR_LEN + S_MACADDR_LEN);
					if(!msg){
						goto next;
					}
					memset(msg, 0, (MACADDR_LEN + S_MACADDR_LEN));

					memcpy(msg, buf + pos, MACADDR_LEN + S_MACADDR_LEN);
					ret = pthread_create(&pid, &attr, node_preinit, (void *)msg);
				}

				if((pkglen == PKT_HEARTBEAT_LEN) &&
						(check_action(buf[h + TYPE_POS]) == NODE_HEARTBEAT)){
					NODE_INFO *ninfo = (NODE_INFO *)malloc(sizeof(NODE_INFO));
					memset(ninfo, 0, sizeof(NODE_INFO));
					memcpy(ninfo->s_macaddr, buf + h + HEARTBEAT_ADDR_POS, S_MACADDR_LEN);
					ninfo->signal = buf[h + HEARTBEAT_SIG_POS];
					ret = pthread_create(&pid, &attr, node_heartbeat, (void *)ninfo);
				}

				if(check_action(buf[h + TYPE_POS]) == NODE_UPDATE){
					if(pkglen > NODE_UPDATE_MIN){
						unsigned char *nu = (unsigned char *)malloc(pkglen);
						if(nu){
							memset(nu, 0, pkglen);
							memcpy(nu, buf + h, pkglen);
							ret = pthread_create(&pid, &attr, node_update, (void *)nu);
						}	
					}	
				}
			}
			else if(check_type(buf[h + TYPE_POS]) == TYPE_ZIGBEE_SWITCH){
				if((check_action(buf[h + TYPE_POS]) == SWITCH_STATUS_REMOTE) || 
					(check_action(buf[h + TYPE_POS]) == SWITCH_STATUS_TOUCH)){
					tl_printf(MSG_INFO, "set status\n");
					DPKT *pkt = malloc(DEV_STATUS_PKT_LEN);
					if(!pkt){
						goto next;
					}
					if(pkglen == PKT_SWITCH_STATUS_LEN){
						memcpy(pkt, buf + h, DEV_STATUS_PKT_LEN);
					}
					else if (pkglen == PKT_SCENE_SWITCH_STATUS_LEN){
						pkt->h[0] = buf[h];
						pkt->h[1] = buf[h + 1];
						pkt->dt = buf[h + 2];
						pkt->type = buf[h + 3];
						pkt->datalen = 3;
						pkt->s_macaddr[0] = buf[h + 5];
						pkt->s_macaddr[1] = buf[h + 6];
						pkt->status = buf[h + 7];
						//crc
						pkt->t[0] = buf[h + 18];
						pkt->t[1] = buf[h + 19];

						unsigned char smac[2] = {};
						unsigned char mac[8] = {};
						memcpy(smac, buf + h + 5, 2);
						memcpy(mac, buf + h + 8, 8);
						node_scene_checkout(smac, mac);
						//crc
					}
					else{
						free(pkt);
						goto next;
					}
					ret = pthread_create(&pid, &attr, switch_status_pthread, (void *)pkt);
				}
			}
			else if(check_type(buf[h + TYPE_POS]) == TYPE_ZIGBEE_AIRCONDITION){
			}
		}	
		else if(buf[h + DTYPE_POS] == DEV_STM32){
				if(buf[h + TYPE_POS] == TYPE_STM32_DETECT){
					DETECT_T *pkt = (DETECT_T *)malloc(DETECT_T_LEN);
					if(pkt){
						memcpy(pkt, buf + h, DETECT_T_LEN);
						ret = pthread_create(&pid, &attr, stm32_common_pthread, (void *)pkt);
					}
				}
				else if(buf[h + TYPE_POS == TYPE_STM32_EBTN]){
					EBTN_T *pkt = (EBTN_T *)malloc(EBTN_T_LEN);
					if(pkt){
						memcpy(pkt, buf + h, EBTN_T_LEN);
						ret = pthread_create(&pid, &attr, stm32_common_pthread, (void *)pkt);
					}
				}
		}
		else if(buf[h + DTYPE_POS] == DEV_485){

		}
next:
		pthread_attr_destroy(&attr);
		if(ret < 0){
			tl_printf(MSG_INFO, "pthread_create error,ret=%d\n",ret);
		}

		pktlen = pktlen - t - 1;
		if(pktlen <= 0)
			break;

		unsigned char tmp[BUF_LEN];
		memset(tmp, 0, BUF_LEN);
		memcpy(tmp, buf + t + 1, pktlen);

		memset(buf, 0, BUF_LEN);
		memcpy(buf, tmp, pktlen);
		continue;
	}

	return 0;
}
