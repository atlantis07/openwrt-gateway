#include "crc.h"
#include "common.h"
#include "node.h"
#include "switch.h"
#include "air_condition.h" //climate
#include "parse.h"
#include <pthread.h>

int find_edge(unsigned char* pkt, unsigned int len, int type){
	if(len < 0 ){
		return -1;	
	}

	for(int i = 0; i < len - 1; i++){
		if(type == PKT_HEAD){
			if((pkt[i] == 0xfe) && (pkt[i+1] == 0xfd)){
				return i;
			}
		}

		if(type == PKT_TAIL){
			if((pkt[i] == 0xef) && (pkt[i+1] == 0xdf)){
				return i + 1;
			}
		}

	}

	return -1;
}

int parse_packets(unsigned char* pkt, unsigned int len){
	if(len < 0 || !pkt)
		return 0;

	tl_printf_array("received:", pkt, len);

	int pktlen = len; 
	unsigned char buf[BUF_LEN];
	memset(buf, 0, BUF_LEN);

	memcpy(buf, pkt, len);
	// ... 0xfe 0xfd...  0xef 0xdf ......
	// ... 0xef 0xdf ... 0xfe 0xfd ......

	while(pktlen > 0){
		int h = -1, t = -1;
		int pkglen = -1;
		h = find_edge(buf, pktlen, PKT_HEAD);
		t = find_edge(buf, pktlen, PKT_TAIL);
		if(h < 0 || t < 0){
			break;
		}
		
		pkglen = t - h + 1;
		if(pkglen < MIN_PKT_LEN){
			goto next;
		}

//		printf("h %d t %d\n", h, t);
		tl_printf_array("parse:   ", buf + h, pkglen);

		//thread 
		pthread_t pid;
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
		int ret = 0;

		if(check_type(buf[h + TYPE_POS]) == TYPE_MACERROR){ 
			if((pkglen == PKT_INIT_LEN ) && 
			(check_action(buf[h + TYPE_POS]) == NODE_INIT)){
			//fe fd f2 0f 79 6f 00 00 79 6f 98 73 d4 02 00 4b 12 00 f0 f3 c0 ef df
				int pos = h + REINIT_SMACADDR_POS;
				
				unsigned char *msg = malloc(MACADDR_LEN + S_MACADDR_LEN);
				if(!msg){
					goto next;
				}

				memcpy(msg, buf + pos, MACADDR_LEN + S_MACADDR_LEN);
				ret = pthread_create(&pid, &attr, node_preinit, (void *)msg);
			}
			if((pkglen == PKT_HEARTBEAT_LEN) &&
			(check_action(buf[h + TYPE_POS]) == NODE_HEARTBEAT)){
				NODE_INFO *ninfo = (NODE_INFO *)malloc(sizeof(NODE_INFO));
				memset(ninfo, 0, sizeof(NODE_INFO));
				memcpy(ninfo->s_macaddr, buf + h + HEARTBEAT_ADDR_POS, S_MACADDR_LEN);
				ninfo->signal = buf[h + HEARTBEAT_SIG_POS];
				ret = pthread_create(&pid, &attr, node_heartbeat, (void *)ninfo);
			}
		}
		else if(check_type(buf[h + TYPE_POS]) == TYPE_SWITCH){
			if(check_action(buf[h + TYPE_POS]) == SWITCH_STATUS){
				tl_printf(MSG_INFO, "set status\n");
				DPKT *pkt = malloc(DEV_STATUS_PKT_LEN);
				if(!pkt){
					goto next;
				}
				memcpy(pkt, buf + h, DEV_STATUS_PKT_LEN);
				ret = pthread_create(&pid, &attr, switch_status_pthread, (void *)pkt);
			}
		}
		else if(check_type(buf[h + TYPE_POS]) == TYPE_AIRCONDITION){
#if 0
			if(check_action(buf[h + TYPE_POS]) == AIRCONDITION_RECVFROM){
				if(buf[h + 3] != 0x0a){
					goto next;
				}
				printf("air passthrough\n");
				AIR_NODE *anode = (AIR_NODE *)malloc(AIR_NODE_LEN);
				if(!anode){
					goto next;
				}
				memcpy(anode->ainfo.s_macaddr, buf + h + INIT_SMACADDR_POS, S_MACADDR_LEN);
				memcpy(anode->ainfo.status , buf + h + DATA_POS, AIR_STATUS_LEN);

				ret = pthread_create(&pid, &attr, air_passthrough_pthread, (void *)anode);
			}
#endif
		}
		
next:
		pthread_attr_destroy(&attr);
		if(ret < 0){
			tl_printf(MSG_INFO, "pthread_create error,ret=%d\n",ret);
		}

		pktlen = pktlen - t - 1;
		if(pktlen <= 0)
			break;

		unsigned char tmp[BUF_LEN];
		memset(tmp, 0, BUF_LEN);
		memcpy(tmp, buf + t + 1, pktlen);

		memset(buf, 0, BUF_LEN);
		memcpy(buf, tmp, pktlen);
		continue;
	}

	return 0;
}
