#include "common.h"
#include "parse.h"

#include "serial.h"
#include "node.h"
#include "air_condition.h"

#include "crc.h"
#include "mqttc.h"

int recvfrom_zigbee(){
	printf("start reading zigbee device\n");
	int fd = open(ZIGBEE_DEV, O_RDWR);
	if(fd < 0){
		perror("fd");
		return OPEN_DEVICE_ERROR;
	}
	else{
		if(fcntl(fd, F_SETFL,0) < 0){
			printf("fcntl failed\n");
			return SET_DEVICE_ERROR;
		}
	}

	unsigned char _p[8];
	unsigned char pkt[BUF_LEN];
	int pkt_len = 0;

	memset(_p, 0, 8);
	memset(pkt, 0, BUF_LEN);

	while(1){
		int ret = read(fd, _p, 8);
		if(ret < 0)
			return -1;
		else if(ret > 0){

			memcpy(pkt + pkt_len, _p, ret);
			pkt_len += ret;
			memset(_p, 0, 8);

			if(pkt_len > 1000){
				parse_packets(pkt, pkt_len);
				pkt_len = 0;
				memset(pkt, 0, BUF_LEN);
			}
		}
		else{
			if(pkt_len){
				parse_packets(pkt, pkt_len);
				pkt_len = 0;
				memset(pkt, 0, BUF_LEN);
			}
		}
	}

	close(fd);
	return 0;
}

int sendto_zigbee(unsigned char *data, int data_len){
	int fd = open(ZIGBEE_DEV, O_RDWR);
	if(fd < 0){ 
		perror("fd");
		return OPEN_DEVICE_ERROR;
	}   
	else{
		if(fcntl(fd, F_SETFL,0) < 0){
			close(fd);
			return OPEN_DEVICE_ERROR;
		}
	}

	int ret = write(fd, data, data_len);
	close(fd);
	return ret;
}

int write_to_switch(unsigned char *message, unsigned int message_len, int times, int num, unsigned char target){
		for(int i = 0; i < times; i++){
			int wret = sendto_zigbee(message, message_len);
			if(wret > 0){ 
				for(int i = 0;i < message_len; i++){
					printf("%02x ", (unsigned char)message[i]);
				}   
				printf("\n");
				usleep(300000);
				//wait for new stat

				if(message_len == DEV_SINGLE_CMD_PKT_LEN){
					DPKT dpkt;
					memset(&dpkt, 0, sizeof(DPKT));
					memcpy(dpkt.s_macaddr, ((CMD_S_PKT *)message)->s_macaddr, S_MACADDR_LEN);
					unsigned char status = 0;
					unsigned char macaddr[MACADDR_LEN];

					pthread_mutex_lock(&mutex_lock);
					int ret = find_full_mac_and_status(&dpkt, macaddr, &status, NULL);
					pthread_mutex_unlock(&mutex_lock);
					if(ret == MAC_EXIST){
						unsigned char find_target = (status & (0x1 << num))>>num;
						if(find_target == target){
							//							printf("new status %x\n", find_target);
							break;
						}
					}
					else{
						return ret;
					}
				}

			}   
			else{
				perror("write device");
				return WRITE_DEVICE_ERROR;
			}
		}
//	}
	return 0;
}

int request_mac(char *type, unsigned char *mac, int len){
		REQ_INIT_PKT pkt;
		memset(&pkt, 0, REQ_INIT_PKT_LEN);

		pkt.h[0] = 0xfe;
		pkt.h[1] = 0xfd;
		pkt.datalen = MACADDR_LEN;
		pkt.t[0] = 0xef;
		pkt.t[1] = 0xdf;
		memcpy(pkt.macaddr, mac, len);

		if(!strcmp(type, "long")){
			pkt.type = 0xf1;
		}
		else if(!strcmp(type, "short")){
			pkt.type = 0xf2;
		}
		else{
			return PARAM_ERROR; 
		}

		unsigned short crc = crc16tablefast((unsigned char *)&pkt, REQ_INIT_PKT_LEN - 4);
#if 1
		pkt.crc[0] = crc & 0xff;
		pkt.crc[1] = crc >> 8;
#else
		pkt.crc[0] = crc >> 8;
		pkt.crc[1] = crc & 0xff;
#endif

		for(int i = 0;i < REQ_INIT_PKT_LEN; i++){
			printf("%02x ", ((unsigned char *)&pkt)[i]);
		}
		printf("\n");


		int ret = sendto_zigbee((unsigned char *)&pkt, REQ_INIT_PKT_LEN);
		if(ret < 0){
			return WRITE_DEVICE_ERROR;
		}
	return WRITE_OK;
}


int write_to_climate(char *gwaddr, char *type, char* payload, char *host, char *series, unsigned char *addr, int addrlen){
	if(!(host && type && payload)){
		return PARAM_ERROR;
	}

	unsigned char status[AIR_PASS_DATA_LEN] = {};

	int ret = query_climate((unsigned char*)status, series, addr, addrlen);
	if(ret < 0){
		return WRITE_DEVICE_ERROR;
	}

	AIR_PASS_PKT apkt;

	char sdevaddr[17] = "";
	sprintf(sdevaddr, "%02x%02x%02x%02x%02x%02x%02x%02x", addr[0], addr[1], addr[2], addr[3], addr[4], 
			addr[5], addr[6], addr[7]);

	if(!strcmp(type, "power")){
		if(!strncmp(payload, "ON", 2)|| !strncmp(payload, "on", 2)){
			status[0] = 0xa1;
			status[3] |= 1 << 4;
		}
		else if (!strncmp(payload, "OFF", 3) || !strncmp(payload, "off", 3)){
			status[0] = 0xa1;
			status[3] = status[3] & (~(0x1 << 4));
		}
	}
	else if(!strcmp(type, "temperature_set")){
		int temp = 0;
		int ret = sscanf(payload, "%d", &temp);
		if(ret != 1)
			return -1;

		status[0] = 0xa1;
		status[5] = temp; 
	}
	else if(!strcmp(type, "temperature_increase")){
		int temp = 0;
		int ret = sscanf(payload, "%d", &temp);
		if(ret != 1)
			return -1;

		status[5] = status[5] + temp;
		char increase_temp[256] = "";
		sprintf(increase_temp, "mosquitto_pub -h %s -t '%s/airconditioning/FANGWEI/%s/temperature_set' -m '%d'", host, gwaddr, sdevaddr, status[5]);
		system(increase_temp);
	}
	else if(!strcmp(type, "mode_set")){
		printf("mode set\n");
		if (!strncmp(payload, "COOL", 4) || !strncmp(payload, "cool", 4)){
			status[3] = status[3] & (~(0x1 << 5));
		}
		else if (!strncmp(payload, "HEAT", 4) || !strncmp(payload, "heat", 4)){
			status[3] |= 1 << 5;
		}
		else{//default cool
			status[3] = status[3] & (~(0x1 << 5));
		}

		status[0] = 0xa1;
	}
	else if(!strcmp(type, "fan_set")){
		if (!strncmp(payload, "MAX", 3) || !strncmp(payload, "max", 3) ||
				!strncmp(payload, "HIGH", 4) || !strncmp(payload, "high", 4)){
			status[3] = status[3] & (~0x3) | 0x1;

		}
		else if (!strncmp(payload, "MIDDLE", 6) || !strncmp(payload, "middle", 6) ||
				!strncmp(payload, "medium", 6) || !strncmp(payload, "MEDIUM", 6)){
			status[3] = status[3] & (~0x3) | 0x2;
		}
		else if (!strncmp(payload, "LOW", 3) || !strncmp(payload, "low", 3) ||
				!strncmp(payload, "min", 3) || !strncmp(payload, "min", 4)){
			status[3] = status[3] & (~0x3) | 0x3;
		}
		else{
			//auto
			status[3] = status[3] & (~0x3);
		}

		status[0] = 0xa1;
	}
	else if(!strcmp(type, "fan_increase")){
		int temp = 0;
		int ret = sscanf(payload, "%d", &temp);
		if(ret != 1)
			return -1;

		int fan_pass = status[3] & 0x3;
		char increase_fan[256];
		char speed[8];
		memset(increase_fan, 0, 256);
		memset(speed, 0, 8);

		if(temp > 0){
			if(fan_pass == 0x3){
				memcpy(speed, "medium", 6);
			}
			else if (fan_pass == 0x2){
				memcpy(speed, "high", 4);
			}
			else if (fan_pass == 0x1){
				memcpy(speed, "high", 4);
			}
			else if (fan_pass == 0x0){
				memcpy(speed, "medium", 6);
			}
		}
		else if(temp < 0){
			if(fan_pass == 0x3){
				memcpy(speed, "low", 3);
			}
			else if(fan_pass == 0x2){
				memcpy(speed, "low", 3);
			}
			else if(fan_pass == 0x1){
				memcpy(speed, "medium", 6);
			}
			else if(fan_pass == 0x0){
				memcpy(speed, "low", 3);
			}
		}

		sprintf(increase_fan, "mosquitto_pub -h %s -t '%s/airconditioning/FANGWEI/%s/fan_set' -m '%s' ", host,gwaddr, sdevaddr, speed);
		system(increase_fan);
	}
	else{
		return 0;
	}

	if(!strcmp(type, "temperature_increase") || !strcmp(type, "fan_increase")){
	}
	else{
		status[7] = climate_crc(status, AIR_PASS_DATA_LEN);

		unsigned char dev_saddr[S_MACADDR_LEN];

		pthread_mutex_lock(&air_mutex_lock);
		AIR_NODE *cmd_air = find_air_node(addr);
		if(!cmd_air){
			printf("[cmd]air node is not exist\n");
			pthread_mutex_unlock(&air_mutex_lock);
			return PARAM_ERROR; 
		}   
		memcpy(dev_saddr, cmd_air->ainfo.s_macaddr, S_MACADDR_LEN);
		pthread_mutex_unlock(&air_mutex_lock);
//		char test[] = {0xa1, 0x33, 0x10, 0x00, 0x00, 0x15, 0x00, 0x5c};
//		memcpy(status, test, 8);

		air_passpkt_init(&apkt, status, (AIR_PASS_DATA_LEN + S_MACADDR_LEN), dev_saddr);

		printf("exec cmd:\n");
		for(int i =0 ; i < sizeof(AIR_PASS_PKT); i++){
			printf("%02x ", ((unsigned char *)&apkt)[i]);
		}
		printf("\n");
		ret = sendto_zigbee((unsigned char *)&apkt, sizeof(AIR_PASS_PKT));
		if(ret == sizeof(AIR_PASS_PKT)){
			printf("exec %s success\n", type);
		}
		else{
			printf("exec %s failed\n", type);
		}
		usleep(1500000);
		update_climate(gwaddr, series, host, addr, addrlen);
	}
	return 0;
}
