#include "common.h"
#include "parse.h"

#include "serial.h"
#include "switch.h"
#include "air_condition.h"

#include "crc.h"
#include "mqttc.h"

int recvfrom_zigbee(){
	tl_printf(MSG_INFO, "start reading zigbee device\n");
	int fd = open(ZIGBEE_DEV, O_RDWR);
	if(fd < 0){
		perror("fd");
		return OPEN_DEVICE_ERROR;
	}
	else{
		if(fcntl(fd, F_SETFL,0) < 0){
			tl_printf(MSG_INFO, "fcntl failed\n");
			printf(MSG_INFO, "fcntl failed\n");
			return SET_DEVICE_ERROR;
		}
	}

	unsigned char _p[8];
	unsigned char pkt[BUF_LEN];
	int pkt_len = 0;

	memset(_p, 0, 8);
	memset(pkt, 0, BUF_LEN);

#if 1
//	unsigned char buf[] = {0xfe,0xfd,0xf2,0x0f,0x79,0x70,0x00,0x00,0x79,0x70,0x98,0x73,0xd4,0x02,0x00,0x4b,0x12,0x00,0xf0,0xdc,0xba,0xef,0xdf,0xfe,0xfd,0xf2,0x0f,0x79,0x70,0x00,0x00,0x79,0x70,0x98,0x73,0xd4,0x02,0x00,0x4b,0x12,0x00,0xf0,0xdc,0xba,0xef,0xdf};
//	parse_packets(buf, sizeof(buf));

	//query all
	query_node(fd);

	while(1){
		int ret = read(fd, _p, 8);
		if(ret < 0)
			return -1;
		else if(ret > 0){

			memcpy(pkt + pkt_len, _p, ret);
			pkt_len += ret;
			memset(_p, 0, 8);

			if(pkt_len > 1000){
				parse_packets(pkt, pkt_len);
				pkt_len = 0;
				memset(pkt, 0, BUF_LEN);
			}
		}
		else{
			if(pkt_len){
				parse_packets(pkt, pkt_len);
				pkt_len = 0;
				memset(pkt, 0, BUF_LEN);
			}
		}
	}
#else
	//	4876d402004b1200
	sleep(200);
#endif

	close(fd);
	return 0;
}

int sendto_zigbee(unsigned char *data, int data_len){
	int fd = open(ZIGBEE_DEV, O_RDWR);
	if(fd < 0){ 
		perror("fd");
		return OPEN_DEVICE_ERROR;
	}   
	else{
		if(fcntl(fd, F_SETFL,0) < 0){
			close(fd);
			return OPEN_DEVICE_ERROR;
		}
	}

	int ret = write(fd, data, data_len);
	if(ret == data_len){
		tl_printf_array("send to zigbee:", data, data_len);
	}
	close(fd);
	return ret;
}

int write_to_switch(unsigned char *message, unsigned int message_len, int times, int num, unsigned char target){
	for(int i = 0; i < times; i++){
		int wret = sendto_zigbee(message, message_len);
		if(wret == message_len){ 
			usleep(200000);
			//struct timeval tv;
			//gettimeofday(&tv,NULL);
			//printf("start:%ld\n",tv.tv_sec);
			//sleep(1);
			//gettimeofday(&tv,NULL);
			//printf("end:%ld\n",tv.tv_sec);
			//usleep(500000);
			if(message_len == DEV_SINGLE_CMD_PKT_LEN){
				DPKT dpkt;
				memset(&dpkt, 0, sizeof(DPKT));
				memcpy(dpkt.s_macaddr, ((CMD_S_PKT *)message)->s_macaddr, S_MACADDR_LEN);
				unsigned char status = 0;
				unsigned char macaddr[MACADDR_LEN];

				pthread_mutex_lock(&switch_mutex_lock);
				int ret = find_full_mac_and_status(&dpkt, macaddr, &status, NULL);
				pthread_mutex_unlock(&switch_mutex_lock);
				if(ret == MAC_EXIST){
					unsigned char find_target = (status & (0x1 << num))>>num;
					if(find_target == target){
						//							printf("new status %x\n", find_target);
						break;
					}
				}
				else{
					return ret;
				}
			}

		}   
		else{
			perror("write device");
			return WRITE_DEVICE_ERROR;
		}
	}
	//	}
return 0;
}

int request_mac(char *type, unsigned char *mac, int len){
	REQ_INIT_PKT pkt;
	memset(&pkt, 0, REQ_INIT_PKT_LEN);

	pkt.h[0] = 0xfe;
	pkt.h[1] = 0xfd;
	pkt.datalen = MACADDR_LEN;
	pkt.t[0] = 0xef;
	pkt.t[1] = 0xdf;
	memcpy(pkt.macaddr, mac, len);

	if(!strcmp(type, "long")){
		pkt.type = 0xf1;
	}
	else if(!strcmp(type, "short")){
		pkt.type = 0xf2;
	}
	else{
		return PARAM_ERROR; 
	}

	unsigned short crc = crc16tablefast((unsigned char *)&pkt, REQ_INIT_PKT_LEN - 4);
	pkt.crc[0] = crc & 0xff;
	pkt.crc[1] = crc >> 8;

	int ret = sendto_zigbee((unsigned char *)&pkt, REQ_INIT_PKT_LEN);
	if(ret < 0){
		return WRITE_DEVICE_ERROR;
	}
	return WRITE_OK;
}


int write_to_climate(char *gwaddr, char *type, char* payload, char *host, char *series, unsigned char *addr, int addrlen){
	if(!(host && type && payload)){
		return PARAM_ERROR;
	}
	int ret = 0;	

	pthread_mutex_lock(&air_mutex_lock);
	AIR_NODE *cmd_air = find_air_node(addr);
	if(!cmd_air){
		tl_printf(MSG_INFO, "[cmd]air node is not exist\n");
		ret = PARAM_ERROR;
		goto climate_end;
	}

	tl_printf(MSG_INFO, "%s %s %d\n", cmd_air->ainfo.series, series, strcmp(cmd_air->ainfo.series, series));

	if(strcmp(cmd_air->ainfo.series, series)){
		tl_printf(MSG_INFO, "air series mismatch\n");
		ret = PARAM_ERROR;
		goto climate_end;
	}
	
	if(!strcmp(type, "tanklight_set")){
		tl_printf(MSG_INFO, "tanklight set series %s\n", series);

		unsigned char target_climate_cmd[AIR_PASS_DATA_MAX] = "";
		int target_climate_cmd_len = 0;
		climate_data_init(series, payload, &target_climate_cmd ,&target_climate_cmd_len, cmd_air->ainfo.addr, cmd_air->ainfo.s_macaddr);

		if(target_climate_cmd_len){
			int ret = sendto_zigbee(target_climate_cmd, target_climate_cmd_len);
		}
	}
	else {
		if(!strcmp("FANGWEI", series)){
		}
		else if(!strcmp("INFRARED", series)){
			char sdevaddr[17] = "";
			sprintf(sdevaddr, "%02x%02x%02x%02x%02x%02x%02x%02x", addr[0], addr[1], addr[2], addr[3], 
					addr[4],addr[5], addr[6], addr[7]);

			unsigned char infrared_cmd[INFRARED_CMD_LEN] = {0x00, 0x00, 0x08, 0x08, 0x00};
			unsigned char crc = 0x0;

			if(!strcmp(type, "power")){
				if(!strncmp(payload, "ON", 2)|| !strncmp(payload, "on", 2)){
					infrared_cmd[1] = 0xff;
				}
				else if (!strncmp(payload, "OFF", 3) || !strncmp(payload, "off", 3)){
					infrared_cmd[1] = 0x00;
				}
				infrared_cmd[0] = INFRARED_POWER;
			}
			else if(!strcmp(type, "temperature_set")){
				int temp = 0;
				int ret = sscanf(payload, "%d", &temp);
				if(ret != 1){
					goto climate_end;
				}
				if(temp > AIR_INFRARED_MAX_TEMP){
					temp = AIR_INFRARED_MAX_TEMP;
				}
				else if (temp < AIR_INFRARED_MIN_TEMP){
					temp = AIR_INFRARED_MIN_TEMP;
				}
				infrared_cmd[0] = INFRARED_TEMP_SET;
				infrared_cmd[1] = temp;
			}
			else if(!strcmp(type, "temperature_increase")){
				int temp = 0;
				int ret = sscanf(payload, "%d", &temp);
				if(ret != 1){
					goto climate_end;
				}

				infrared_cmd[0] = INFRARED_TEMP_SET;
				infrared_cmd[1] = cmd_air->ainfo.temperature + temp;
				if(infrared_cmd[1] > AIR_INFRARED_MAX_TEMP){
					infrared_cmd[1] = AIR_INFRARED_MAX_TEMP;
				}   
				else if (infrared_cmd[1] < AIR_INFRARED_MIN_TEMP){
					infrared_cmd[1] = AIR_INFRARED_MIN_TEMP;
				} 
			}
			else if(!strcmp(type, "mode_set")){
				infrared_cmd[0] = INFRARED_MODE;
				if(!strncmp(payload, "AUTO", 4) || !strncmp(payload, "auto", 4)){
					infrared_cmd[1] = INFRARED_MODE_AUTO;
				}
				else if (!strncmp(payload, "COOL", 4) || !strncmp(payload, "cool", 4)){
					infrared_cmd[1] = INFRARED_MODE_COOL;
				}
				else if (!strncmp(payload, "DEHUMIDIFICATION", 16) || !strncmp(payload, "dehumidification", 16) ||
						!strncmp(payload, "dry", 3) || !strncmp(payload, "DRY", 3)){
					infrared_cmd[1] = INFRARED_MODE_DEHUMIDIFICATION;
				}
				else if (!strncmp(payload, "FAN", 3) || !strncmp(payload, "fan", 3) ||
						!strncmp(payload, "fan_only", 8) || !strncmp(payload, "FAN_ONLY", 8)){
					infrared_cmd[1] = INFRARED_MODE_FAN;
				}
				else if (!strncmp(payload, "HEAT", 4) || !strncmp(payload, "heat", 4)){
					infrared_cmd[1] = INFRARED_MODE_HEAT;
				}
			}
			else if(!strcmp(type, "fan_set")){
				infrared_cmd[0] = INFRARED_FAN_SET;
				if (!strncmp(payload, "MAX", 3) || !strncmp(payload, "max", 3) ||
						!strncmp(payload, "HIGH", 4) || !strncmp(payload, "high", 4)){
					infrared_cmd[1] = INFRARED_FAN_HIGH;
				}
				else if (!strncmp(payload, "MIDDLE", 6) || !strncmp(payload, "middle", 6) ||
						!strncmp(payload, "medium", 6) || !strncmp(payload, "MEDIUM", 6)){
					infrared_cmd[1] = INFRARED_FAN_MIDDLE;
				}
				else if (!strncmp(payload, "LOW", 3) || !strncmp(payload, "low", 3) ||
						!strncmp(payload, "min", 3) || !strncmp(payload, "min", 4)){
					infrared_cmd[1] = INFRARED_FAN_LOW;
				}
				else{
					//auto
					infrared_cmd[1] = INFRARED_FAN_AUTO;
				}
			}
			else if(!strcmp(type, "fan_increase")){
				infrared_cmd[0] = INFRARED_FAN_SET;

				int temp = 0;
				int ret = sscanf(payload, "%d", &temp);
				if(ret != 1){
					goto climate_end;
				}

				infrared_cmd[1] = cmd_air->ainfo.fan + temp;
				if(infrared_cmd[1] > INFRARED_FAN_HIGH){
					infrared_cmd[1] = INFRARED_FAN_HIGH;
				}
				else if (infrared_cmd[1] < INFRARED_FAN_LOW){
					infrared_cmd[1] = INFRARED_FAN_LOW;
				}

			}
			else{
				goto climate_end;
			}
			infrared_cmd[4] = climate_infrared_xor(infrared_cmd, 4);


			unsigned char dev_saddr[S_MACADDR_LEN];
			memcpy(dev_saddr, cmd_air->ainfo.s_macaddr, S_MACADDR_LEN);
			//required 

			unsigned char infrared_pass[INFRARED_CMD_LEN] = {0xfe, 0xfd, ( AIRCONDITION_SENDTO | (TYPE_AIRCONDITION << 4)), 
				0x07, dev_saddr[0], dev_saddr[1], 
				infrared_cmd[0], infrared_cmd[1], infrared_cmd[2], infrared_cmd[3], 
				infrared_cmd[4], 
				0x0, 0x0, 0xef, 0xdf};
			unsigned short modbus_crc[2];
			modbus_crc[0] = crc16table(infrared_pass, INFRARED_CMD_LEN - 4) & 0xff;
			modbus_crc[1] = crc16table(infrared_pass, INFRARED_CMD_LEN - 4) >> 8;
			infrared_pass[11] = modbus_crc[0];
			infrared_pass[12] = modbus_crc[1];

			int ret = sendto_zigbee(infrared_pass, INFRARED_CMD_LEN);
			if(ret == INFRARED_CMD_LEN){
				//update
				if(infrared_cmd[0] == INFRARED_TEMP_SET){
					cmd_air->ainfo.temperature = (int)infrared_cmd[1];
				}
				else if(infrared_cmd[0] == INFRARED_POWER){
					cmd_air->ainfo.on = infrared_cmd[1] == 0xff?1:0;
				}
				else if(infrared_cmd[0] == INFRARED_MODE){
					cmd_air->ainfo.mode = infrared_cmd[1];
				}
				else if(infrared_cmd[0] == INFRARED_FAN_SET){
					cmd_air->ainfo.fan = infrared_cmd[1];
				}
			}
		}
	}

climate_end:
	cmd_air = NULL;
	pthread_mutex_unlock(&air_mutex_lock);
	return 0;
}

int query_node(int fd){
	unsigned char query[] = {0xfe, 0xfd, 0xf9, 0x00, 0xe2, 0x6c, 0xef, 0xdf};
	int len = sizeof(query)/sizeof(unsigned char );
	int ret = write(fd, query, len);
	if(ret != len){
		tl_printf(MSG_INFO, "query node failed\n");
	}
	return 0;
}
