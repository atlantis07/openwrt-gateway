#include "common.h"
//#include <wiringSerial.h>
#include "serial.h"
#include "parse.h"
#include "node.h"
#include "crc.h"
#include "mqttc.h"
int recvfrom_switch(){
	//	if(wiringPiSetup() < 0){
	//		return 1;
	//	}

	//	int fd = serialOpen(ZIGBEE_DEV, BAUD);
	printf("start reading zigbee device\n");
	int fd = open(ZIGBEE_DEV, O_RDWR);
	if(fd < 0){
		perror("fd");
		exit(0);
	}
	else{
		if(fcntl(fd, F_SETFL,0) < 0)
			printf("fcntl failed\n");
		else
			printf("fcntl =%d\n", fcntl(fd, F_SETFL, 0));

		if(isatty(STDIN_FILENO) == 0)
			printf("standard input is not a terminal device\n");
		else
			printf("isatty success\n");
	}

	zfd = fd;
	unsigned char _p[8];
	unsigned char pkt[BUF_LEN];
	int pkt_len = 0;

	memset(_p, 0, 8);
	memset(pkt, 0, BUF_LEN);

	while(1){
		int ret = read(fd, _p, 8);
		if(ret < 0)
			return -1;
		else if(ret > 0){

			memcpy(pkt + pkt_len, _p, ret);
			pkt_len += ret;
			memset(_p, 0, 8);

			if(pkt_len > 1000){
				parse_packets(pkt, pkt_len);
				pkt_len = 0;
				memset(pkt, 0, BUF_LEN);
			}
		}
		else{
			if(pkt_len){
				parse_packets(pkt, pkt_len);
				pkt_len = 0;
				memset(pkt, 0, BUF_LEN);
			}
		}
	}

	close(fd);
	return 0;
}

int write_to_switch(unsigned char *message, unsigned int message_len, int times, int num, unsigned char target){
	if(zfd > 0){
		for(int i = 0; i < times; i++){
			int wret = write(zfd, message, message_len);
			if(wret > 0){ 
				for(int i = 0;i < message_len; i++){
					printf("%02x ", (unsigned char)message[i]);
				}   
				printf("\n");
				usleep(500000);
				//wait for new stat
							
				if(message_len == DEV_SINGLE_CMD_PKT_LEN){
					DPKT dpkt;
					memset(&dpkt, 0, sizeof(DPKT));
					memcpy(dpkt.s_macaddr, ((CMD_S_PKT *)message)->s_macaddr, S_MACADDR_LEN);
					unsigned char status = 0;
					unsigned char macaddr[MACADDR_LEN];

					pthread_mutex_lock(&mutex_lock);
					int ret = find_full_mac_and_status(&dpkt, macaddr, &status, NULL);
					pthread_mutex_unlock(&mutex_lock);
					if(ret == MAC_EXIST){
						unsigned char find_target = (status & (0x1 << num))>>num;
						if(find_target == target){
//							printf("new status %x\n", find_target);
							break;
						}
					}
					else{
						return ret;
					}
				}

			}   
			else{
				perror("write device");
				return WRITE_DEVICE_ERROR;
			}
		}
	}
	return 0;
}

int request_mac(char *type, unsigned char *mac, int len){
	if(zfd > 0){
		REQ_INIT_PKT pkt;
		memset(&pkt, 0, REQ_INIT_PKT_LEN);

		pkt.h[0] = 0xfe;
		pkt.h[1] = 0xfd;
		pkt.t[0] = 0xef;
		pkt.t[1] = 0xdf;
		memcpy(pkt.macaddr, mac, len);

		if(!strcmp(type, "long")){
			pkt.type = 3;
		}
		else if(!strcmp(type, "short")){
			pkt.type = 4;
		}
	
		int ret = write(zfd, &pkt, REQ_INIT_PKT_LEN);
		if(ret < 0){
			return WRITE_DEVICE_ERROR;
		}
	}
	return WRITE_DEVICE_ERROR;
}


int write_to_climate(char *type, char* payload){
	int fd = open(ZIGBEE_DEV, O_RDWR);
	if(fd < 0){ 
		perror("fd");
		exit(0);
	}   
	else{
		if(fcntl(fd, F_SETFL,0) < 0){
			goto exit;
		}

		if(isatty(STDIN_FILENO) == 0){
			printf("standard input is not a terminal device\n");
			goto exit;
		}
	}

	if(fd > 0){
		if(!strcmp(type, "power")){
			if(!strncmp(payload, "ON", 2)|| !strncmp(payload, "on", 2)){
				unsigned char status[8] = {};

				int ret = query_climate(fd, status);
				if(ret < 0)
					goto exit;
					
				status[0] = 0xa1;
				status[3] |= 1 << 4;
				status[7] = climate_crc(status, 8);

				ret = write_for_status(fd, status, 8);
				if(!ret){
					printf("exec on success\n");
				}
				else{
					printf("exec on failed\n");
				}
			}
			else if (!strncmp(payload, "OFF", 3) || !strncmp(payload, "off", 3)){
				unsigned char status[8] = {};
				int ret = query_climate(fd, status);
				if(ret < 0)
					goto exit;

				status[0] = 0xa1;
				status[3] = status[3] & (~(0x1 << 4));
				status[7] = climate_crc(status, 8);

				ret = write_for_status(fd, status, 8);
				if(!ret){
					printf("exec off success\n");
				}
				else{
					printf("exec off failed\n");
				}
			}
		}
		else if(!strcmp(type, "temperature_set")){
			int temp = 0;
			int ret = sscanf(payload, "%d", &temp);
			if(ret != 1)
				return -1;
			
			unsigned char status[8] = {};
			ret = query_climate(fd, status);
			if(ret < 0)
				goto exit;
			
			status[0] = 0xa1;
			status[5] = temp; 
			status[7] = climate_crc(status, 8);
			
			ret = write_for_status(fd, status, 8);
			if(!ret){
				printf("exec temperature_set success\n");
			}
			else{
				printf("exec temperature_set failed\n");
			}
		}
		else if(!strcmp(type, "temperature_increase")){
			int temp = 0;
			int ret = sscanf(payload, "%d", &temp);
			if(ret != 1)
				return -1;
			
			unsigned char status[8] = {};
			ret = query_climate(fd, status);
			if(ret < 0)
				goto exit;
			status[5] = status[5] + temp;
			char increase_temp[256] = "";
			sprintf(increase_temp, "mosquitto_pub -h %s -t 'homeassistant/ac/temperature_set' -m '%d'", HOST, status[5]);
			system(increase_temp);
		}
		else if(!strcmp(type, "mode_set")){
			unsigned char status[8] = {};
			int ret = ret = query_climate(fd, status);
			if(ret < 0)
				goto exit;
			
			if (!strncmp(payload, "COOL", 4) || !strncmp(payload, "cool", 4)){
				status[3] = status[3] & (~(0x1 << 5));
			}
			else if (!strncmp(payload, "HEAT", 4) || !strncmp(payload, "heat", 4)){
				status[3] |= 1 << 5;
			}
			else{//default cool
				status[3] = status[3] & (~(0x1 << 5));
			}

			status[0] = 0xa1;
			status[7] = climate_crc(status, 8);
			
			ret = write_for_status(fd, status, 8);
			if(!ret){
				printf("exec mode_set success\n");
			}
			else{
				printf("exec mode_set failed\n");
			}
		}
		else if(!strcmp(type, "fan_set")){
			unsigned char status[8] = {};
			int ret = query_climate(fd, status);
			if(ret < 0)
				goto exit;

			if (!strncmp(payload, "MAX", 3) || !strncmp(payload, "max", 3) ||
					!strncmp(payload, "HIGH", 4) || !strncmp(payload, "high", 4)){
				status[3] = status[3] & (~0x3) | 0x1;
				
			}
			else if (!strncmp(payload, "MIDDLE", 6) || !strncmp(payload, "middle", 6) ||
					!strncmp(payload, "medium", 6) || !strncmp(payload, "MEDIUM", 6)){
				status[3] = status[3] & (~0x3) | 0x2;
			}
			else if (!strncmp(payload, "LOW", 3) || !strncmp(payload, "low", 3) ||
					!strncmp(payload, "min", 3) || !strncmp(payload, "min", 4)){
				status[3] = status[3] & (~0x3) | 0x3;
			}
			else{
				//auto
				status[3] = status[3] & (~0x3);
			}

			status[0] = 0xa1;
			status[7] = climate_crc(status, 8);
			
			ret = write_for_status(fd, status, 8);
			if(!ret){
				printf("exec fan_set success\n");
			}
			else{
				printf("exec fan_set failed\n");
			}
		}
		else if(!strcmp(type, "fan_increase")){
			int temp = 0;
			int ret = sscanf(payload, "%d", &temp);
			if(ret != 1)
				return -1;
			
			unsigned char status[8] = {};
			ret = query_climate(fd, status);
			if(ret < 0)
				goto exit;


			int fan_pass = status[3] & 0x3;
			char increase_fan[256];
			char speed[8];
			memset(increase_fan, 0, 256);
			memset(speed, 0, 8);

			if(temp > 0){
				if(fan_pass == 0x3){
					memcpy(speed, "medium", 6);
				}
				else if (fan_pass == 0x2){
					memcpy(speed, "high", 4);
				}
				else if (fan_pass == 0x1){
					memcpy(speed, "high", 4);
				}
				else if (fan_pass == 0x0){
					memcpy(speed, "medium", 6);
				}
			}
			else if(temp < 0){
				if(fan_pass == 0x3){
					memcpy(speed, "low", 3);
				}
				else if(fan_pass == 0x2){
					memcpy(speed, "low", 3);
				}
				else if(fan_pass == 0x1){
					memcpy(speed, "medium", 6);
				}
				else if(fan_pass == 0x0){
					memcpy(speed, "low", 3);
				}
			}

			sprintf(increase_fan, "mosquitto_pub -h %s -t 'homeassistant/ac/fan_set' -m '%s' ", HOST, speed);
			system(increase_fan);
		}
	}
	if(!strcmp(type, "temperature_increase") || !strcmp(type, "fan_increase")){
	}
	else{
		update_climate(fd, type);
	}
	close(fd);
	return 0;
exit:
	close(fd);
	return WRITE_DEVICE_ERROR;
}

void update_climate(int fd, char *type){
	char update_mode[256] = "";
	char update_temp[256] = "";
	char update_temp_current[256] = "";
	char update_fan[256] = "";

	unsigned char res[64] = "";
	int ret;
	ret = query_climate(fd, res);
	if(ret < 0)
		return;
	

	int mode = (res[3] & (0x1 << 5)) >> 5;
	int current = res[6];
	int fan = res[3] & 0x3;
	char fan_mode[8] = "";
	if(fan == 0){
		memcpy(fan_mode, "auto", 4);
	}
	else if (fan == 0x1){
		memcpy(fan_mode, "high", 4);
	}
	else if (fan == 0x2){
		memcpy(fan_mode, "medium", 6);
	}
	else if (fan == 0x3){
		memcpy(fan_mode, "low", 3);
	}
	
	int on = (res[3] & (0x1 << 4)) >> 4;
	if(on)
		sprintf(update_mode , "mosquitto_pub -h %s -t 'homeassistant/ac/mode_state' -m '%s' ", HOST, mode == 0?"cool":"heat");
	else
		sprintf(update_mode , "mosquitto_pub -h %s -t 'homeassistant/ac/mode_state' -m 'off' ", HOST);
	sprintf(update_temp , "mosquitto_pub -h %s -t 'homeassistant/ac/temperature_state' -m '%d' ", HOST, res[5]);
	sprintf(update_temp_current , "mosquitto_pub -h %s -t 'homeassistant/ac/temperature_current' -m '%d' ", HOST, current);
	sprintf(update_fan , "mosquitto_pub -h %s -t 'homeassistant/ac/fan_state' -m '%s' ", HOST, fan_mode);
	
	system(update_mode);
	system(update_temp);
	system(update_temp_current);
	system(update_fan);
}

int write_for_status(int fd, unsigned char *data, int datalen){
	int ret = write(fd, data, datalen);
	if(ret < datalen){
		return -1;
	}
	
	usleep(500000);
	unsigned char buf[128] = "";
	ret = read(fd, buf, 0);

	if(ret > 0){
		printf("response: ");
		for(int i = 0; i < ret; i++){
			printf("%02x ", buf[i]);
		}
		printf("\n");
	}
	return 0;
}

int query_climate(int fd, unsigned char* res){
	unsigned char query[8] = {0xa0, 0x33, 0x10, 0x00, 0x00, 0x00, 0x00, 0x46};
	unsigned char _res[128] = { };
	int buf_len = 128;
	int ret = write(fd, query, 8);
	if(ret != 8)
		return -1;
	
	for(int i = 0; i < 3; i++){
		ret = read(fd, _res, buf_len);
		if(ret == 8){
			break;
		}
		else{
			usleep(500000);
		}
	}

	memcpy(res, _res, 8);

	return 0;
}
