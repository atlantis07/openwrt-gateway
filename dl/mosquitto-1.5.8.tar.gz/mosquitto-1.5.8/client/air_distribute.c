#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

//#include <termio.h>
//#include <error.h>
#include <string.h>


struct param
{
	int fd;
	int argc;
	char **argv;
};

static void *mqtt_rpthread(void *arg) {
	struct param *p = (struct param *)arg;;

	while (true){
		//Unexpect exit
		recv_from_server(p->argc, p->argv, p->fd);
		sleep(5);
	}

	return 0;
}

static void *mqtt_spthread(void *arg) {
//	struct param *p = (struct param *)arg;;
//	while (true){
//		serial_to_net(p->argc, p->argv, p->fd);
//		sleep(5);
//	}
}

int main(int argc, char *argv[]){
	int fd = open("/dev/ttyS1", O_RDWR|O_NOCTTY|O_NDELAY);
	if(fd < 0){
		printf("open ttyS1 failed [%d]\n", fd);
		return 1;
	}

	if(fcntl(fd, F_SETFL,0) < 0)
		printf("fcntl failed\n");
	else
		printf("fcntl =%d\n", fcntl(fd, F_SETFL, 0));

	if(isatty(STDIN_FILENO) == 0)
		printf("standard input is not a terminal device\n");
	else
		printf("isatty success\n");

	struct param p;
	p.argc = argc;
	p.argv = argv;
	p.fd = fd;

	pthread_t rpid, spid;
	int rret, sret;

	pthread_attr_t rattr, sattr;
	pthread_attr_init(&rattr);
	pthread_attr_init(&sattr);

	pthread_attr_setdetachstate(&rattr, PTHREAD_CREATE_JOINABLE);
	pthread_attr_setdetachstate(&sattr, PTHREAD_CREATE_JOINABLE);

	rret = pthread_create(&rpid, &rattr, mqtt_rpthread, (void *)&p);
	if(rret<0)
	{
		printf("pthread_create error,ret=%d\n",rret);
		return -1;
	}


	sret = pthread_create(&spid, &sattr, mqtt_spthread, (void *)&p);
	if(sret<0)
	{
		printf("pthread_create error,ret=%d\n",sret);
		return -1;
	}

	pthread_join(rpid, NULL);
	pthread_join(spid, NULL);
	printf("Passthrough threads exit\n");
	return 0;
}
