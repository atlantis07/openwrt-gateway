#include "common.h"
#include "task.h"
#include "node.h"
#include "stm32.h"
#include "switch.h"
#include "air_condition.h"
#include "scene.h"

TASK_QUEUE* task_head = NULL;
int task_num = 0;

int task_init(){
	task_head = (TASK_QUEUE*) malloc(sizeof(TASK_QUEUE));
	if(!task_head){
		tl_printf(MSG_ERROR,"init task failed\n");
		return TASK_INIT; 
	}   

	task_head->next = NULL;
	task_head->prev = NULL;
	return TASK_OK;
}

int task_insert_tail(TASKINFO tinfo){
	TASK_QUEUE* t = (TASK_QUEUE*)malloc(sizeof(TASK_QUEUE));
	if(!t){
		tl_printf(MSG_ERROR, "malloc task error");
		return TASK_MALLOC;
	}   

	memcpy(&t->tinfo, (const void*)&tinfo, sizeof(TASKINFO));
	t->next = NULL;

	TASK_QUEUE *s = NULL;
	TASK_QUEUE *e = NULL;
	s = task_head;
	e = s->next;
	while(e){
		s = e;
		e = e->next;
	}   

	s->next = t; 
	t->prev = s;

	task_num++;
	return TASK_OK;
}

void task_insert(int action, int type, void *data, int datalen){
	TASKINFO _tinfo;
	memset(&_tinfo, 0, sizeof(TASKINFO));

	_tinfo.type = type;
	_tinfo.action = action;
	memcpy(_tinfo.data, (char *)data, datalen);

	task_insert_tail(_tinfo);
	return;
}

int task_remove_head(TASKINFO *tinfo){
	if(!task_head || !tinfo){
		return TASK_OK;
	}

	TASK_QUEUE *temp = task_head->next, *next = NULL;
	if(!temp){
		return TASK_EMPTY;
	}

	next = temp->next;

	task_head->next = next;
	if(next){
		next->prev = task_head;
	}

	temp->prev = NULL;
	temp->next = NULL;

	memcpy(tinfo, &temp->tinfo, sizeof(TASKINFO));

	free(temp);

	task_num--;
	return TASK_OK;
}

void task_print(void){
	if(!task_head){
		return;
	}

	tl_printf(MSG_INFO, "task:");
	TASK_QUEUE *p = NULL;
	p = task_head->next;
	while(p){
		tl_printf(MSG_INFO, "    action %d, type %d", p->tinfo.action, p->tinfo.type);
		p = p->next;
	}
}

void update_switch(const unsigned char* macaddr,
		const unsigned char new_status,
		const SWITCH_SCENE_INFO scene, const char* type){

	unsigned char ori_status = 0;
	unsigned char num = new_status >> 4;
	unsigned char status = new_status & 0x0f;
	unsigned char full_mac[MACADDR_LEN] = "";

	pthread_mutex_lock(&node_mutex_lock);
	int f = find_switch_status(macaddr, &ori_status);
	pthread_mutex_unlock(&node_mutex_lock);

	if(f == 0){
		int i = 0;
		while(num){
			if(num & 0x1){
				ori_status = (ori_status & ~(1 << i)) | (status & (1 << i));
			}
			num >>= 1;
			i++;
		}

		INIT_DPKT ipkt;
		memset(&ipkt, 0, sizeof(INIT_DPKT));
		memcpy(ipkt.macaddr, macaddr, MACADDR_LEN);
		ipkt.status = ori_status;

		pthread_mutex_lock(&switch_mutex_lock);
		switch_action(type, &ipkt, &scene);
		pthread_mutex_unlock(&switch_mutex_lock);
	}
}

void *task_report(void *arg){
	TASKINFO *tinfo = (TASKINFO *)arg;
	if(!tinfo){
		return;
	}

	if(tinfo->type == DEVICE_SWITCH){
		SWITCHINFO *sdata = (SWITCHINFO *)tinfo->data;
		switch_send_foreach(sdata->macaddr, (sdata->status >> 4), sdata->status);
		update_switch(sdata->macaddr, sdata->status, sdata->scene, "update_status");		
	}
	else if((tinfo->type == DEVICE_STM32_DETECT) || (tinfo->type == DEVICE_STM32_EBTN)){
		STM32_DATA_T *ddata = (STM32_DATA_T *)tinfo->data;
		stm32_send_foreach((ddata->status >> 4), ddata->status, ddata->type);
	}

	free(arg);
	arg = NULL;
	return;
}


void *task_scene(void *arg){
	TASKINFO *tinfo = (TASKINFO *)arg;
	if(!tinfo){
		return;
	}

	if(tinfo->type == DEVICE_SWITCH){
		SWITCHINFO* sdata = (SWITCHINFO *)tinfo->data;
		if(sdata){
			tl_printf(MSG_INFO, "scene mode %s", sdata->scene.switch_mode);
			unsigned char scene_num = (sdata->status >> 4);
			unsigned char i = 1;
			char scene_name[SWITCH_SCENE_LEN] = "";
			char scene_name_temp[SWITCH_SCENE_LEN] = "";
			unsigned char scene_len = 0;
			unsigned char cur = 0;
			while(scene_num){
				if(scene_num & 0x1){
					break;
				}
				scene_num = scene_num >> 1;
				i++;
			}

			if(i == 1){
				memcpy(scene_name, sdata->scene.switch_scene1, SWITCH_SCENE_LEN);
				scene_len = find_char_max(scene_name, ',');
				
				cur = sdata->scene.scene1_current;
				if(++sdata->scene.scene1_current > scene_len){
					sdata->scene.scene1_current = 0;
				}
			}
			else if(i == 2){
				memcpy(scene_name, sdata->scene.switch_scene2, SWITCH_SCENE_LEN);
				scene_len = find_char_max(scene_name, ',');
				cur = sdata->scene.scene2_current;
				if(++sdata->scene.scene2_current > scene_len){
					sdata->scene.scene2_current = 0;
				}
			}
			else if(i == 3){
				memcpy(scene_name, sdata->scene.switch_scene3, SWITCH_SCENE_LEN);
				scene_len = find_char_max(scene_name, ',');
				cur = sdata->scene.scene3_current;
				if(++sdata->scene.scene3_current > scene_len){
					sdata->scene.scene3_current = 0;
				}
			}
			else if(i == 4){
				memcpy(scene_name, sdata->scene.switch_scene4, SWITCH_SCENE_LEN);
				scene_len = find_char_max(scene_name, ',');
				cur = sdata->scene.scene4_current;
				if(++sdata->scene.scene4_current > scene_len){
					sdata->scene.scene4_current = 0;
				}
			}

			if(scene_len >= 0){
				if(scene_len > 0){
					//abcdef,ghij,klm
					if(cur == 0){
						unsigned char pos = find_char(scene_name, ',', 1);
						memcpy(scene_name_temp, scene_name, pos);
					}
					else if(cur == scene_len){
						unsigned char pos = find_char(scene_name, ',', cur);
						if((pos + 1) == strlen(scene_name)){
							goto scene_end;
						}
						else{
							memcpy(scene_name_temp, scene_name + pos + 1, strlen(scene_name) - pos - 1);
						}
					}
					else{
						unsigned char poss = find_char(scene_name, ',', cur);
						unsigned char pose = find_char(scene_name, ',', cur + 1);
						if(pose - poss - 1 > 0){
							memcpy(scene_name_temp, scene_name + poss + 1, pose - poss - 1);
						}
						else{
							goto scene_end;
						}
					}
					tl_printf(MSG_INFO, "scene name:%s", scene_name_temp);
					scene_action(scene_name_temp);
				}
				else{
					tl_printf(MSG_INFO, "scene name:%s", scene_name);
					scene_action(scene_name);
				}
				update_switch(sdata->macaddr, sdata->status, sdata->scene, "update_scene");		
			}
		}
	}

scene_end:
	free(arg);
	arg = NULL;
	return;
}

void task_report_thread(TASKINFO *tinfo){
	if(!tinfo){
		return;
	}
	TASKINFO *t = (TASKINFO *)malloc(sizeof(TASKINFO));
	memcpy(t, tinfo, sizeof(TASKINFO));

	pthread_t dispatch_pid;
	pthread_attr_t dispatch_attr;
	pthread_attr_init(&dispatch_attr);
	pthread_attr_setdetachstate(&dispatch_attr, PTHREAD_CREATE_DETACHED);
	int dispatch_ret = 0;
	dispatch_ret = pthread_create(&dispatch_pid, &dispatch_attr, task_report, (void *)t);
	pthread_attr_destroy(&dispatch_attr);
	if(dispatch_ret){
		tl_printf(MSG_ERROR, "create %d %d thread error", tinfo->action, tinfo->type);
	}
	return;
}

void task_scene_thread(TASKINFO *tinfo){
	if(!tinfo){
		return;
	}
	TASKINFO *t = (TASKINFO *)malloc(sizeof(TASKINFO));
	memcpy(t, tinfo, sizeof(TASKINFO));

	pthread_t dispatch_pid;
	pthread_attr_t dispatch_attr;
	pthread_attr_init(&dispatch_attr);
	pthread_attr_setdetachstate(&dispatch_attr, PTHREAD_CREATE_DETACHED);
	int dispatch_ret = 0;
	dispatch_ret = pthread_create(&dispatch_pid, &dispatch_attr, task_scene, (void *)t);
	pthread_attr_destroy(&dispatch_attr);
	if(dispatch_ret){
		tl_printf(MSG_ERROR, "create %d %d thread error", tinfo->action, tinfo->type);
	}
	return;
}

void *task_run(void *arg){
	bool process_task = 0;
	while(true){
		pthread_mutex_lock(&task_mutex_lock);
		if(task_num){
			TASKINFO tinfo = {};
			task_remove_head(&tinfo);
			tl_printf(MSG_INFO, "tl task:%d %d", tinfo.action, tinfo.type);
			
			if((tinfo.action == ACTION_REPORT)){
				task_report_thread(&tinfo);
			}
			
			if(tinfo.action == ACTION_SCENE){
				task_scene_thread(&tinfo);
			}

			process_task = 1;
		}
		pthread_mutex_unlock(&task_mutex_lock);

		if(process_task){
			process_task = 0;
		}
		else{
			usleep(200000);
		}
	}
}
