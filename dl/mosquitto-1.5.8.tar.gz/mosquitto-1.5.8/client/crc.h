#ifndef _CRC_H
#define _CRC_H
typedef unsigned char uint8_t; 
typedef unsigned short uint16_t;
typedef int int32_t;

uint16_t crc16table(uint8_t *ptr, uint16_t len);
uint16_t crc16bitbybit(uint8_t *ptr, uint16_t len);
uint16_t crc16tablefast(uint8_t *ptr, uint16_t len);
unsigned char climate_crc(unsigned char* data, int len);
#endif
