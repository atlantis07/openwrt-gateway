#ifndef _MQTTC_H
#define _MQTTC_H
#include "switch.h"
#include "air_condition.h"

#include "cJSON.h"
#include "common.h"
#include <unistd.h>
typedef struct tanklight_reginfo {
	unsigned char smacaddr[S_MACADDR_LEN];
	unsigned char macaddr[MACADDR_LEN];
	unsigned char switch_way;
	char climate_series[AIR_SERIES_LEN];
	unsigned char climate_addr[AIR_ADDR_LEN];
}TANKLIGHT_REGINFO;

/****************************************SWITCH INIT****************************************/

#define SWITCH_NAME		"%02x%02x%02x%02x%02x%02x%02x%02x-%d"
#define SWITCH_CMD		"%s/switch/%02x%02x%02x%02x%02x%02x%02x%02x-%d/set"
#define SWITCH_STATE	"%s/switch/%02x%02x%02x%02x%02x%02x%02x%02x-%d/state"

#define ZR_DEV_CMD 		"%s/zigbee-router/id/set"
#define STM32_DEV_STATUS "%s/stm32-%s/00-%d/state"

#define ID_LEN 16
#define NUM_LEN 8
#define TOPIC_LEN 128

#define POS_START 19
//#define POS_START 33
//112233445566/switch/aabbccddeeff0011-1/config

#define ONLINE "online"
#define OFFLINE "offline"
#define ON "ON"
#define OFF "OFF"

#define MQTT_CMD "mosquitto_pub -h %s -p %s --cafile /etc/keys/ca.crt --cert /etc/keys/client.crt --key /etc/keys/client.key --tls-version tlsv1 -u %s -P %s -t \"%s\" -q 1 -m \"%s\""

void register_device(SWITCHINFO snode);
int switch_set_status(unsigned char *macaddr, int num, int status);


/****************************************AIRCONDITION INIT****************************************/
#endif
