#ifndef _MQTTC_H
#define _MQTTC_H
#include "node.h"
#include <unistd.h>

#define SWITCH_PARAM_LEN 128
#define SWITCH_REG_LEN	512

#define SWITCH_CONFIG	"homeassistant/switch/%02x%02x%02x%02x%02x%02x%02x%02x-%d/config"
#define SWITCH_NAME		"%02x%02x%02x%02x%02x%02x%02x%02x-%d"
#define SWITCH_CMD		"homeassistant/switch/%02x%02x%02x%02x%02x%02x%02x%02x-%d/set"
#define SWITCH_STATE	"homeassistant/switch/%02x%02x%02x%02x%02x%02x%02x%02x-%d/state"
#define SWITCH_AVAL		"homeassistant/switch/%02x%02x%02x%02x%02x%02x%02x%02x-%d/available"

#define HOST	"39.98.165.253"

#define POS_START 20
//homeassistant/switch/aabbccddeeff0011-1/config

#define SWITCH_REG "mosquitto_pub -h %s -t \"%s\" -m \"{\\\"name\\\": \\\"%s\\\", \\\"command_topic\\\": \\\"%s\\\", \\\"state_topic\\\": \\\"%s\\\", \\\"availability_topic\\\": \\\"%s\\\", \\\"qos\\\":1}\""

#define ONLINE "online"
#define OFFLINE "offline"
#define ON "ON"
#define OFF "OFF"

#define SWITCH_SET "mosquitto_pub -h %s -t \"%s\" -q 1 -m \"%s\""

void register_device(NODEINFO node);
int switch_register(unsigned char *macaddr, int num);
int switch_active(unsigned char *macaddr, int num, char* s);
int switch_set_status(unsigned char *macaddr, int num, int status);
#endif
