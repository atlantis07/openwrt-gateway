#ifndef _MQTTC_H
#define _MQTTC_H
#include "switch.h"
#include "air_condition.h"

#include "cJSON.h"
#include "common.h"
#include <unistd.h>
typedef struct tanklight_reginfo {
	unsigned char smacaddr[S_MACADDR_LEN];
	unsigned char macaddr[MACADDR_LEN];
	unsigned char switch_way;
	char climate_series[AIR_SERIES_LEN];
	unsigned char climate_addr[AIR_ADDR_LEN];
}TANKLIGHT_REGINFO;

/****************************************SWITCH INIT****************************************/

#define SWITCH_PARAM_LEN 128
#define SWITCH_REG_LEN	512

#define SWITCH_CONFIG	"%s/switch/%02x%02x%02x%02x%02x%02x%02x%02x-%d/config"
#define SWITCH_NAME		"%02x%02x%02x%02x%02x%02x%02x%02x-%d"
#define SWITCH_CMD		"%s/switch/%02x%02x%02x%02x%02x%02x%02x%02x-%d/set"
#define SWITCH_STATE	"%s/switch/%02x%02x%02x%02x%02x%02x%02x%02x-%d/state"
#define SWITCH_AVAL		"%s/switch/%02x%02x%02x%02x%02x%02x%02x%02x-%d/available"

#define TANKLIGHT_CONFIG "%s/switch/config"
#define TANKLIGHT_NAME "%s"
#define TANKLIGHT_CMD	"%s/switch/set"
#define TANKLIGHT_STATE	"%s/switch/state"
#define TANKLIGHT_AVAL	"%s/switch/available"
#define TANKLIGHT_REG "mosquitto_pub -h %s -t '%s' -m '%s'"

#define ID_LEN 16
#define NUM_LEN 8
#define HA_PARAM_LEN 128
#define HA_REG_LEN	512
#define TOPIC_LEN 128

#define POS_START 19
//#define POS_START 33
//112233445566/switch/aabbccddeeff0011-1/config

#define SWITCH_REG "mosquitto_pub -h %s -t '%s' -m \"{\\\"name\\\": \\\"%s\\\", \\\"command_topic\\\": \\\"%s\\\", \\\"state_topic\\\": \\\"%s\\\", \\\"availability_topic\\\": \\\"%s\\\", \\\"qos\\\":1}\""

#define ONLINE "online"
#define OFFLINE "offline"
#define ON "ON"
#define OFF "OFF"

#define SWITCH_SET "mosquitto_pub -h %s -t \"%s\" -q 1 -m \"%s\""

void register_device(SWITCHINFO snode);
int switch_register(unsigned char *macaddr, int num);
int switch_active(unsigned char *macaddr, int num, char* s);
int switch_set_status(unsigned char *macaddr, int num, int status);


/****************************************AIRCONDITION INIT****************************************/
#define AIRCONDITION_REG_LEN	2048
int register_aircondition(unsigned char *air_macaddr, char *type);
int air_online(unsigned char *air_macaddr, char *state, char *type);
int aircondition_active();
int aircondition_set_status();

#define AIRCONDITION_REG "mosquitto_pub -h %s -t '%s' -m \"{\\\"availability_topic\\\":\\\"%s\\\" ,\\\"name\\\": \\\"%s\\\", \\\"modes\\\":%s, \\\"fan_modes\\\":%s, \\\"power_command_topic\\\":\\\"%s\\\", \\\"mode_command_topic\\\":\\\"%s\\\", \\\"mode_state_topic\\\":\\\"%s\\\", \\\"temperature_command_topic\\\":\\\"%s\\\", \\\"temperature_state_topic\\\":\\\"%s\\\", \\\"increase_tempture_topic\\\":\\\"%s\\\", \\\"current_temperature_topic\\\":\\\"%s\\\", \\\"fan_mode_command_topic\\\":\\\"%s\\\", \\\"increase_fan_topic\\\":\\\"%s\\\", \\\"fan_mode_state_topic\\\":\\\"%s\\\", \\\"update_climate_topic\\\":\\\"%s\\\", \\\"qos\\\":2}\""

#define AIRCONDITION_AVAL_REG "mosquitto_pub -h %s -t '%s' -m \"%s\""

#define AIR_CONFIG				"%s/climate/%s/%s/config"
#define AIR_AVAL				"%s/climate/%s/%s/available"


#define AIR_NAME				"%s-climate"
//#define AIR_MODES				"[\\\"cool\\\", \\\"heat\\\", \\\"off\\\"]"
#define AIR_MODES	"[\\\"auto\\\", \\\"off\\\", \\\"cool\\\", \\\"heat\\\", \\\"dry\\\", \\\"fan_only\\\"]"
#define AIR_FANMODES			"[\\\"high\\\", \\\"medium\\\", \\\"low\\\", \\\"auto\\\"]"

#define AIR_POWER				"%s/climate/%s/%s/power"
#define AIR_MODE_CMD			"%s/climate/%s/%s/mode_set"
#define AIR_MODE_STATE			"%s/climate/%s/%s/mode_state"
#define AIR_TEMP_CMD			"%s/climate/%s/%s/temperature_set"
#define AIR_TEMP_STATE			"%s/climate/%s/%s/temperature_state"
#define AIR_TEMP_INCREASE		"%s/climate/%s/%s/temperature_increase"
#define AIR_TEMP_CURRENT		"%s/climate/%s/%s/temperature_current"
#define AIR_FANMODE_CMD			"%s/climate/%s/%s/fan_set"
#define AIR_FANMODE_INCREASE	"%s/climate/%s/%s/fan_increase"
#define AIR_FANMODE_STATE		"%s/climate/%s/%s/fan_state"
#define AIR_UPDATE				"%s/climate/%s/%s/update"



#endif
