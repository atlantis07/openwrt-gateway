#ifndef _ZR_H
#define _ZR_H

#define CMD_ZR "zigbee_router"

typedef struct
{
    unsigned char h[2];
    unsigned char dt; 
    unsigned char type;
    //unsigned char action;
    unsigned char datalen;
    //unsigned char id; 
    unsigned char status;
    unsigned char crc[2];
    unsigned char t[2];
}DEVZR_T;

#define DEVZR_T_LEN sizeof(DEVZR_T)

#define DEVZR_SET 0x13
#define ZR_MIN_NETWORK_DISABLE 0
#define ZR_MAX_NETWORK_DISABLE 120

int write_to_zr(unsigned char id, char *cmd, char *data);
#endif
