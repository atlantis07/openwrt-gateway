#ifndef _TL_DEBUG_H
#define _TL_DEBUG_H

#include <syslog.h>
#include <stdio.h>
#include <stdarg.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>

enum {
	    MSG_EXCESSIVE, MSG_MSGDUMP, MSG_DEBUG, MSG_INFO, MSG_WARNING, MSG_ERROR 
};

int tl_get_time(struct os_time *t);
void tl_debug_print_timestamp(void);
int tl_debug_open_file(const char *path);
int tl_printf(int level, const char* format, ...);

#endif
