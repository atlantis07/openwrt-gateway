#ifndef _TL_H
#define _TL_H

#include "switch.h"
#include "air_condition.h"

typedef struct switch_reg_info{
	unsigned char switch_num;
	unsigned char switch_status;
	SWITCH_SCENE_INFO switch_scene;
}SWITCH_REG_INFO;

int tanklight_control(char* topic, char* message);
int tanklight_getreginfo(char *tkreginfo, SWITCH_REG_INFO* switch_reg, AC_REG_INFO *ac_reg);
#endif
