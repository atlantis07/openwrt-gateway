#include "timer.h"
#include "node.h"
#include "switch.h"
#include "air_condition.h"
#include <stdbool.h>
#include <pthread.h>
void _setTimer()
{
	struct timeval temp;
	temp.tv_sec = TIMER_INTERVAL;
	temp.tv_usec = 0;

	int err;
	do{
		err = select(0, NULL, NULL, NULL, &temp);
	}while(err<0 && errno==EINTR);
}

void print_all(){
	pthread_mutex_lock(&node_mutex_lock);
	node_action("print/reg/signal");
	pthread_mutex_unlock(&node_mutex_lock);

	pthread_mutex_lock(&switch_mutex_lock);
	switch_action("print", NULL, NULL);
	pthread_mutex_unlock(&switch_mutex_lock);

	pthread_mutex_lock(&air_mutex_lock);
	airnode_action("print");
	pthread_mutex_unlock(&air_mutex_lock);
}

void *setTimer(void *arg){
	while(true){
		_setTimer();
		print_all();
	}
}
