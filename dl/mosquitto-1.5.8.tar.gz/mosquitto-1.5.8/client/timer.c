#include "timer.h"
#include "node.h"
#include "air_condition.h"
#include <stdbool.h>
#include <pthread.h>
void _setTimer()
{
	struct timeval temp;
	
	temp.tv_sec = 30;
	temp.tv_usec = 0;

	select(0, NULL, NULL, NULL, &temp);
	pthread_mutex_lock(&mutex_lock);
	node_action("timer", NULL);
	node_action("print", NULL);
	pthread_mutex_unlock(&mutex_lock);


	pthread_mutex_lock(&air_mutex_lock);
	airnode_action("print");
	pthread_mutex_unlock(&air_mutex_lock);

}

void *setTimer(void *arg){
	while(true){
		_setTimer();

		if(!t_flag){
			break;
		}
	}
}
