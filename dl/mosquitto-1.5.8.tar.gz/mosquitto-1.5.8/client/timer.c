#include "timer.h"
#include "node.h"
#include <pthread.h>
void* setTimer(void *arg)
{
	//pthread_detach(pthread_self());
	struct timeval temp;
	
	temp.tv_sec = 5;
	temp.tv_usec = 0;

	select(0, NULL, NULL, NULL, &temp);
	pthread_mutex_lock(&mutex_lock);
	node_action("timer", NULL);
//	node_action("print", NULL);
	pthread_mutex_unlock(&mutex_lock);
	

	if(t_flag){
		setTimer(NULL);
	}
	return NULL;
}


