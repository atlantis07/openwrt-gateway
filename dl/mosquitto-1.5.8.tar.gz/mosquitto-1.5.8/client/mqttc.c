#include "mqttc.h"
#include "common.h"
void register_device(SWITCHINFO Switch){
	if(!serveripaddr){
		return;
	}

	SWITCHINFO _switch = Switch;
	int num = (_switch.status & 0xf0) >> 4;
	int status = (_switch.status & 0x0f);

	if(num <= 0 ){
		return;
	}

	int i = 0, n = num & 1;
	while(n){
		switch_set_status(_switch.macaddr, i, ((status >> i) & 0x1));

		num = num >> 1;
		n = num & 0x1;
		i++;
	}
}

int switch_set_status(unsigned char *macaddr, int num, int status){
	if(!macaddr || !serveripaddr){
		return -1;
	}
	
	char sstatus[LEN256];
	char scontrol[LEN256];
	memset(sstatus,	0, LEN256);
	memset(scontrol, 0, LEN256);
	
	sprintf(sstatus, SWITCH_STATE, gwmacaddr,
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);
	if(status == 0){	
		sprintf(scontrol, MQTT_CMD, serveripaddr, port, username, password, sstatus, OFF);
	}
	else if(status == 1){
		sprintf(scontrol, MQTT_CMD, serveripaddr, port, username, password, sstatus, ON);
	}

	system(scontrol);
	usleep(100000);
	return 0;
}
