#include "mqttc.h"
#include "common.h"
void register_device(SWITCHINFO Switch){
	if(!serveripaddr){
		return;
	}

	SWITCHINFO _switch = Switch;
	int num = (_switch.status & 0xf0) >> 4;
	int status = (_switch.status & 0x0f);

	if(num <= 0 ){
		return;
	}

	int i = 0, n = num & 1;
	while(n){
//		switch_register(_node.macaddr, i);//register
//		switch_active(_node.macaddr, i, ONLINE);
		switch_set_status(_switch.macaddr, i, ((status >> i) & 0x1));

		num = num >> 1;
		n = num & 0x1;
		i++;
	}
}

int start = 0;

int switch_register(unsigned char *macaddr, int num){
	if(!macaddr){
		return -1;
	}
	char sconfig[SWITCH_PARAM_LEN];
	char sname[SWITCH_PARAM_LEN];
	char scmd[SWITCH_PARAM_LEN];
	char sstate[SWITCH_PARAM_LEN];
	char saval[SWITCH_PARAM_LEN];
	char sreg[SWITCH_REG_LEN];

	memset(sconfig, 0, SWITCH_PARAM_LEN);
	memset(sname, 0, SWITCH_PARAM_LEN);
	memset(scmd, 0, SWITCH_PARAM_LEN);
	memset(sstate, 0, SWITCH_PARAM_LEN);
	memset(saval, 0, SWITCH_PARAM_LEN);
	memset(sreg, 0, SWITCH_REG_LEN);

	sprintf(sconfig,	SWITCH_CONFIG, gwmacaddr,
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);
	sprintf(sname,		SWITCH_NAME,	
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);
	sprintf(scmd,		SWITCH_CMD,	gwmacaddr,
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);
	sprintf(sstate,		SWITCH_STATE, gwmacaddr,
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);
	sprintf(saval,		SWITCH_AVAL, gwmacaddr,
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);


	sprintf(sreg, SWITCH_REG, serveripaddr, sconfig, sname, scmd, sstate, saval);
	
	system(sreg);

	sleep(1);
//	usleep(1500000);
	return 0;
}

int switch_active(unsigned char *macaddr, int num, char *s){
	if(!macaddr){
		return -1;
	}

	char saval[SWITCH_PARAM_LEN];
	char sactive[SWITCH_PARAM_LEN];
	memset(saval,	0, SWITCH_PARAM_LEN);
	memset(sactive, 0, SWITCH_PARAM_LEN);

	sprintf(saval,		SWITCH_AVAL, gwmacaddr,
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);

	sprintf(sactive, SWITCH_SET, serveripaddr, saval, s);

	system(sactive);
	sleep(1);
//	usleep(1500000);
	return 0;
}

int switch_set_status(unsigned char *macaddr, int num, int status){
	if(!macaddr || !serveripaddr){
		return -1;
	}
	
	char sstatus[SWITCH_PARAM_LEN];
	char scontrol[SWITCH_PARAM_LEN];
	memset(sstatus,	0, SWITCH_PARAM_LEN);
	memset(scontrol, 0, SWITCH_PARAM_LEN);
	
	sprintf(sstatus,		SWITCH_STATE, gwmacaddr,
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);
	if(status == 0){	
		sprintf(scontrol, SWITCH_SET, serveripaddr, sstatus, OFF);
	}
	else if(status == 1){
		sprintf(scontrol, SWITCH_SET, serveripaddr, sstatus, ON);
	}

//	tl_printf(MSG_INFO, "%s\n", scontrol);
	system(scontrol);
	usleep(100000);
//	sleep(1);
	return 0;
}

#if 1
int  register_aircondition(unsigned char *air_macaddr, char *type){
	
	if(!air_macaddr || !type || !serveripaddr || !gwmacaddr){
		return -1;
	}

	unsigned char macaddr[HA_PARAM_LEN];
	memset(macaddr, 0, HA_PARAM_LEN);
	sprintf(macaddr, "%02x%02x%02x%02x%02x%02x%02x%02x", air_macaddr[0], air_macaddr[1], air_macaddr[2],
			air_macaddr[3], air_macaddr[4], air_macaddr[5], air_macaddr[6], air_macaddr[7]);

	unsigned char air_reginfo[AIRCONDITION_REG_LEN];
	unsigned char air_config[HA_PARAM_LEN];
	unsigned char air_aval[HA_PARAM_LEN];
	unsigned char air_name[HA_PARAM_LEN];
	unsigned char air_power[HA_PARAM_LEN];
	unsigned char air_mode_cmd[HA_PARAM_LEN];
	unsigned char air_mode_state[HA_PARAM_LEN];
	unsigned char air_temp_cmd[HA_PARAM_LEN];
	unsigned char air_temp_state[HA_PARAM_LEN];
	unsigned char air_temp_increase[HA_PARAM_LEN];
	unsigned char air_temp_current[HA_PARAM_LEN];
	unsigned char air_fanmode_cmd[HA_PARAM_LEN];
	unsigned char air_fanmode_increase[HA_PARAM_LEN];
	unsigned char air_fanmode_state[HA_PARAM_LEN];
	unsigned char air_update[HA_PARAM_LEN];


	memset(air_reginfo, 0, AIRCONDITION_REG_LEN);
	memset(air_config, 0, HA_PARAM_LEN);
	memset(air_aval, 0, HA_PARAM_LEN);
	memset(air_name, 0, HA_PARAM_LEN);
	memset(air_power, 0, HA_PARAM_LEN);
	memset(air_mode_cmd, 0, HA_PARAM_LEN);
	memset(air_mode_state, 0, HA_PARAM_LEN);
	memset(air_temp_cmd, 0, HA_PARAM_LEN);
	memset(air_temp_state, 0, HA_PARAM_LEN);
	memset(air_temp_increase, 0, HA_PARAM_LEN);
	memset(air_temp_current, 0, HA_PARAM_LEN);
	memset(air_fanmode_cmd, 0, HA_PARAM_LEN);
	memset(air_fanmode_increase, 0, HA_PARAM_LEN);
	memset(air_fanmode_state, 0, HA_PARAM_LEN);
	memset(air_update, 0, HA_PARAM_LEN);

//	sprintf(air_config, AIR_CONFIG, gwmacaddr, type, macaddr);
	sprintf(air_config, AIR_CONFIG, gwmacaddr,  macaddr, type);
	sprintf(air_aval, AIR_AVAL, gwmacaddr, type, macaddr);
	sprintf(air_name, AIR_NAME, macaddr);

	sprintf(air_power, AIR_POWER, gwmacaddr, type, macaddr);

	sprintf(air_mode_cmd, AIR_MODE_CMD, gwmacaddr, type, macaddr);
	sprintf(air_mode_state, AIR_MODE_CMD, gwmacaddr, type, macaddr);

	sprintf(air_temp_cmd, AIR_TEMP_CMD, gwmacaddr, type, macaddr);
	sprintf(air_temp_state, AIR_TEMP_STATE, gwmacaddr, type, macaddr);
	sprintf(air_temp_increase, AIR_TEMP_INCREASE, gwmacaddr, type, macaddr);
	sprintf(air_temp_current, AIR_TEMP_CURRENT, gwmacaddr, type, macaddr);

	sprintf(air_fanmode_cmd, AIR_FANMODE_CMD, gwmacaddr, type, macaddr);
	sprintf(air_fanmode_increase, AIR_FANMODE_INCREASE, gwmacaddr, type, macaddr);
	sprintf(air_fanmode_state, AIR_FANMODE_STATE, gwmacaddr, type, macaddr);

	sprintf(air_update, AIR_UPDATE, gwmacaddr, type, macaddr);

	sprintf(air_reginfo, AIRCONDITION_REG, 
			serveripaddr, air_config, air_aval,
			air_name, AIR_MODES, AIR_FANMODES, air_power,
			air_mode_cmd, air_mode_state,
			air_temp_cmd, air_temp_state, air_temp_increase, air_temp_current,
			air_fanmode_cmd, air_fanmode_increase, air_fanmode_state,
			air_update);

//	printf("%s\n", air_reginfo);
	system(air_reginfo);
	sleep(1);

	air_online(air_macaddr, "online", type);
	return 0;
}


int air_online(unsigned char *air_macaddr, char *state, char *type){
	if(!state || !air_macaddr || !gwmacaddr || !type || !serveripaddr){
		return -1;
	}
	
	unsigned char air_aval_reginfo[AIRCONDITION_REG_LEN];
	unsigned char macaddr[HA_PARAM_LEN];
	unsigned char air_aval_topic[HA_PARAM_LEN];

	memset(air_aval_reginfo, 0, AIRCONDITION_REG_LEN);
	memset(air_aval_topic, 0, HA_PARAM_LEN);
	memset(macaddr, 0, HA_PARAM_LEN);

	sprintf(macaddr, "%02x%02x%02x%02x%02x%02x%02x%02x", air_macaddr[0], air_macaddr[1], air_macaddr[2],
			air_macaddr[3], air_macaddr[4], air_macaddr[5], air_macaddr[6], air_macaddr[7]);
	sprintf(air_aval_topic, AIR_AVAL, gwmacaddr, type, macaddr);

	sprintf(air_aval_reginfo, AIRCONDITION_AVAL_REG, serveripaddr, air_aval_topic, state);

	system(air_aval_reginfo);
	usleep(100000);
}
#endif
