#include "mqttc.h"

void register_device(NODEINFO node){
	NODEINFO _node = node;
	int num = (_node.status & 0xf0) >> 4;
	int status = (_node.status & 0x0f);

	if(num <= 0 ){
		return;
	}


	int i = 0, n = num & 1;
	while(n){
		switch_register(_node.macaddr, i);//register
		switch_active(_node.macaddr, i, ONLINE);
		switch_set_status(_node.macaddr, i, ((status >> i) & 0x1));

		num = num >> 1;
		n = num & 0x1;
		i++;

	}
}

int start = 0;

int switch_register(unsigned char *macaddr, int num){
	if(!macaddr){
		return -1;
	}
	char sconfig[SWITCH_PARAM_LEN];
	char sname[SWITCH_PARAM_LEN];
	char scmd[SWITCH_PARAM_LEN];
	char sstate[SWITCH_PARAM_LEN];
	char saval[SWITCH_PARAM_LEN];
	char sreg[SWITCH_REG_LEN];

	memset(sconfig, 0, SWITCH_PARAM_LEN);
	memset(sname, 0, SWITCH_PARAM_LEN);
	memset(scmd, 0, SWITCH_PARAM_LEN);
	memset(sstate, 0, SWITCH_PARAM_LEN);
	memset(saval, 0, SWITCH_PARAM_LEN);
	memset(sreg, 0, SWITCH_REG_LEN);

	sprintf(sconfig,	SWITCH_CONFIG,	
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);
	sprintf(sname,		SWITCH_NAME,	
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);
	sprintf(scmd,		SWITCH_CMD,	
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);
	sprintf(sstate,		SWITCH_STATE,
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);
	sprintf(saval,		SWITCH_AVAL,
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);


	sprintf(sreg, SWITCH_REG, HOST, sconfig, sname, scmd, sstate, saval);
	
//	printf("%s\n", sreg);
	system(sreg);
	if(!start){
		start = 1;
		sleep(1);
	}
//	usleep(50000);
	return 0;
}

int switch_active(unsigned char *macaddr, int num, char *s){
	if(!macaddr){
		return -1;
	}

	char saval[SWITCH_PARAM_LEN];
	char sactive[SWITCH_PARAM_LEN];
	memset(saval,	0, SWITCH_PARAM_LEN);
	memset(sactive, 0, SWITCH_PARAM_LEN);

	sprintf(saval,		SWITCH_AVAL,
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);

	sprintf(sactive, SWITCH_SET, HOST, saval, s);

//	printf("%s\n", sactive);
	system(sactive);
//	usleep(50000);
	return 0;
}

int switch_set_status(unsigned char *macaddr, int num, int status){
	if(!macaddr){
		return -1;
	}
	
	char sstatus[SWITCH_PARAM_LEN];
	char scontrol[SWITCH_PARAM_LEN];
	memset(sstatus,	0, SWITCH_PARAM_LEN);
	memset(scontrol, 0, SWITCH_PARAM_LEN);
	
	sprintf(sstatus,		SWITCH_STATE,
			macaddr[0], macaddr[1], macaddr[2],	macaddr[3], 
			macaddr[4], macaddr[5], macaddr[6], macaddr[7], 
			num);
	if(status == 0){	
		sprintf(scontrol, SWITCH_SET, HOST, sstatus, OFF);
	}
	else if(status == 1){
		sprintf(scontrol, SWITCH_SET, HOST, sstatus, ON);
	}

	printf("%s\n", scontrol);
	system(scontrol);
//	usleep(50000);
	return 0;
}
