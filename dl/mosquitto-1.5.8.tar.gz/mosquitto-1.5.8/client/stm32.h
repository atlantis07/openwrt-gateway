#ifndef _STM32_H
#define _STM32_H


typedef struct
{
	unsigned char h[2];
	unsigned char dt;
	unsigned char type;
	unsigned char action;
	unsigned char datalen;
	unsigned char id;
	unsigned char status;
	unsigned char crc[2];
	unsigned char t[2];
}DETECT_T;
#define DETECT_T_LEN sizeof(DETECT_T)

typedef struct
{
	unsigned char id[2];
	unsigned char type;
	unsigned char status;
}STM32_DATA_T;

typedef struct
{
	unsigned char h[2];
	unsigned char dt;
	unsigned char type;
	unsigned char action;
	unsigned char datalen;
	unsigned char id;
	unsigned char status;
	unsigned char crc[2];
	unsigned char t[2];
}EBTN_T;
#define EBTN_T_LEN sizeof(EBTN_T)

void *stm32_common_pthread(void *arg);
int stm32_set_status(int num, int status, int type);
int stm32_send_foreach(int num, unsigned char status, int type);
#endif
