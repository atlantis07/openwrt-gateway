#ifndef _SWITCH_H
#define _SWITCH_H
#include <pthread.h>
#include "common.h"
#define TAIL_LEN	2

#define MACADDR_STRLEN 18
#define MAX_TIME 300

#define SHORTMAC_EXIST		(1)
#define SHORTMAC_NOT_EXIST	(0)
#define MAC_EXIST		SHORTMAC_EXIST
#define MAC_NOT_EXIST	SHORTMAC_NOT_EXIST
#define SWITCH_EXIST		SHORTMAC_EXIST
#define SWITCH_NOT_EXIST	SHORTMAC_NOT_EXIST

#define SWITCH_MODE_SCENE "Scene"
#define SWITCH_MODE_LEN 16
#define SWITCH_SCENE_LEN 64

typedef struct switch_scene_info{
	char switch_mode[SWITCH_MODE_LEN];
	char switch_scene1[SWITCH_SCENE_LEN];
	unsigned char scene1_current;
	char switch_scene2[SWITCH_SCENE_LEN];
	unsigned char scene2_current;
	char switch_scene3[SWITCH_SCENE_LEN];
	unsigned char scene3_current;
	char switch_scene4[SWITCH_SCENE_LEN];
	unsigned char scene4_current;
}SWITCH_SCENE_INFO;

typedef struct switchinfo{
//	unsigned char s_macaddr[S_MACADDR_LEN];
	unsigned char macaddr[MACADDR_LEN];
	unsigned char status;
	unsigned char proc;
	unsigned char timeout;
	SWITCH_SCENE_INFO scene;
}SWITCHINFO;

//type init
typedef struct init_dev_status_pkt {
	unsigned char h[HEAD_LEN];
	unsigned char dt;
	unsigned char parent[PARENT_LEN];
	unsigned char s_macaddr[S_MACADDR_LEN];
	unsigned char macaddr[MACADDR_LEN];
	unsigned char status;
	unsigned char crc[CRC_LEN];
	unsigned char t[TAIL_LEN];
}INIT_DPKT;
#define INIT_DEV_STATUS_PKT_LEN sizeof(INIT_DPKT)

typedef struct full_init_dev_status_pkt{
	INIT_DPKT ipkt;
	int preinit;
	SWITCH_SCENE_INFO scene;
}FULL_INIT_DPKT;
#define FULL_INIT_DEV_STATUS_PKT_LEN sizeof(FULL_INIT_DPKT)

//type 02
typedef struct dev_status_pkt {
	unsigned char h[HEAD_LEN];
	unsigned char dt;
	unsigned char type;
	unsigned char datalen;
	unsigned char s_macaddr[S_MACADDR_LEN];
	unsigned char status;
	unsigned char crc[CRC_LEN];
	unsigned char t[TAIL_LEN];
}DPKT;
#define DEV_STATUS_PKT_LEN sizeof(DPKT)

//type 03
typedef struct dev_single_cmd_pkt {
	unsigned char h[HEAD_LEN];
	unsigned char dt;
	unsigned char type;
	unsigned char datalen;
	unsigned char s_macaddr[S_MACADDR_LEN];
	unsigned char status;
	unsigned char crc[CRC_LEN];
	unsigned char t[TAIL_LEN];
}CMD_S_PKT;
#define DEV_SINGLE_CMD_PKT_LEN sizeof(CMD_S_PKT)

//type ff  for unknown macaddr or short macaddr
typedef struct req_init_pkt{
	unsigned char h[HEAD_LEN];
	unsigned char dt;
	unsigned char type;
	unsigned char datalen;
	unsigned char macaddr[MACADDR_LEN];
	unsigned char crc[CRC_LEN];
	unsigned char t[TAIL_LEN];
}REQ_INIT_PKT;
#define REQ_INIT_PKT_LEN sizeof(REQ_INIT_PKT)

pthread_mutex_t switch_mutex_lock;


typedef struct _switch
{
	struct switchinfo ninfo;
	struct _switch *prev;
	struct _switch *next;
}SWITCH_NODE;

int switch_init();
int insert_tail(SWITCHINFO ninfo);

int find_switch();
//int find_full_mac_and_status(DPKT *dpkt, unsigned char *full_mac, unsigned char *status, unsigned char *proc);
//int find_short_macaddr(INIT_DPKT *dpkt, unsigned char *short_mac);

void switch_action(char *cmd, INIT_DPKT* dpkt, SWITCH_SCENE_INFO *scene);

void switch_alarm(int num);

void *switch_init_pthread(void *arg);
void *switch_status_pthread(void *arg);
int switch_prepare(unsigned char *macaddr, int num, char *message);
int switch_prepare_foreach(unsigned char *macaddr, unsigned char switch_status);
int find_switch_status(unsigned char *macaddr, unsigned char *status);
//int switch_final_init(unsigned char* macaddr, SWITCH_REG_INFO sreginfo);
#endif
