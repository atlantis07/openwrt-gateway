#ifndef _DEV_H
#define _DEV_H
int parse_switch_message(char *type, char *message, unsigned char *short_mac, int num);
void *pthread_recv(void* arg);

typedef struct param {
	int argc;
	char **argv;
}RECV_PARAM;

#endif
